import { pgTable, text, serial, bigint, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const gameGuildsTable = pgTable("game_guilds", {
  id: text("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull().default(""),
  leaderId: text("leader_id").notNull(),
  balance: bigint("balance", { mode: "number" }).notNull().default(0),
  level: integer("level").notNull().default(1),
  maxMembers: integer("max_members").notNull().default(20),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const guildMembersTable = pgTable("guild_members", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  playerId: text("player_id").notNull(),
  role: text("role").notNull().default("member"), // leader, officer, member
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
});

export const insertGameGuildSchema = createInsertSchema(gameGuildsTable).omit({ createdAt: true });
export type InsertGameGuild = z.infer<typeof insertGameGuildSchema>;
export type GameGuild = typeof gameGuildsTable.$inferSelect;

export const insertGuildMemberSchema = createInsertSchema(guildMembersTable).omit({ id: true, joinedAt: true });
export type InsertGuildMember = z.infer<typeof insertGuildMemberSchema>;
export type GuildMember = typeof guildMembersTable.$inferSelect;
