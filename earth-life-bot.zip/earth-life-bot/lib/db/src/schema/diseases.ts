import { pgTable, text, serial, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const playerDiseasesTable = pgTable("player_diseases", {
  id: serial("id").primaryKey(),
  playerId: text("player_id").notNull(),
  diseaseId: text("disease_id").notNull(),
  contractedAt: timestamp("contracted_at").notNull().defaultNow(),
  treatedAt: timestamp("treated_at"),
  isActive: boolean("is_active").notNull().default(true),
});

export const insertPlayerDiseaseSchema = createInsertSchema(playerDiseasesTable).omit({ id: true });
export type InsertPlayerDisease = z.infer<typeof insertPlayerDiseaseSchema>;
export type PlayerDisease = typeof playerDiseasesTable.$inferSelect;
