import { pgTable, text, bigint, integer, real, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const playersTable = pgTable("players", {
  id: text("id").primaryKey(), // Discord userId_guildId
  userId: text("user_id").notNull(),
  guildId: text("guild_id").notNull(),
  name: text("name").notNull(),
  level: integer("level").notNull().default(1),
  exp: bigint("exp", { mode: "number" }).notNull().default(0),
  money: bigint("money", { mode: "number" }).notNull().default(1000),
  bank: bigint("bank", { mode: "number" }).notNull().default(0),
  job: text("job").notNull().default("unemployed"),
  location: text("location").notNull().default("city"),
  health: integer("health").notNull().default(100),
  energy: integer("energy").notNull().default(100),
  happiness: integer("happiness").notNull().default(100),
  spouseId: text("spouse_id"),
  children: integer("children").notNull().default(0),
  houseLevel: integer("house_level").notNull().default(0),
  carLevel: integer("car_level").notNull().default(0),
  companyId: text("company_id"),
  guildGameId: text("guild_game_id"),
  stockPortfolio: jsonb("stock_portfolio").$type<Record<string, number>>().default({}),
  lastWork: timestamp("last_work"),
  lastDaily: timestamp("last_daily"),
  lastExplore: timestamp("last_explore"),
  lastDisease: timestamp("last_disease"),
  isAlive: boolean("is_alive").notNull().default(true),
  totalEarned: bigint("total_earned", { mode: "number" }).notNull().default(0),
  jobLevel: integer("job_level").notNull().default(1),
  jobExp: integer("job_exp").notNull().default(0),
  // Premium / VIP
  diamonds: bigint("diamonds", { mode: "number" }).notNull().default(0),
  vipTier: integer("vip_tier").notNull().default(0), // 0=none 1=bronze 2=silver 3=gold 4=diamond
  vipExpiresAt: timestamp("vip_expires_at"),
  profileEffect: text("profile_effect").notNull().default("none"),
  // Economy extras
  loanAmount: bigint("loan_amount", { mode: "number" }).notNull().default(0),
  loanDueAt: timestamp("loan_due_at"),
  lastTax: timestamp("last_tax"),
  // Stats
  streakDays: integer("streak_days").notNull().default(0),
  lastStreak: timestamp("last_streak"),
  casinoWins: integer("casino_wins").notNull().default(0),
  casinoLosses: integer("casino_losses").notNull().default(0),
  workedTotal: integer("worked_total").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertPlayerSchema = createInsertSchema(playersTable).omit({ createdAt: true, updatedAt: true });
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Player = typeof playersTable.$inferSelect;
