import { pgTable, text, bigint, integer, timestamp, boolean, jsonb, serial } from "drizzle-orm/pg-core";

// Player inventory
export const playerItemsTable = pgTable("player_items", {
  id: serial("id").primaryKey(),
  playerId: text("player_id").notNull(),
  itemId: text("item_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  acquiredAt: timestamp("acquired_at").notNull().defaultNow(),
});

// Gift codes
export const giftCodesTable = pgTable("gift_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  rewardsJson: jsonb("rewards_json").$type<{
    money?: number;
    exp?: number;
    diamonds?: number;
    items?: { itemId: string; quantity: number }[];
  }>().notNull(),
  maxUses: integer("max_uses").notNull().default(1),
  uses: integer("uses").notNull().default(0),
  expiresAt: timestamp("expires_at"),
  createdBy: text("created_by").notNull(),
  guildId: text("guild_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Gift code usage tracking
export const giftCodeUsesTable = pgTable("gift_code_uses", {
  id: serial("id").primaryKey(),
  codeId: integer("code_id").notNull(),
  playerId: text("player_id").notNull(),
  usedAt: timestamp("used_at").notNull().defaultNow(),
});

// Player achievements
export const playerAchievementsTable = pgTable("player_achievements", {
  id: serial("id").primaryKey(),
  playerId: text("player_id").notNull(),
  achievementId: text("achievement_id").notNull(),
  unlockedAt: timestamp("unlocked_at").notNull().defaultNow(),
});

// Activity logs
export const activityLogsTable = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  playerId: text("player_id").notNull(),
  action: text("action").notNull(), // 'work','casino','explore','shop','bank',...
  description: text("description").notNull(),
  amount: bigint("amount", { mode: "number" }).notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Stock prices (for investment system)
export const stocksTable = pgTable("stocks", {
  id: text("id").primaryKey(), // e.g. 'TECH', 'AGRI'
  name: text("name").notNull(),
  price: bigint("price", { mode: "number" }).notNull().default(1000),
  change: integer("change").notNull().default(0), // percentage change today
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
