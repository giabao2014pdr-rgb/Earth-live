import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

// Health-check endpoint — dùng để UptimeRobot ping giữ bot sống 24/7
app.get("/api/ping", (_req, res) => {
  res.json({ status: "ok", uptime: Math.floor(process.uptime()) });
});

app.get("/api/healthz", (_req, res) => {
  res.json({ status: "ok" });
});

export default app;
