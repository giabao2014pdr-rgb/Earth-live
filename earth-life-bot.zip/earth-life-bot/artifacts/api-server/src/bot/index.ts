import { Client, GatewayIntentBits, Collection, Events, REST, Routes } from "discord.js";
import type { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { logger } from "../lib/logger.js";

// Import all commands
import { data as profileData, execute as profileExecute } from "./commands/profile.js";
import { data as registerData, execute as registerExecute } from "./commands/register.js";
import { workData, workExecute, jobsData, jobsExecute } from "./commands/work.js";
import {
  balanceData, balanceExecute,
  bankData, bankExecute,
  dailyData, dailyExecute,
  payData, payExecute,
  leaderboardData, leaderboardExecute,
} from "./commands/economy.js";
import {
  healthData, healthExecute,
  hospitalData, hospitalExecute,
  reviveData, reviveExecute,
} from "./commands/health.js";
import {
  slotsData, slotsExecute,
  coinflipData, coinflipExecute,
  blackjackData, blackjackExecute,
  rouletteData, rouletteExecute,
  raceData, raceExecute,
} from "./commands/casino.js";
import {
  houseData, houseExecute,
  carData, carExecute,
  marryData, marryExecute,
  divorceData, divorceExecute,
  babyData, babyExecute,
} from "./commands/life.js";
import {
  exploreData, exploreExecute,
  travelData, travelExecute,
  mapData, mapExecute,
} from "./commands/world.js";
import { guildData, guildExecute } from "./commands/guild.js";

// ─── NEW commands ────────────────────────────────────────────────────────────
import { inventoryData, inventoryExecute, shopData, shopExecute, useItemData, useItemExecute } from "./commands/inventory.js";
import { loanData, loanExecute, repayData, repayExecute, interestData, interestExecute } from "./commands/bank_extended.js";
import { taixiuData, taixiuExecute, diceData, diceExecute, pokerData, pokerExecute, lotteryData, lotteryExecute } from "./commands/casino_extended.js";
import { achievementsData, achievementsExecute } from "./commands/achievements.js";
import { diamondData, diamondExecute, vipData, vipExecute } from "./commands/premium.js";
import { adminData, adminExecute } from "./commands/admin.js";
import { giftcodeData, giftcodeExecute } from "./commands/giftcode.js";
import { eventsData, eventsExecute } from "./commands/events.js";
import { investData, investExecute } from "./commands/invest.js";
import { historyData, historyExecute } from "./commands/history.js";
import { helpData, helpExecute } from "./commands/help.js";

interface Command {
  data: SlashCommandBuilder;
  execute: (interaction: ChatInputCommandInteraction) => Promise<void>;
}

const commands: Command[] = [
  // Core
  { data: registerData, execute: registerExecute },
  { data: profileData, execute: profileExecute },
  // Work
  { data: workData, execute: workExecute },
  { data: jobsData, execute: jobsExecute },
  // Economy (original)
  { data: balanceData, execute: balanceExecute },
  { data: bankData, execute: bankExecute },
  { data: dailyData, execute: dailyExecute },
  { data: payData, execute: payExecute },
  { data: leaderboardData, execute: leaderboardExecute },
  // Economy (new)
  { data: loanData, execute: loanExecute },
  { data: repayData, execute: repayExecute },
  { data: interestData, execute: interestExecute },
  // Health
  { data: healthData, execute: healthExecute },
  { data: hospitalData, execute: hospitalExecute },
  { data: reviveData, execute: reviveExecute },
  // Casino (original)
  { data: slotsData, execute: slotsExecute },
  { data: coinflipData, execute: coinflipExecute },
  { data: blackjackData, execute: blackjackExecute },
  { data: rouletteData, execute: rouletteExecute },
  { data: raceData, execute: raceExecute },
  // Casino (new)
  { data: taixiuData, execute: taixiuExecute },
  { data: diceData, execute: diceExecute },
  { data: pokerData, execute: pokerExecute },
  { data: lotteryData, execute: lotteryExecute },
  // Life
  { data: houseData, execute: houseExecute },
  { data: carData, execute: carExecute },
  { data: marryData, execute: marryExecute },
  { data: divorceData, execute: divorceExecute },
  { data: babyData, execute: babyExecute },
  // World
  { data: exploreData, execute: exploreExecute },
  { data: travelData, execute: travelExecute },
  { data: mapData, execute: mapExecute },
  // Guild
  { data: guildData, execute: guildExecute },
  // Inventory & Shop
  { data: inventoryData, execute: inventoryExecute },
  { data: shopData, execute: shopExecute },
  { data: useItemData, execute: useItemExecute },
  // Achievements
  { data: achievementsData, execute: achievementsExecute },
  // Premium
  { data: diamondData, execute: diamondExecute },
  { data: vipData, execute: vipExecute },
  // Admin
  { data: adminData, execute: adminExecute },
  // Gift Code
  { data: giftcodeData, execute: giftcodeExecute },
  // Events
  { data: eventsData, execute: eventsExecute },
  // Invest
  { data: investData, execute: investExecute },
  // History
  { data: historyData, execute: historyExecute },
  // Help
  { data: helpData, execute: helpExecute },
];

const commandMap = new Collection<string, Command>();
for (const cmd of commands) {
  commandMap.set(cmd.data.name, cmd);
}

export async function startBot() {
  const token = process.env["DISCORD_TOKEN"];
  const clientId = process.env["DISCORD_CLIENT_ID"];

  if (!token || !clientId) {
    logger.error("DISCORD_TOKEN and DISCORD_CLIENT_ID are required");
    return;
  }

  // Register slash commands
  const rest = new REST({ version: "10" }).setToken(token);
  const commandsJson = commands.map((c) => c.data.toJSON());

  try {
    logger.info({ count: commands.length }, "Registering slash commands...");
    await rest.put(Routes.applicationCommands(clientId), { body: commandsJson });
    logger.info("Slash commands registered successfully");
  } catch (err) {
    logger.error({ err }, "Failed to register slash commands");
  }

  // Create Discord client
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
    ],
  });

  client.once(Events.ClientReady, (readyClient) => {
    logger.info({ tag: readyClient.user.tag }, "Discord bot is ready!");
    startPassiveTasks(client);
  });

  client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    const command = commandMap.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction);
    } catch (err) {
      logger.error({ err, command: interaction.commandName }, "Command error");
      const errorMsg = { content: "❌ Có lỗi xảy ra khi thực hiện lệnh này!", ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(errorMsg).catch(() => {});
      } else {
        await interaction.reply(errorMsg).catch(() => {});
      }
    }
  });

  await client.login(token);
}

function startPassiveTasks(client: Client) {
  // Energy restore every 30 minutes
  setInterval(async () => {
    try {
      const { db } = await import("@workspace/db");
      const { sql } = await import("drizzle-orm");

      await db.execute(sql`
        UPDATE players SET
          energy = LEAST(100, energy + 10),
          updated_at = NOW()
        WHERE is_alive = true
      `);

      logger.info("Passive task: energy restored");
    } catch (err) {
      logger.error({ err }, "Passive task error");
    }
  }, 30 * 60 * 1000);

  // Disease health drain every hour
  setInterval(async () => {
    try {
      const { db } = await import("@workspace/db");
      const { playersTable, playerDiseasesTable } = await import("@workspace/db");
      const { eq, sql } = await import("drizzle-orm");

      const diseases = await db.select().from(playerDiseasesTable).where(eq(playerDiseasesTable.isActive, true));
      const { DISEASES } = await import("./constants/diseases.js");

      for (const d of diseases) {
        const info = DISEASES[d.diseaseId];
        if (!info) continue;

        await db.execute(sql`
          UPDATE players SET
            health = GREATEST(0, health - ${info.healthDrain}),
            updated_at = NOW()
          WHERE id = ${d.playerId} AND is_alive = true
        `);

        const rows = await db.select().from(playersTable).where(eq(playersTable.id, d.playerId)).limit(1);
        const p = rows[0];
        if (p && p.health <= 0 && p.isAlive) {
          const deathRoll = Math.random();
          if (deathRoll < info.deathRisk) {
            await db.update(playersTable).set({ isAlive: false }).where(eq(playersTable.id, d.playerId));
            logger.info({ playerId: d.playerId, disease: d.diseaseId }, "Player died from disease");
          }
        }
      }
    } catch (err) {
      logger.error({ err }, "Disease drain task error");
    }
  }, 60 * 60 * 1000);

  // Bank interest every week (every 168 hours — simulated as daily check)
  setInterval(async () => {
    try {
      const { db } = await import("@workspace/db");
      const { sql } = await import("drizzle-orm");

      // 2% weekly interest on bank balance (0.286% per day)
      await db.execute(sql`
        UPDATE players SET
          bank = FLOOR(bank * 1.00286),
          updated_at = NOW()
        WHERE bank > 0 AND is_alive = true
      `);

      // Late loan penalty: add 10% per day on overdue loans
      await db.execute(sql`
        UPDATE players SET
          loan_amount = FLOOR(loan_amount * 1.10),
          updated_at = NOW()
        WHERE loan_amount > 0 AND loan_due_at IS NOT NULL AND loan_due_at < NOW()
      `);

      // VIP daily diamonds
      await db.execute(sql`
        UPDATE players SET
          diamonds = diamonds + CASE
            WHEN vip_tier = 1 THEN 3
            WHEN vip_tier = 2 THEN 8
            WHEN vip_tier = 3 THEN 20
            WHEN vip_tier = 4 THEN 50
            ELSE 0
          END,
          updated_at = NOW()
        WHERE vip_tier > 0 AND (vip_expires_at IS NULL OR vip_expires_at > NOW())
      `);

      // Expire VIP
      await db.execute(sql`
        UPDATE players SET
          vip_tier = 0,
          vip_expires_at = NULL,
          updated_at = NOW()
        WHERE vip_tier > 0 AND vip_expires_at IS NOT NULL AND vip_expires_at < NOW()
      `);

      logger.info("Passive task: daily economy tick");
    } catch (err) {
      logger.error({ err }, "Daily economy tick error");
    }
  }, 24 * 60 * 60 * 1000); // every 24 hours
}
