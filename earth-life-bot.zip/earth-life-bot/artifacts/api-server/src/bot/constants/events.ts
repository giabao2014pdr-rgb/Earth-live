export interface GameEvent {
  id: string;
  name: string;
  emoji: string;
  description: string;
  bonuses: {
    expMultiplier?: number;
    moneyMultiplier?: number;
    luckBoost?: number;
    dailyBonus?: number;
  };
  startMonth: number; // 1-12
  startDay: number;
  endMonth: number;
  endDay: number;
}

export const EVENTS: GameEvent[] = [
  {
    id: "tet", name: "Tết Nguyên Đán", emoji: "🧧",
    description: "Năm mới đến! X2 tiền và EXP cho mọi hoạt động. Điểm danh nhận bao lì xì 500,000₫",
    bonuses: { expMultiplier: 2, moneyMultiplier: 2, dailyBonus: 500000 },
    startMonth: 1, startDay: 1, endMonth: 1, endDay: 7,
  },
  {
    id: "valentine", name: "Valentine", emoji: "💘",
    description: "Ngày tình nhân! Tăng hạnh phúc và giảm giá nhẫn cưới",
    bonuses: { expMultiplier: 1.2, luckBoost: 1.1 },
    startMonth: 2, startDay: 14, endMonth: 2, endDay: 14,
  },
  {
    id: "halloween", name: "Halloween", emoji: "🎃",
    description: "Đêm ma quái! Khám phá có cơ hội tìm kho báu bí ẩn",
    bonuses: { expMultiplier: 1.5, luckBoost: 1.3, dailyBonus: 50000 },
    startMonth: 10, startDay: 28, endMonth: 11, endDay: 1,
  },
  {
    id: "noel", name: "Noel & Năm Mới", emoji: "🎄",
    description: "Mùa Giáng Sinh! X1.5 tiền, quà ngẫu nhiên mỗi ngày điểm danh",
    bonuses: { expMultiplier: 1.5, moneyMultiplier: 1.5, dailyBonus: 100000 },
    startMonth: 12, startDay: 24, endMonth: 12, endDay: 31,
  },
  {
    id: "sinh_nhat_bot", name: "Sinh Nhật Bot", emoji: "🎂",
    description: "Chúc mừng sinh nhật Earth Life Bot! Mọi người nhận quà đặc biệt",
    bonuses: { expMultiplier: 3, moneyMultiplier: 2, luckBoost: 1.5, dailyBonus: 1000000 },
    startMonth: 7, startDay: 13, endMonth: 7, endDay: 13,
  },
];

/** Returns events that are currently active based on given date */
export function getActiveEvents(date: Date = new Date()): GameEvent[] {
  const month = date.getMonth() + 1;
  const day = date.getDate();
  return EVENTS.filter(ev => {
    if (ev.startMonth === ev.endMonth) {
      return month === ev.startMonth && day >= ev.startDay && day <= ev.endDay;
    }
    if (month === ev.startMonth) return day >= ev.startDay;
    if (month === ev.endMonth) return day <= ev.endDay;
    return month > ev.startMonth && month < ev.endMonth;
  });
}

/** Combine multipliers from all active events */
export function getEventBonuses(date: Date = new Date()) {
  const active = getActiveEvents(date);
  let expMultiplier = 1;
  let moneyMultiplier = 1;
  let luckBoost = 1;
  let dailyBonus = 0;
  for (const ev of active) {
    expMultiplier *= ev.bonuses.expMultiplier ?? 1;
    moneyMultiplier *= ev.bonuses.moneyMultiplier ?? 1;
    luckBoost *= ev.bonuses.luckBoost ?? 1;
    dailyBonus += ev.bonuses.dailyBonus ?? 0;
  }
  return { expMultiplier, moneyMultiplier, luckBoost, dailyBonus, activeEvents: active };
}
