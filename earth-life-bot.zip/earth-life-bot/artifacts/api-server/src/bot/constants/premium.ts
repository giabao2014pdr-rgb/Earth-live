export interface VipTier {
  tier: number;
  name: string;
  emoji: string;
  color: number; // hex
  costDiamonds: number; // per month
  perks: {
    dailyDiamonds: number;
    expMultiplier: number;
    moneyMultiplier: number;
    loanLimitMultiplier: number;
    interestRateBonus: number; // extra % on bank interest
    luckBoost: number;
    badge: string;
    specialTitle: string;
  };
}

export const VIP_TIERS: VipTier[] = [
  {
    tier: 0, name: "Thường dân", emoji: "👤", color: 0x95a5a6,
    costDiamonds: 0,
    perks: { dailyDiamonds: 0, expMultiplier: 1, moneyMultiplier: 1, loanLimitMultiplier: 1, interestRateBonus: 0, luckBoost: 1, badge: "", specialTitle: "" },
  },
  {
    tier: 1, name: "Bronze VIP", emoji: "🥉", color: 0xcd7f32,
    costDiamonds: 50,
    perks: { dailyDiamonds: 3, expMultiplier: 1.1, moneyMultiplier: 1.1, loanLimitMultiplier: 1.5, interestRateBonus: 1, luckBoost: 1.05, badge: "🥉", specialTitle: "Hội viên Đồng" },
  },
  {
    tier: 2, name: "Silver VIP", emoji: "🥈", color: 0xc0c0c0,
    costDiamonds: 150,
    perks: { dailyDiamonds: 8, expMultiplier: 1.25, moneyMultiplier: 1.25, loanLimitMultiplier: 2, interestRateBonus: 2, luckBoost: 1.15, badge: "🥈", specialTitle: "Hội viên Bạc" },
  },
  {
    tier: 3, name: "Gold VIP", emoji: "🥇", color: 0xffd700,
    costDiamonds: 400,
    perks: { dailyDiamonds: 20, expMultiplier: 1.5, moneyMultiplier: 1.5, loanLimitMultiplier: 3, interestRateBonus: 4, luckBoost: 1.3, badge: "🥇", specialTitle: "Hội viên Vàng" },
  },
  {
    tier: 4, name: "Diamond VIP", emoji: "💎", color: 0x00bfff,
    costDiamonds: 1000,
    perks: { dailyDiamonds: 50, expMultiplier: 2, moneyMultiplier: 2, loanLimitMultiplier: 5, interestRateBonus: 8, luckBoost: 1.5, badge: "💎", specialTitle: "Hội viên Kim Cương" },
  },
];

export const VIP_MAP = Object.fromEntries(VIP_TIERS.map(v => [v.tier, v]));

export const DIAMOND_PACKAGES = [
  { id: "pkg_100", name: "100 Kim Cương", diamonds: 100, bonusDiamonds: 0, description: "Gói nhỏ" },
  { id: "pkg_500", name: "500 + 50 Kim Cương", diamonds: 500, bonusDiamonds: 50, description: "Gói phổ biến (+10% bonus)" },
  { id: "pkg_1000", name: "1000 + 200 Kim Cương", diamonds: 1000, bonusDiamonds: 200, description: "Gói giá trị (+20% bonus)" },
  { id: "pkg_5000", name: "5000 + 1500 Kim Cương", diamonds: 5000, bonusDiamonds: 1500, description: "Gói lớn (+30% bonus)" },
];

export const BASE_LOAN_LIMIT = 500000; // base loan limit 500k₫
export const LOAN_INTEREST_RATE = 0.05; // 5% interest per day
export const BANK_INTEREST_RATE = 0.02; // 2% interest per week
