export function expToNextLevel(level: number): number {
  return Math.floor(100 * Math.pow(1.15, level - 1));
}

export function totalExpForLevel(level: number): number {
  let total = 0;
  for (let i = 1; i < level; i++) {
    total += expToNextLevel(i);
  }
  return total;
}

export function calculateLevel(totalExp: number): { level: number; expInLevel: number; expNeeded: number } {
  let level = 1;
  let remaining = totalExp;
  while (remaining >= expToNextLevel(level) && level < 1000) {
    remaining -= expToNextLevel(level);
    level++;
  }
  return { level, expInLevel: remaining, expNeeded: expToNextLevel(level) };
}

export function getLevelTitle(level: number): string {
  if (level >= 900) return "🌌 Huyền thoại tối thượng";
  if (level >= 700) return "⭐ Siêu huyền thoại";
  if (level >= 500) return "💎 Kim cương";
  if (level >= 300) return "🏆 Cao thủ";
  if (level >= 200) return "🔥 Chiến thần";
  if (level >= 150) return "⚡ Thần thánh";
  if (level >= 100) return "👑 Vương giả";
  if (level >= 75) return "💫 Thạch đấu";
  if (level >= 50) return "🌟 Bạch kim";
  if (level >= 30) return "🥇 Vàng";
  if (level >= 20) return "🥈 Bạc";
  if (level >= 10) return "🥉 Đồng";
  if (level >= 5) return "🔰 Tân thủ";
  return "🌱 Mới bắt đầu";
}

export function progressBar(current: number, max: number, length = 10): string {
  const filled = Math.floor((current / max) * length);
  const empty = length - filled;
  return "█".repeat(filled) + "░".repeat(empty);
}
