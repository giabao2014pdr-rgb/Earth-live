export interface Location {
  id: string;
  name: string;
  emoji: string;
  description: string;
  expBonus: number;
  moneyBonus: number;
  diseaseChance: number;
  events: string[];
}

export const LOCATIONS: Record<string, Location> = {
  city: {
    id: "city",
    name: "Thành phố",
    emoji: "🏙️",
    description: "Trung tâm kinh tế sầm uất, nhiều cơ hội việc làm",
    expBonus: 1.0,
    moneyBonus: 1.2,
    diseaseChance: 0.05,
    events: ["gặp đồng nghiệp", "trúng thưởng xổ số nhỏ", "mất ví", "tắc đường"],
  },
  village: {
    id: "village",
    name: "Làng quê",
    emoji: "🌾",
    description: "Yên bình, không khí trong lành, thích hợp nông nghiệp",
    expBonus: 0.8,
    moneyBonus: 0.8,
    diseaseChance: 0.02,
    events: ["thu hoạch được mùa", "giúp đỡ hàng xóm", "tìm thấy rau quý"],
  },
  beach: {
    id: "beach",
    name: "Biển",
    emoji: "🏖️",
    description: "Bãi biển tuyệt đẹp, lý tưởng cho ngư dân",
    expBonus: 0.9,
    moneyBonus: 0.9,
    diseaseChance: 0.03,
    events: ["bắt được cá lớn", "tìm thấy đồ cổ", "gặp bão nhỏ"],
  },
  mountain: {
    id: "mountain",
    name: "Núi",
    emoji: "⛰️",
    description: "Địa hình hiểm trở, ẩn chứa khoáng sản quý",
    expBonus: 1.3,
    moneyBonus: 1.0,
    diseaseChance: 0.04,
    events: ["tìm thấy quặng quý", "gặp thú hoang", "phong cảnh đẹp"],
  },
  desert: {
    id: "desert",
    name: "Sa mạc",
    emoji: "🏜️",
    description: "Khắc nghiệt nhưng ẩn chứa nhiều báu vật",
    expBonus: 1.5,
    moneyBonus: 1.1,
    diseaseChance: 0.07,
    events: ["tìm ốc đảo", "bão cát", "gặp đoàn lữ hành"],
  },
  forest: {
    id: "forest",
    name: "Rừng",
    emoji: "🌲",
    description: "Rừng xanh bí ẩn, nhiều tài nguyên thiên nhiên",
    expBonus: 1.2,
    moneyBonus: 0.9,
    diseaseChance: 0.06,
    events: ["tìm thảo dược quý", "gặp thú rừng", "phát hiện di tích cổ"],
  },
  island: {
    id: "island",
    name: "Đảo bí ẩn",
    emoji: "🏝️",
    description: "Hòn đảo huyền bí với kho báu và nguy hiểm bất ngờ",
    expBonus: 2.0,
    moneyBonus: 1.5,
    diseaseChance: 0.1,
    events: ["tìm kho báu cổ", "gặp cướp biển", "phát hiện di tích bí ẩn", "sóng thần nhỏ"],
  },
};

export const LOCATION_LIST = Object.values(LOCATIONS);

export const HOUSES = [
  { level: 1, name: "Phòng trọ", emoji: "🛏️", cost: 5000, description: "Phòng trọ nhỏ, đủ để ở" },
  { level: 2, name: "Căn hộ mini", emoji: "🏠", cost: 25000, description: "Căn hộ nhỏ tiện nghi" },
  { level: 3, name: "Căn hộ cao cấp", emoji: "🏡", cost: 100000, description: "Căn hộ rộng rãi, tiện nghi đầy đủ" },
  { level: 4, name: "Biệt thự", emoji: "🏰", cost: 500000, description: "Biệt thự sang trọng với sân vườn" },
  { level: 5, name: "Dinh thự", emoji: "🏯", cost: 2000000, description: "Dinh thự đẳng cấp như nhà giàu" },
];

export const CARS = [
  { level: 1, name: "Xe đạp", emoji: "🚲", cost: 500, description: "Phương tiện cơ bản nhất" },
  { level: 2, name: "Xe máy", emoji: "🛵", cost: 5000, description: "Xe máy cũ tiện dụng" },
  { level: 3, name: "Xe ô tô cũ", emoji: "🚗", cost: 30000, description: "Xe ô tô đã qua sử dụng" },
  { level: 4, name: "Xe ô tô mới", emoji: "🚙", cost: 150000, description: "Xe ô tô đời mới hiện đại" },
  { level: 5, name: "Siêu xe", emoji: "🏎️", cost: 1000000, description: "Siêu xe cao cấp, tốc độ tối đa" },
];
