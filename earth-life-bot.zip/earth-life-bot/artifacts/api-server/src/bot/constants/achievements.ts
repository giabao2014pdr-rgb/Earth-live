export interface Achievement {
  id: string;
  name: string;
  emoji: string;
  description: string;
  reward: { money?: number; exp?: number; diamonds?: number };
  check: (stats: AchievementStats) => boolean;
}

export interface AchievementStats {
  level: number;
  totalEarned: number;
  money: number;
  bank: number;
  houseLevel: number;
  carLevel: number;
  casinoWins: number;
  casinoLosses: number;
  workedTotal: number;
  children: number;
  isMarried: boolean;
  guildGameId: string | null;
  loanAmount: number;
}

export const ACHIEVEMENTS: Achievement[] = [
  // ─── Level ──────────────────────────────────────────────────
  { id: "level_10", name: "Bước vào đời", emoji: "🌱", description: "Đạt cấp độ 10", reward: { money: 5000, exp: 500 }, check: s => s.level >= 10 },
  { id: "level_50", name: "Dày dặn kinh nghiệm", emoji: "🌿", description: "Đạt cấp độ 50", reward: { money: 50000, exp: 5000 }, check: s => s.level >= 50 },
  { id: "level_100", name: "Chiến binh bách chiến", emoji: "⚔️", description: "Đạt cấp độ 100", reward: { money: 200000, diamonds: 10, exp: 10000 }, check: s => s.level >= 100 },
  { id: "level_500", name: "Huyền thoại sống", emoji: "🏆", description: "Đạt cấp độ 500", reward: { money: 2000000, diamonds: 50, exp: 100000 }, check: s => s.level >= 500 },
  { id: "level_1000", name: "Bất tử", emoji: "👑", description: "Đạt cấp độ 1000 — đỉnh cao tối thượng", reward: { money: 10000000, diamonds: 200, exp: 0 }, check: s => s.level >= 1000 },

  // ─── Money ──────────────────────────────────────────────────
  { id: "earn_100k", name: "Bắt đầu kiếm tiền", emoji: "💵", description: "Kiếm tổng cộng 100,000₫", reward: { money: 10000 }, check: s => s.totalEarned >= 100000 },
  { id: "earn_1m", name: "Triệu phú mới nổi", emoji: "💴", description: "Kiếm tổng cộng 1,000,000₫", reward: { money: 100000, exp: 5000 }, check: s => s.totalEarned >= 1000000 },
  { id: "earn_100m", name: "Đại gia", emoji: "💶", description: "Kiếm tổng cộng 100,000,000₫", reward: { money: 5000000, diamonds: 20, exp: 50000 }, check: s => s.totalEarned >= 100000000 },
  { id: "earn_1b", name: "Tỷ phú", emoji: "💷", description: "Kiếm tổng cộng 1,000,000,000₫", reward: { money: 50000000, diamonds: 100, exp: 200000 }, check: s => s.totalEarned >= 1000000000 },
  { id: "cash_1m", name: "Có trong tay", emoji: "💰", description: "Có 1,000,000₫ trong ví", reward: { exp: 2000 }, check: s => s.money >= 1000000 },
  { id: "bank_10m", name: "Tiết kiệm thông minh", emoji: "🏦", description: "Gửi ngân hàng 10,000,000₫", reward: { exp: 5000 }, check: s => s.bank >= 10000000 },

  // ─── Work ───────────────────────────────────────────────────
  { id: "work_10", name: "Chăm chỉ", emoji: "💪", description: "Đi làm 10 lần", reward: { money: 5000 }, check: s => s.workedTotal >= 10 },
  { id: "work_100", name: "Lao động xuất sắc", emoji: "🔨", description: "Đi làm 100 lần", reward: { money: 50000, exp: 10000 }, check: s => s.workedTotal >= 100 },
  { id: "work_1000", name: "Vua lao động", emoji: "👷", description: "Đi làm 1000 lần", reward: { money: 500000, diamonds: 15, exp: 50000 }, check: s => s.workedTotal >= 1000 },

  // ─── Property ───────────────────────────────────────────────
  { id: "house_1", name: "Mái ấm", emoji: "🏠", description: "Mua căn nhà đầu tiên", reward: { money: 10000, exp: 2000 }, check: s => s.houseLevel >= 1 },
  { id: "house_3", name: "Nhà đẹp", emoji: "🏡", description: "Nâng cấp nhà lên cấp 3", reward: { money: 100000, exp: 10000 }, check: s => s.houseLevel >= 3 },
  { id: "house_5", name: "Ông hoàng bất động sản", emoji: "🏰", description: "Sở hữu Penthouse/Đảo riêng", reward: { money: 2000000, diamonds: 30, exp: 50000 }, check: s => s.houseLevel >= 5 },
  { id: "car_1", name: "Có xe đi", emoji: "🚗", description: "Mua phương tiện đầu tiên", reward: { money: 5000, exp: 2000 }, check: s => s.carLevel >= 1 },
  { id: "car_5", name: "Sưu tầm siêu xe", emoji: "🏎️", description: "Sở hữu siêu xe giới hạn", reward: { money: 2000000, diamonds: 30, exp: 50000 }, check: s => s.carLevel >= 5 },

  // ─── Casino ─────────────────────────────────────────────────
  { id: "casino_win_1", name: "Người mới may mắn", emoji: "🎰", description: "Thắng casino lần đầu", reward: { money: 5000 }, check: s => s.casinoWins >= 1 },
  { id: "casino_win_50", name: "Con cưng của vận may", emoji: "🎲", description: "Thắng casino 50 lần", reward: { money: 200000, diamonds: 10, exp: 20000 }, check: s => s.casinoWins >= 50 },
  { id: "casino_win_200", name: "Bá chủ casino", emoji: "♠️", description: "Thắng casino 200 lần", reward: { money: 1000000, diamonds: 50, exp: 100000 }, check: s => s.casinoWins >= 200 },

  // ─── Family ─────────────────────────────────────────────────
  { id: "married", name: "Tìm được nửa kia", emoji: "💍", description: "Kết hôn với người chơi khác", reward: { money: 20000, happiness: 20 } as any, check: s => s.isMarried },
  { id: "children_1", name: "Thiên đường gia đình", emoji: "👶", description: "Có con đầu lòng", reward: { money: 30000, exp: 5000 }, check: s => s.children >= 1 },
  { id: "children_3", name: "Gia đình đông vui", emoji: "👨‍👩‍👧‍👦", description: "Có 3 con", reward: { money: 100000, diamonds: 5 }, check: s => s.children >= 3 },

  // ─── Guild ──────────────────────────────────────────────────
  { id: "guild_join", name: "Gia nhập bang hội", emoji: "⚔️", description: "Gia nhập một bang hội", reward: { exp: 5000 }, check: s => !!s.guildGameId },
];

export const ACHIEVEMENT_MAP = Object.fromEntries(ACHIEVEMENTS.map(a => [a.id, a]));
