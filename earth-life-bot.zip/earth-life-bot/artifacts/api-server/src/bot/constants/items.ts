export interface Item {
  id: string;
  name: string;
  emoji: string;
  description: string;
  price: number;         // shop price (0 = not for sale)
  diamondPrice: number;  // diamond price (0 = not for diamonds)
  type: "consumable" | "collectible" | "boost" | "key" | "ticket" | "gift";
  effect?: {
    health?: number;
    energy?: number;
    happiness?: number;
    money?: number;
    exp?: number;
    luckBoost?: number;      // multiplier for casino luck (e.g. 1.2)
    expBoost?: number;       // multiplier for EXP gain
    moneyBoost?: number;     // multiplier for money gain
    cooldownReduce?: number; // reduce cooldown by % (0-1)
    duration?: number;       // duration in hours (for boosts)
  };
}

export const ITEMS: Record<string, Item> = {
  // ─── Medicines ──────────────────────────────────────────────
  thuoc_cam: {
    id: "thuoc_cam", name: "Thuốc cảm cúm", emoji: "💊",
    description: "Phục hồi 20 máu, giảm triệu chứng bệnh nhẹ",
    price: 500, diamondPrice: 0, type: "consumable",
    effect: { health: 20, happiness: 5 },
  },
  thuoc_bo: {
    id: "thuoc_bo", name: "Thuốc bổ tổng hợp", emoji: "🧴",
    description: "Phục hồi 40 máu và 30 năng lượng",
    price: 1500, diamondPrice: 0, type: "consumable",
    effect: { health: 40, energy: 30 },
  },
  thuoc_quy: {
    id: "thuoc_quy", name: "Thuốc quý hiếm", emoji: "✨",
    description: "Phục hồi 80 máu, 50 năng lượng, 30 hạnh phúc",
    price: 5000, diamondPrice: 5, type: "consumable",
    effect: { health: 80, energy: 50, happiness: 30 },
  },
  nuoc_tang_luc: {
    id: "nuoc_tang_luc", name: "Nước tăng lực", emoji: "⚡",
    description: "Khôi phục 60 năng lượng ngay lập tức",
    price: 800, diamondPrice: 0, type: "consumable",
    effect: { energy: 60 },
  },
  vitamin: {
    id: "vitamin", name: "Vitamin tổng hợp", emoji: "🍊",
    description: "Tăng 15 máu và 15 hạnh phúc",
    price: 300, diamondPrice: 0, type: "consumable",
    effect: { health: 15, happiness: 15 },
  },

  // ─── Casino Tickets ──────────────────────────────────────────
  ve_casino: {
    id: "ve_casino", name: "Vé casino VIP", emoji: "🎫",
    description: "Cho phép vào khu VIP casino với cược tối thiểu thấp hơn",
    price: 2000, diamondPrice: 3, type: "ticket",
    effect: { luckBoost: 1.1 },
  },
  ve_may_man: {
    id: "ve_may_man", name: "Vé may mắn", emoji: "🍀",
    description: "Tăng 20% may mắn cho lần chơi casino tiếp theo",
    price: 3000, diamondPrice: 5, type: "ticket",
    effect: { luckBoost: 1.2 },
  },

  // ─── Lottery ────────────────────────────────────────────────
  ve_so: {
    id: "ve_so", name: "Vé số", emoji: "🎟️",
    description: "Cào để có cơ hội trúng thưởng lớn",
    price: 100, diamondPrice: 0, type: "ticket",
  },
  ve_so_vang: {
    id: "ve_so_vang", name: "Vé số vàng", emoji: "🌟",
    description: "Vé số đặc biệt, tỷ lệ trúng cao hơn",
    price: 0, diamondPrice: 10, type: "ticket",
  },

  // ─── Boosts ─────────────────────────────────────────────────
  goi_x2_exp: {
    id: "goi_x2_exp", name: "Gói X2 EXP (24h)", emoji: "📈",
    description: "Nhân đôi EXP nhận được trong 24 giờ",
    price: 0, diamondPrice: 20, type: "boost",
    effect: { expBoost: 2, duration: 24 },
  },
  goi_x2_tien: {
    id: "goi_x2_tien", name: "Gói X2 Tiền (24h)", emoji: "💰",
    description: "Nhân đôi tiền kiếm được trong 24 giờ",
    price: 0, diamondPrice: 25, type: "boost",
    effect: { moneyBoost: 2, duration: 24 },
  },
  goi_tang_may_man: {
    id: "goi_tang_may_man", name: "Gói May Mắn (12h)", emoji: "🌈",
    description: "Tăng 30% may mắn casino trong 12 giờ",
    price: 0, diamondPrice: 15, type: "boost",
    effect: { luckBoost: 1.3, duration: 12 },
  },
  goi_giam_cd: {
    id: "goi_giam_cd", name: "Gói Giảm Thời Gian (1 lần)", emoji: "⏰",
    description: "Xóa cooldown công việc ngay lập tức",
    price: 0, diamondPrice: 10, type: "boost",
    effect: { cooldownReduce: 1 },
  },

  // ─── Profile Effects ─────────────────────────────────────────
  hieu_ung_lua: {
    id: "hieu_ung_lua", name: "Hiệu ứng ngọn lửa 🔥", emoji: "🔥",
    description: "Thêm hiệu ứng ngọn lửa vào hồ sơ nhân vật",
    price: 0, diamondPrice: 30, type: "collectible",
  },
  hieu_ung_bang: {
    id: "hieu_ung_bang", name: "Hiệu ứng băng giá ❄️", emoji: "❄️",
    description: "Thêm hiệu ứng băng giá vào hồ sơ nhân vật",
    price: 0, diamondPrice: 30, type: "collectible",
  },
  hieu_ung_sao: {
    id: "hieu_ung_sao", name: "Hiệu ứng ngân hà 🌌", emoji: "🌌",
    description: "Thêm hiệu ứng ngân hà vào hồ sơ nhân vật",
    price: 0, diamondPrice: 50, type: "collectible",
  },

  // ─── Gift Boxes ──────────────────────────────────────────────
  hop_qua_nho: {
    id: "hop_qua_nho", name: "Hộp quà nhỏ", emoji: "🎁",
    description: "Chứa phần thưởng ngẫu nhiên (tiền hoặc vật phẩm)",
    price: 5000, diamondPrice: 2, type: "gift",
  },
  hop_qua_lon: {
    id: "hop_qua_lon", name: "Hộp quà lớn", emoji: "🎀",
    description: "Chứa phần thưởng lớn ngẫu nhiên (tiền hoặc diamond)",
    price: 0, diamondPrice: 20, type: "gift",
  },
};

export const ITEM_LIST = Object.values(ITEMS);
export const SHOP_ITEMS = ITEM_LIST.filter(i => i.price > 0);
export const DIAMOND_ITEMS = ITEM_LIST.filter(i => i.diamondPrice > 0);
