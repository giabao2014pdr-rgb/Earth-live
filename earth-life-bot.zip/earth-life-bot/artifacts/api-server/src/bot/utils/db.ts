import { db } from "@workspace/db";
import { playersTable, type Player } from "@workspace/db";
import { eq } from "drizzle-orm";
import { calculateLevel } from "../constants/levels.js";

export function playerId(userId: string, guildId: string): string {
  return `${userId}_${guildId}`;
}

export async function getPlayer(userId: string, guildId: string): Promise<Player | null> {
  const pid = playerId(userId, guildId);
  const rows = await db.select().from(playersTable).where(eq(playersTable.id, pid)).limit(1);
  return rows[0] ?? null;
}

export async function getOrCreatePlayer(userId: string, guildId: string, name: string): Promise<Player> {
  let player = await getPlayer(userId, guildId);
  if (!player) {
    const pid = playerId(userId, guildId);
    const rows = await db
      .insert(playersTable)
      .values({ id: pid, userId, guildId, name })
      .returning();
    player = rows[0]!;
  }
  return player;
}

export async function updatePlayer(userId: string, guildId: string, data: Partial<Player>): Promise<Player> {
  const pid = playerId(userId, guildId);
  const rows = await db
    .update(playersTable)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(playersTable.id, pid))
    .returning();
  return rows[0]!;
}

export async function addExpAndMoney(
  player: Player,
  exp: number,
  money: number,
): Promise<{ player: Player; leveledUp: boolean; newLevel: number }> {
  const oldLevel = player.level;
  const newTotalExp = player.exp + exp;
  const { level: newLevel } = calculateLevel(newTotalExp);
  const newMoney = player.money + money;
  const updated = await updatePlayer(player.userId, player.guildId, {
    exp: newTotalExp,
    level: newLevel,
    money: newMoney,
    totalEarned: player.totalEarned + (money > 0 ? money : 0),
  });
  return { player: updated, leveledUp: newLevel > oldLevel, newLevel };
}

export function formatMoney(amount: number): string {
  return `${amount.toLocaleString("vi-VN")}₫`;
}

export function cooldownRemaining(lastTime: Date | null, cooldownHours: number): number {
  if (!lastTime) return 0;
  const cooldownMs = cooldownHours * 60 * 60 * 1000;
  const elapsed = Date.now() - lastTime.getTime();
  return Math.max(0, cooldownMs - elapsed);
}

export function formatCooldown(ms: number): string {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  if (hours > 0) return `${hours}g ${minutes % 60}p ${seconds % 60}s`;
  if (minutes > 0) return `${minutes}p ${seconds % 60}s`;
  return `${seconds}s`;
}
