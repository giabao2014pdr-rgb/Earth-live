import { EmbedBuilder, type ColorResolvable } from "discord.js";

export const COLORS = {
  primary: 0x5865f2 as ColorResolvable,
  success: 0x57f287 as ColorResolvable,
  warning: 0xfee75c as ColorResolvable,
  danger: 0xed4245 as ColorResolvable,
  info: 0x5865f2 as ColorResolvable,
  gold: 0xffd700 as ColorResolvable,
  dark: 0x2b2d31 as ColorResolvable,
};

export function successEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder().setColor(COLORS.success).setTitle(`✅ ${title}`).setDescription(description).setTimestamp();
}

export function errorEmbed(description: string): EmbedBuilder {
  return new EmbedBuilder().setColor(COLORS.danger).setTitle("❌ Lỗi").setDescription(description);
}

export function infoEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder().setColor(COLORS.primary).setTitle(title).setDescription(description).setTimestamp();
}

export function warningEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder().setColor(COLORS.warning).setTitle(`⚠️ ${title}`).setDescription(description);
}

export function goldEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder().setColor(COLORS.gold).setTitle(title).setDescription(description).setTimestamp();
}
