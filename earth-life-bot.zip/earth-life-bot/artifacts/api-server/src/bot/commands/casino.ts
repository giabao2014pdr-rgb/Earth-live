import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getPlayer, updatePlayer, formatMoney } from "../utils/db.js";
import { COLORS } from "../utils/embeds.js";

function rng() { return Math.random(); }

// ─── SLOTS ───────────────────────────────────────────────────────────────────
const SLOT_SYMBOLS = ["🍒", "🍋", "🍇", "🍊", "⭐", "💎", "7️⃣", "🃏"];
const SLOT_MULTIPLIERS: Record<string, number> = {
  "🍒": 2, "🍋": 3, "🍇": 4, "🍊": 5, "⭐": 10, "💎": 20, "7️⃣": 50, "🃏": 100,
};

export const slotsData = new SlashCommandBuilder()
  .setName("slots")
  .setDescription("🎰 Chơi máy đánh bạc")
  .addIntegerOption((opt) => opt.setName("cuoc").setDescription("Số tiền cược").setRequired(true).setMinValue(10));

export async function slotsExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const bet = interaction.options.getInteger("cuoc", true);
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }
  if (player.money < bet) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền! Bạn chỉ có **${formatMoney(player.money)}**`)] }); return; }

  const slots = [
    SLOT_SYMBOLS[Math.floor(rng() * SLOT_SYMBOLS.length)]!,
    SLOT_SYMBOLS[Math.floor(rng() * SLOT_SYMBOLS.length)]!,
    SLOT_SYMBOLS[Math.floor(rng() * SLOT_SYMBOLS.length)]!,
  ];

  let winnings = 0;
  let resultText = "";

  if (slots[0] === slots[1] && slots[1] === slots[2]) {
    const mult = SLOT_MULTIPLIERS[slots[0]!] ?? 2;
    winnings = bet * mult;
    resultText = `🎉 **JACKPOT!** Ba ${slots[0]} — Thắng **x${mult}**!`;
  } else if (slots[0] === slots[1] || slots[1] === slots[2] || slots[0] === slots[2]) {
    winnings = Math.floor(bet * 1.5);
    resultText = `✨ Hai giống nhau — Thắng **x1.5**!`;
  } else {
    winnings = 0;
    resultText = `💸 Không trúng — Thua **${formatMoney(bet)}**`;
  }

  const diff = winnings - bet;
  await updatePlayer(user.id, guildId, { money: player.money + diff });

  const embed = new EmbedBuilder()
    .setColor(winnings > 0 ? COLORS.success : COLORS.danger)
    .setTitle("🎰 Máy Đánh Bạc")
    .setDescription(`[ ${slots.join(" | ")} ]\n\n${resultText}`)
    .addFields(
      { name: "💰 Tiền cược", value: formatMoney(bet), inline: true },
      { name: winnings > 0 ? "🏆 Thắng" : "💸 Thua", value: formatMoney(Math.abs(diff)), inline: true },
      { name: "👛 Còn lại", value: formatMoney(player.money + diff), inline: true },
    );

  await interaction.editReply({ embeds: [embed] });
}

// ─── COIN FLIP ────────────────────────────────────────────────────────────────
export const coinflipData = new SlashCommandBuilder()
  .setName("coinflip")
  .setDescription("🪙 Tung xu")
  .addIntegerOption((opt) => opt.setName("cuoc").setDescription("Số tiền cược").setRequired(true).setMinValue(10))
  .addStringOption((opt) =>
    opt.setName("chon").setDescription("Sấp hay ngửa?").setRequired(true)
      .addChoices({ name: "🦅 Ngửa (Heads)", value: "heads" }, { name: "🌟 Sấp (Tails)", value: "tails" })
  );

export async function coinflipExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const bet = interaction.options.getInteger("cuoc", true);
  const choice = interaction.options.getString("chon", true);
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }
  if (player.money < bet) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền!`)] }); return; }

  const result = rng() < 0.5 ? "heads" : "tails";
  const won = choice === result;
  const diff = won ? bet : -bet;
  await updatePlayer(user.id, guildId, { money: player.money + diff });

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(won ? COLORS.success : COLORS.danger)
        .setTitle(`🪙 ${result === "heads" ? "🦅 Ngửa!" : "🌟 Sấp!"}`)
        .setDescription(`Bạn chọn: **${choice === "heads" ? "🦅 Ngửa" : "🌟 Sấp"}**\nKết quả: **${result === "heads" ? "🦅 Ngửa" : "🌟 Sấp"}**\n\n${won ? `🎉 **Thắng ${formatMoney(bet)}!**` : `💸 **Thua ${formatMoney(bet)}**`}`)
        .addFields({ name: "👛 Số dư", value: formatMoney(player.money + diff), inline: true }),
    ],
  });
}

// ─── BLACKJACK ───────────────────────────────────────────────────────────────
const CARD_VALUES = [2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11];
const CARD_NAMES = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
const SUITS = ["♠", "♥", "♦", "♣"];

function drawCard() {
  const idx = Math.floor(rng() * CARD_NAMES.length);
  const suit = SUITS[Math.floor(rng() * SUITS.length)]!;
  return { name: `${CARD_NAMES[idx]}${suit}`, value: CARD_VALUES[idx]! };
}

function handTotal(hand: { value: number }[]) {
  let total = hand.reduce((s, c) => s + c.value, 0);
  let aces = hand.filter((c) => c.value === 11).length;
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
}

export const blackjackData = new SlashCommandBuilder()
  .setName("blackjack")
  .setDescription("🃏 Chơi Blackjack")
  .addIntegerOption((opt) => opt.setName("cuoc").setDescription("Số tiền cược").setRequired(true).setMinValue(10));

export async function blackjackExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const bet = interaction.options.getInteger("cuoc", true);
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }
  if (player.money < bet) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền!`)] }); return; }

  const playerHand = [drawCard(), drawCard()];
  const dealerHand = [drawCard(), drawCard()];

  let playerTotal = handTotal(playerHand);
  let dealerTotal = handTotal(dealerHand);

  // Simple AI: dealer draws to 17
  while (dealerTotal < 17) {
    dealerHand.push(drawCard());
    dealerTotal = handTotal(dealerHand);
  }

  const playerBust = playerTotal > 21;
  const dealerBust = dealerTotal > 21;
  const playerBlackjack = playerTotal === 21 && playerHand.length === 2;
  const dealerBlackjack = dealerTotal === 21 && dealerHand.length === 2;

  let result: "win" | "loss" | "push";
  let diff = 0;

  if (playerBlackjack && !dealerBlackjack) { result = "win"; diff = Math.floor(bet * 1.5); }
  else if (dealerBlackjack && !playerBlackjack) { result = "loss"; diff = -bet; }
  else if (playerBust) { result = "loss"; diff = -bet; }
  else if (dealerBust) { result = "win"; diff = bet; }
  else if (playerTotal > dealerTotal) { result = "win"; diff = bet; }
  else if (dealerTotal > playerTotal) { result = "loss"; diff = -bet; }
  else { result = "push"; diff = 0; }

  await updatePlayer(user.id, guildId, { money: player.money + diff });

  const resultEmojis = { win: "🏆", loss: "💸", push: "🤝" };
  const resultTexts = {
    win: `🎉 **Bạn thắng ${formatMoney(Math.abs(diff))}!**${playerBlackjack ? " BLACKJACK! 🃏" : ""}`,
    loss: `💸 **Bạn thua ${formatMoney(Math.abs(diff))}**`,
    push: `🤝 **Hòa — Nhận lại tiền cược**`,
  };

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(result === "win" ? COLORS.success : result === "loss" ? COLORS.danger : COLORS.warning)
        .setTitle(`${resultEmojis[result]} Blackjack`)
        .addFields(
          { name: `🧑 Bạn (${playerTotal})`, value: playerHand.map((c) => c.name).join(" "), inline: true },
          { name: `🤖 Dealer (${dealerTotal})`, value: dealerHand.map((c) => c.name).join(" "), inline: true },
          { name: "📊 Kết quả", value: resultTexts[result], inline: false },
          { name: "👛 Số dư", value: formatMoney(player.money + diff), inline: true },
        ),
    ],
  });
}

// ─── ROULETTE ─────────────────────────────────────────────────────────────────
export const rouletteData = new SlashCommandBuilder()
  .setName("roulette")
  .setDescription("🎡 Chơi Roulette")
  .addIntegerOption((opt) => opt.setName("cuoc").setDescription("Số tiền cược").setRequired(true).setMinValue(10))
  .addStringOption((opt) =>
    opt.setName("chon").setDescription("Lựa chọn").setRequired(true)
      .addChoices(
        { name: "🔴 Đỏ (x2)", value: "red" },
        { name: "⚫ Đen (x2)", value: "black" },
        { name: "🟢 Số 0 (x35)", value: "zero" },
        { name: "1️⃣ Số lẻ (x2)", value: "odd" },
        { name: "2️⃣ Số chẵn (x2)", value: "even" },
      )
  );

export async function rouletteExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const bet = interaction.options.getInteger("cuoc", true);
  const choice = interaction.options.getString("chon", true);
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }
  if (player.money < bet) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền!`)] }); return; }

  const number = Math.floor(rng() * 37); // 0-36
  const isRed = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(number);
  const isZero = number === 0;

  let won = false;
  let multiplier = 0;

  if (choice === "zero" && isZero) { won = true; multiplier = 35; }
  else if (choice === "red" && isRed && !isZero) { won = true; multiplier = 1; }
  else if (choice === "black" && !isRed && !isZero) { won = true; multiplier = 1; }
  else if (choice === "odd" && number % 2 === 1 && !isZero) { won = true; multiplier = 1; }
  else if (choice === "even" && number % 2 === 0 && !isZero) { won = true; multiplier = 1; }

  const diff = won ? bet * multiplier : -bet;
  await updatePlayer(user.id, guildId, { money: player.money + diff });

  const numColor = isZero ? "🟢" : isRed ? "🔴" : "⚫";

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(won ? COLORS.success : COLORS.danger)
        .setTitle("🎡 Roulette")
        .setDescription(`Bóng dừng tại: ${numColor} **${number}**\n\n${won ? `🎉 **Thắng ${formatMoney(bet * multiplier)}!**` : `💸 **Thua ${formatMoney(bet)}**`}`)
        .addFields({ name: "👛 Số dư", value: formatMoney(player.money + diff), inline: true }),
    ],
  });
}

// ─── HORSE RACE ───────────────────────────────────────────────────────────────
const HORSES = [
  { name: "Thunder", emoji: "⚡", odds: 2, speed: 0.4 },
  { name: "Shadow", emoji: "🌑", odds: 3, speed: 0.3 },
  { name: "Lucky", emoji: "🍀", odds: 5, speed: 0.2 },
  { name: "Storm", emoji: "🌪️", odds: 8, speed: 0.07 },
  { name: "Golden", emoji: "🌟", odds: 15, speed: 0.03 },
];

export const raceData = new SlashCommandBuilder()
  .setName("race")
  .setDescription("🏇 Cá cược đua ngựa")
  .addIntegerOption((opt) => opt.setName("cuoc").setDescription("Số tiền cược").setRequired(true).setMinValue(10))
  .addStringOption((opt) =>
    opt.setName("ngua").setDescription("Chọn ngựa").setRequired(true)
      .addChoices(...HORSES.map((h) => ({ name: `${h.emoji} ${h.name} (x${h.odds})`, value: h.name })))
  );

export async function raceExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const bet = interaction.options.getInteger("cuoc", true);
  const horseName = interaction.options.getString("ngua", true);
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }
  if (player.money < bet) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền!`)] }); return; }

  // Simulate race
  const scores = HORSES.map((h) => ({ ...h, score: rng() * h.speed + rng() * 0.1 }));
  scores.sort((a, b) => b.score - a.score);
  const winner = scores[0]!;

  const chosen = HORSES.find((h) => h.name === horseName)!;
  const won = winner.name === horseName;
  const diff = won ? bet * chosen.odds : -bet;
  await updatePlayer(user.id, guildId, { money: player.money + diff });

  const raceAnimation = scores.map((h, i) => {
    const bar = "🏃".repeat(3 - i) + "─".repeat(i * 2);
    return `${i + 1}. ${h.emoji} ${h.name} ${"─".repeat(10 - i * 2)}🏁`;
  }).join("\n");

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(won ? COLORS.success : COLORS.danger)
        .setTitle("🏇 Đua ngựa!")
        .setDescription(raceAnimation)
        .addFields(
          { name: "🏆 Người chiến thắng", value: `${winner.emoji} **${winner.name}**`, inline: true },
          { name: "🐎 Ngựa bạn chọn", value: `${chosen.emoji} **${chosen.name}**`, inline: true },
          { name: "📊 Kết quả", value: won ? `🎉 **Thắng ${formatMoney(bet * chosen.odds)}!**` : `💸 **Thua ${formatMoney(bet)}**`, inline: false },
          { name: "👛 Số dư", value: formatMoney(player.money + diff), inline: true },
        ),
    ],
  });
}
