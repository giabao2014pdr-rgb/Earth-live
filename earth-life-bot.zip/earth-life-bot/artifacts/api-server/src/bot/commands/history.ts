import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import { db } from "@workspace/db";
import { activityLogsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { getPlayer, formatMoney, playerId } from "../utils/db.js";
import { COLORS, errorEmbed } from "../utils/embeds.js";

export const historyData = new SlashCommandBuilder()
  .setName("history")
  .setDescription("📜 Xem lịch sử hoạt động của bạn")
  .addStringOption(o =>
    o.setName("loai").setDescription("Lọc theo loại hoạt động").setRequired(false)
      .addChoices(
        { name: "Tất cả", value: "all" },
        { name: "💼 Làm việc", value: "work" },
        { name: "🎰 Casino", value: "casino" },
        { name: "🌍 Khám phá", value: "explore" },
        { name: "📈 Đầu tư", value: "invest" },
        { name: "🏪 Cửa hàng", value: "shop" },
        { name: "🏦 Ngân hàng", value: "bank" },
      )
  );

export async function historyExecute(interaction: ChatInputCommandInteraction) {
  const loai = interaction.options.getString("loai") ?? "all";
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký!")], ephemeral: true });

  const pid = playerId(interaction.user.id, interaction.guildId!);

  let query = db.select().from(activityLogsTable)
    .where(eq(activityLogsTable.playerId, pid))
    .orderBy(desc(activityLogsTable.createdAt))
    .limit(20);

  const logs = await query;
  const filtered = loai === "all" ? logs : logs.filter(l => l.action === loai);

  if (filtered.length === 0) {
    return interaction.reply({
      embeds: [new EmbedBuilder().setColor(COLORS.info).setTitle("📜 Lịch Sử Hoạt Động").setDescription("Chưa có hoạt động nào được ghi lại.\n\nHãy đi làm, khám phá, hoặc chơi casino!").setFooter({ text: interaction.user.username })],
    });
  }

  const lines = filtered.map(log => {
    const ts = Math.floor(new Date(log.createdAt).getTime() / 1000);
    const amountStr = log.amount > 0
      ? `+${formatMoney(log.amount)}`
      : log.amount < 0
        ? formatMoney(log.amount)
        : "";
    const actionEmoji: Record<string, string> = {
      work: "💼", casino: "🎰", explore: "🌍", invest: "📈",
      shop: "🏪", bank: "🏦", daily: "🎁", health: "🏥",
    };
    const emoji = actionEmoji[log.action] ?? "📝";
    return `${emoji} <t:${ts}:R>\n   ${log.description}${amountStr ? ` — **${amountStr}**` : ""}`;
  });

  const embed = new EmbedBuilder()
    .setColor(COLORS.info)
    .setTitle(`📜 Lịch Sử — ${interaction.user.username}`)
    .setDescription(lines.join("\n\n"))
    .setFooter({ text: `Hiển thị ${filtered.length} hoạt động gần nhất | Lọc: ${loai}` });

  return interaction.reply({ embeds: [embed] });
}
