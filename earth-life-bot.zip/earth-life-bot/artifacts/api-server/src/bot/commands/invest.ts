import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import { db } from "@workspace/db";
import { stocksTable, activityLogsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getPlayer, updatePlayer, formatMoney, playerId } from "../utils/db.js";
import { COLORS, errorEmbed } from "../utils/embeds.js";

// Initial stock data (seeded on first use)
const INITIAL_STOCKS = [
  { id: "TECH", name: "Công nghệ VN Tech", price: 50000 },
  { id: "AGRI", name: "Nông nghiệp Xanh", price: 20000 },
  { id: "BANK", name: "Ngân hàng Đất Việt", price: 80000 },
  { id: "ENERGY", name: "Năng lượng Mặt Trời", price: 35000 },
  { id: "GAME", name: "Game Studio VN", price: 15000 },
  { id: "REAL", name: "Bất động sản Phú Quý", price: 120000 },
];

async function ensureStocks() {
  for (const s of INITIAL_STOCKS) {
    const [existing] = await db.select().from(stocksTable).where(eq(stocksTable.id, s.id)).limit(1);
    if (!existing) {
      await db.insert(stocksTable).values({ id: s.id, name: s.name, price: s.price, change: 0 });
    }
  }
}

async function fluctuateStocks() {
  const stocks = await db.select().from(stocksTable);
  for (const stock of stocks) {
    const change = (Math.random() - 0.48) * 10; // slightly biased upward
    const newPrice = Math.max(1000, Math.floor(stock.price * (1 + change / 100)));
    await db.update(stocksTable).set({
      price: newPrice,
      change: Math.round(change * 10) / 10,
      updatedAt: new Date(),
    }).where(eq(stocksTable.id, stock.id));
  }
}

export const investData = new SlashCommandBuilder()
  .setName("invest")
  .setDescription("📈 Hệ thống đầu tư chứng khoán")
  .addStringOption(o => o.setName("hanh_dong").setDescription("Hành động").setRequired(true)
    .addChoices(
      { name: "📊 Xem thị trường", value: "xem" },
      { name: "💰 Mua cổ phiếu", value: "mua" },
      { name: "💸 Bán cổ phiếu", value: "ban" },
      { name: "📁 Danh mục đầu tư", value: "danhmuc" },
    ))
  .addStringOption(o => o.setName("co_phieu").setDescription("Mã cổ phiếu (ví dụ: TECH)").setRequired(false))
  .addIntegerOption(o => o.setName("so_luong").setDescription("Số cổ phiếu").setMinValue(1).setRequired(false));

export async function investExecute(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply();

  const action = interaction.options.getString("hanh_dong", true);
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.editReply({ embeds: [errorEmbed("Bạn chưa đăng ký!")] });
  if (!player.isAlive) return interaction.editReply({ embeds: [errorEmbed("Bạn đã tử vong!")] });

  await ensureStocks();

  const pid = playerId(interaction.user.id, interaction.guildId!);

  if (action === "xem") {
    // Fluctuate prices on view (simulates market movement)
    if (Math.random() < 0.3) await fluctuateStocks();

    const stocks = await db.select().from(stocksTable);
    const lines = stocks.map(s => {
      const arrow = s.change > 0 ? "📈" : s.change < 0 ? "📉" : "➡️";
      const changeStr = s.change > 0 ? `+${s.change}%` : `${s.change}%`;
      return `${arrow} **${s.id}** — ${s.name}\n   💵 ${formatMoney(s.price)}/cổ | ${changeStr}`;
    });
    const embed = new EmbedBuilder()
      .setColor(COLORS.info)
      .setTitle("📊 Thị Trường Chứng Khoán")
      .setDescription(lines.join("\n\n"))
      .setFooter({ text: "Dùng /dautu hanh_dong:mua co_phieu:<MÃ> so_luong:<SỐ> để mua" });
    return interaction.editReply({ embeds: [embed] });
  }

  if (action === "danhmuc") {
    const portfolio = player.stockPortfolio ?? {};
    if (Object.keys(portfolio).length === 0) {
      return interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.info).setTitle("📁 Danh Mục Đầu Tư").setDescription("Bạn chưa có cổ phiếu nào!\nDùng `/dautu hanh_dong:mua` để bắt đầu đầu tư.")] });
    }
    const stocks = await db.select().from(stocksTable);
    const stockMap: Record<string, number> = {};
    for (const s of stocks) stockMap[s.id] = s.price;

    let totalValue = 0;
    const lines = Object.entries(portfolio).map(([id, qty]) => {
      const price = stockMap[id] ?? 0;
      const val = price * qty;
      totalValue += val;
      return `**${id}** × ${qty} cổ — ${formatMoney(val)}`;
    });

    const embed = new EmbedBuilder()
      .setColor(COLORS.gold)
      .setTitle("📁 Danh Mục Đầu Tư")
      .setDescription(lines.join("\n"))
      .addFields(
        { name: "💰 Tổng giá trị", value: formatMoney(totalValue), inline: true },
        { name: "💵 Tiền mặt", value: formatMoney(player.money), inline: true },
      );
    return interaction.editReply({ embeds: [embed] });
  }

  const stockId = (interaction.options.getString("co_phieu") ?? "").toUpperCase();
  const qty = interaction.options.getInteger("so_luong") ?? 1;
  if (!stockId) return interaction.editReply({ embeds: [errorEmbed("Vui lòng nhập mã cổ phiếu!")] });

  const [stock] = await db.select().from(stocksTable).where(eq(stocksTable.id, stockId)).limit(1);
  if (!stock) return interaction.editReply({ embeds: [errorEmbed(`Mã cổ phiếu **${stockId}** không tồn tại!\nXem danh sách: /dautu hanh_dong:xem`)] });

  const portfolio = { ...(player.stockPortfolio ?? {}) };

  if (action === "mua") {
    const totalCost = stock.price * qty;
    if (player.money < totalCost) {
      return interaction.editReply({ embeds: [errorEmbed(`Không đủ tiền!\nCần: ${formatMoney(totalCost)}\nBạn có: ${formatMoney(player.money)}`)] });
    }
    portfolio[stockId] = (portfolio[stockId] ?? 0) + qty;
    await updatePlayer(player.userId, player.guildId, { money: player.money - totalCost, stockPortfolio: portfolio });
    await db.insert(activityLogsTable).values({ playerId: pid, action: "invest", description: `Mua ${qty} cổ ${stockId} @ ${formatMoney(stock.price)}`, amount: -totalCost });

    const embed = new EmbedBuilder()
      .setColor(COLORS.success)
      .setTitle("✅ Mua Cổ Phiếu Thành Công")
      .addFields(
        { name: "📈 Mã", value: stockId, inline: true },
        { name: "🔢 Số lượng", value: String(qty), inline: true },
        { name: "💵 Tổng chi", value: formatMoney(totalCost), inline: true },
        { name: "📊 Hiện có", value: `${portfolio[stockId]} cổ ${stockId}`, inline: true },
        { name: "💰 Số dư còn", value: formatMoney(player.money - totalCost), inline: true },
      );
    return interaction.editReply({ embeds: [embed] });
  }

  if (action === "ban") {
    const owned = portfolio[stockId] ?? 0;
    if (owned < qty) {
      return interaction.editReply({ embeds: [errorEmbed(`Bạn chỉ có ${owned} cổ **${stockId}**, không thể bán ${qty} cổ!`)] });
    }
    const totalValue = stock.price * qty;
    if (owned - qty === 0) delete portfolio[stockId];
    else portfolio[stockId] = owned - qty;

    await updatePlayer(player.userId, player.guildId, {
      money: player.money + totalValue,
      totalEarned: player.totalEarned + totalValue,
      stockPortfolio: portfolio,
    });
    await db.insert(activityLogsTable).values({ playerId: pid, action: "invest", description: `Bán ${qty} cổ ${stockId} @ ${formatMoney(stock.price)}`, amount: totalValue });

    const embed = new EmbedBuilder()
      .setColor(COLORS.success)
      .setTitle("✅ Bán Cổ Phiếu Thành Công")
      .addFields(
        { name: "📉 Mã", value: stockId, inline: true },
        { name: "🔢 Số lượng", value: String(qty), inline: true },
        { name: "💵 Thu về", value: formatMoney(totalValue), inline: true },
        { name: "📊 Còn lại", value: `${portfolio[stockId] ?? 0} cổ ${stockId}`, inline: true },
        { name: "💰 Số dư mới", value: formatMoney(player.money + totalValue), inline: true },
      );
    return interaction.editReply({ embeds: [embed] });
  }

  return interaction.editReply({ embeds: [errorEmbed("Hành động không hợp lệ!")] });
}
