import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getPlayer, getOrCreatePlayer } from "../utils/db.js";
import { COLORS } from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
  .setName("register")
  .setDescription("Đăng ký tài khoản nhân vật của bạn");

export async function execute(interaction: ChatInputCommandInteraction) {
  const guildId = interaction.guildId!;
  const user = interaction.user;

  await interaction.deferReply({ ephemeral: false });

  const existing = await getPlayer(user.id, guildId);
  if (existing) {
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.warning)
          .setDescription("⚠️ Bạn đã đăng ký rồi! Dùng `/profile` để xem hồ sơ."),
      ],
    });
    return;
  }

  await getOrCreatePlayer(user.id, guildId, user.displayName);

  // Embed 1 — Chào mừng + Giới thiệu tổng quan
  const embed1 = new EmbedBuilder()
    .setColor(0x00bfff)
    .setTitle("🌍 Earth Life - Discord RPG (FULL VERSION)")
    .setThumbnail(user.displayAvatarURL())
    .setDescription(
      `Chào mừng **${user.displayName}** đến với **Earth Life**!\n\n` +
      `Earth Life là game mô phỏng cuộc sống trên Discord. Người chơi bắt đầu từ con số 0, làm việc, kiếm tiền, sở hữu tài sản, vượt qua bệnh tật và xây dựng vị trí của mình trong xã hội.\n\n` +
      `🪙 Tiền khởi đầu: **1,000$**\n` +
      `⭐ Cấp độ: **1 / 1000**\n` +
      `📍 Vị trí: **Thành phố**`
    );

  // Embed 2 — Nhân vật & Nghề nghiệp
  const embed2 = new EmbedBuilder()
    .setColor(0x7289da)
    .setTitle("👤 Hệ thống nhân vật & 💼 Nghề nghiệp")
    .addFields(
      {
        name: "👤 Nhân vật",
        value:
          "• Hồ sơ cá nhân\n" +
          "• Level tối đa: **1000** | EXP & Danh hiệu\n" +
          "• Chỉ số nhân vật\n" +
          "• Lịch sử hoạt động\n" +
          "• Xếp hạng người chơi",
        inline: true,
      },
      {
        name: "💼 15 Nghề nghiệp",
        value:
          "🌾 Nông dân • 🔧 Công nhân • 🚗 Tài xế\n" +
          "🍳 Đầu bếp • ⚙️ Thợ máy • 📚 Giáo viên\n" +
          "👮 Cảnh sát • 🩺 Bác sĩ • 💻 Lập trình viên\n" +
          "⚖️ Luật sư • 💼 Doanh nhân • 🎮 Streamer\n" +
          "🏗️ Thợ xây • 🎣 Ngư dân • ✈️ Phi công\n\n" +
          "*Mỗi nghề: cấp nghề, lương, EXP, nhiệm vụ*",
        inline: true,
      }
    );

  // Embed 3 — Kinh tế & Tài sản
  const embed3 = new EmbedBuilder()
    .setColor(0xf1c40f)
    .setTitle("💰 Kinh tế & 🏠 Tài sản")
    .addFields(
      {
        name: "💰 Hệ thống kinh tế",
        value:
          "💵 Tiền mặt & 🏦 Ngân hàng\n" +
          "• Gửi/Rút/Vay/Trả nợ/Lãi/Thuế\n" +
          "• Chuyển tiền giữa người chơi\n" +
          "• Cửa hàng & Đầu tư chứng khoán",
        inline: true,
      },
      {
        name: "🏠 Nhà & 🚗 Xe",
        value:
          "**Nhà:** Nhỏ → Thường → Cao cấp → Biệt thự → Penthouse → Đảo riêng\n" +
          "**Xe:** Xe máy → Ô tô → Thể thao → Siêu xe → Xe giới hạn\n" +
          "*(Mua, Bán, Nâng cấp)*",
        inline: true,
      }
    );

  // Embed 4 — Casino & Bệnh viện & Vật phẩm
  const embed4 = new EmbedBuilder()
    .setColor(0xe74c3c)
    .setTitle("🎰 Casino & 🏥 Bệnh viện & 🎒 Vật phẩm")
    .addFields(
      {
        name: "🎰 Casino (6 trò chơi)",
        value:
          "🎰 Slots • 🃏 Blackjack • ♠️ Poker\n" +
          "🎡 Roulette • 🎲 Xúc xắc • 🎟️ Vé số\n" +
          "*May mắn, chuỗi thắng/thua, BXH casino*",
        inline: true,
      },
      {
        name: "🏥 Bệnh viện (30 bệnh)",
        value:
          "🟢 Bệnh nhẹ | 🟡 Trung bình | 🔴 Nặng\n" +
          "• Khám, mua thuốc, điều trị, cấp cứu\n" +
          "*Có tỷ lệ thành công & nguy cơ tử vong*",
        inline: true,
      },
      {
        name: "🎒 Vật phẩm",
        value:
          "💊 Thuốc | 🎟️ Vé casino | 🎫 Vé số\n" +
          "🔑 Chìa khóa nhà/xe | 🎁 Hộp quà\n" +
          "✨ Vật phẩm sự kiện đặc biệt",
        inline: false,
      }
    );

  // Embed 5 — Premium, Sự kiện, Thành tựu, Mục tiêu
  const embed5 = new EmbedBuilder()
    .setColor(0x9b59b6)
    .setTitle("💎 Premium & 🎁 Sự kiện & 🏆 Thành tựu")
    .addFields(
      {
        name: "💎 VIP & Kim cương",
        value:
          "🥉 Bronze | 🥈 Silver | 🥇 Gold | 💎 Diamond\n" +
          "• Quà hằng ngày, huy hiệu, ưu đãi riêng\n" +
          "• X2 EXP/tiền, tăng may mắn, giảm thời gian chờ\n" +
          "• Lãi suất & hạn mức vay cao hơn",
        inline: true,
      },
      {
        name: "🎁 Sự kiện & 🏆 Thành tựu",
        value:
          "📅 Điểm danh hằng ngày | Quà tuần/tháng\n" +
          "🎊 Tết | 🎄 Noel | 🎃 Halloween | 🎂 Sinh nhật bot\n\n" +
          "🏆 Thành tựu: kiếm tiền, lên level, mua nhà/xe,\n thắng casino, chữa bệnh nặng, đạt mốc tài sản",
        inline: true,
      },
      {
        name: "🎯 Mục tiêu cuối game",
        value:
          "⭐ Đạt **Level 1000**\n" +
          "💰 Kiếm **1,000,000,000$** (1 tỷ)\n" +
          "🏠 Sở hữu tài sản lớn nhất\n" +
          "🚗 Sưu tầm xe hiếm\n" +
          "🏆 Trở thành người đứng đầu máy chủ Discord",
        inline: false,
      }
    );

  // Embed 6 — Lệnh nhanh để bắt đầu
  const embed6 = new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle("🚀 Bắt đầu ngay!")
    .setDescription(
      "`/work` — Đi làm kiếm tiền\n" +
      "`/job` — Chọn & đổi nghề nghiệp\n" +
      "`/profile` — Xem hồ sơ cá nhân\n" +
      "`/shop` — Mua vật phẩm\n" +
      "`/explore` — Khám phá thế giới\n" +
      "`/slots` `/coinflip` `/blackjack` — Thử vận may\n" +
      "`/health` — Kiểm tra sức khỏe\n" +
      "`/leaderboard` — Xem bảng xếp hạng\n" +
      "`/daily` — Nhận thưởng hằng ngày"
    )
    .setFooter({ text: "Earth Life • Chúc bạn may mắn và thành công! 🌟" });

  await interaction.editReply({
    embeds: [embed1, embed2, embed3, embed4, embed5, embed6],
  });
}
