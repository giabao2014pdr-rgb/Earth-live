import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import { db } from "@workspace/db";
import { playersTable, giftCodesTable } from "@workspace/db";
import { eq, like } from "drizzle-orm";
import { getPlayer, updatePlayer, formatMoney, playerId } from "../utils/db.js";
import { COLORS, errorEmbed, successEmbed } from "../utils/embeds.js";
import { calculateLevel } from "../constants/levels.js";

export const adminData = new SlashCommandBuilder()
  .setName("admin")
  .setDescription("🛡️ Lệnh quản trị (chỉ Admin server)")
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  // ─── Người chơi ────────────────────────────────────────────
  .addSubcommandGroup(grp => grp.setName("nguoichoi").setDescription("Quản lý người chơi")
    .addSubcommand(sub => sub.setName("xem").setDescription("Xem dữ liệu người chơi")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true)))
    .addSubcommand(sub => sub.setName("reset").setDescription("Reset tài khoản người chơi về mặc định")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true)))
    .addSubcommand(sub => sub.setName("ban").setDescription("Khóa tài khoản người chơi")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true)))
    .addSubcommand(sub => sub.setName("unban").setDescription("Mở khóa tài khoản người chơi")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true)))
  )
  // ─── Tiền ──────────────────────────────────────────────────
  .addSubcommandGroup(grp => grp.setName("tien").setDescription("Quản lý tiền người chơi")
    .addSubcommand(sub => sub.setName("them").setDescription("Thêm tiền cho người chơi")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true))
      .addIntegerOption(o => o.setName("so_tien").setDescription("Số tiền").setRequired(true).setMinValue(1)))
    .addSubcommand(sub => sub.setName("tru").setDescription("Trừ tiền của người chơi")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true))
      .addIntegerOption(o => o.setName("so_tien").setDescription("Số tiền").setRequired(true).setMinValue(1)))
    .addSubcommand(sub => sub.setName("dat").setDescription("Đặt số tiền của người chơi")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true))
      .addIntegerOption(o => o.setName("so_tien").setDescription("Số tiền").setRequired(true).setMinValue(0)))
  )
  // ─── Level ─────────────────────────────────────────────────
  .addSubcommandGroup(grp => grp.setName("level").setDescription("Quản lý cấp độ người chơi")
    .addSubcommand(sub => sub.setName("them_exp").setDescription("Thêm EXP cho người chơi")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true))
      .addIntegerOption(o => o.setName("exp").setDescription("Số EXP").setRequired(true).setMinValue(1)))
    .addSubcommand(sub => sub.setName("dat_level").setDescription("Đặt level người chơi")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true))
      .addIntegerOption(o => o.setName("level").setDescription("Level (1-1000)").setRequired(true).setMinValue(1).setMaxValue(1000)))
    .addSubcommand(sub => sub.setName("max").setDescription("Đặt người chơi lên level tối đa (1000)")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true)))
  )
  // ─── Kim cương ─────────────────────────────────────────────
  .addSubcommandGroup(grp => grp.setName("kimcuong").setDescription("Quản lý kim cương")
    .addSubcommand(sub => sub.setName("them").setDescription("Thêm kim cương cho người chơi")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true))
      .addIntegerOption(o => o.setName("so_luong").setDescription("Số lượng kim cương").setRequired(true).setMinValue(1)))
    .addSubcommand(sub => sub.setName("tru").setDescription("Trừ kim cương của người chơi")
      .addUserOption(o => o.setName("nguoi_dung").setDescription("Người dùng").setRequired(true))
      .addIntegerOption(o => o.setName("so_luong").setDescription("Số lượng kim cương").setRequired(true).setMinValue(1)))
  )
  // ─── Gift Code ─────────────────────────────────────────────
  .addSubcommandGroup(grp => grp.setName("giftcode").setDescription("Tạo gift code")
    .addSubcommand(sub => sub.setName("tao").setDescription("Tạo gift code mới")
      .addStringOption(o => o.setName("code").setDescription("Mã code (để trống = tự tạo)").setRequired(false))
      .addIntegerOption(o => o.setName("tien").setDescription("Tiền thưởng").setMinValue(0))
      .addIntegerOption(o => o.setName("exp").setDescription("EXP thưởng").setMinValue(0))
      .addIntegerOption(o => o.setName("kimcuong").setDescription("Kim cương thưởng").setMinValue(0))
      .addIntegerOption(o => o.setName("max_luot").setDescription("Số lượt dùng tối đa").setMinValue(1).setMaxValue(10000))
      .addIntegerOption(o => o.setName("han_ngay").setDescription("Hạn sử dụng (ngày)").setMinValue(1))
    )
    .addSubcommand(sub => sub.setName("xem").setDescription("Xem danh sách gift code"))
    .addSubcommand(sub => sub.setName("xoa").setDescription("Xóa gift code")
      .addStringOption(o => o.setName("code").setDescription("Mã code cần xóa").setRequired(true)))
  );

export async function adminExecute(interaction: ChatInputCommandInteraction) {
  // Double-check permissions
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
    return interaction.reply({ embeds: [errorEmbed("❌ Bạn không có quyền Admin!")], ephemeral: true });
  }

  const group = interaction.options.getSubcommandGroup();
  const sub = interaction.options.getSubcommand();

  // ─── Người chơi ─────────────────────────────────────────────
  if (group === "nguoichoi") {
    const target = interaction.options.getUser("nguoi_dung", true);
    const pid = playerId(target.id, interaction.guildId!);
    const player = await getPlayer(target.id, interaction.guildId!);

    if (sub === "xem") {
      if (!player) return interaction.reply({ embeds: [errorEmbed("Người chơi này chưa đăng ký!")], ephemeral: true });
      const embed = new EmbedBuilder()
        .setColor(COLORS.info)
        .setTitle(`📋 Dữ liệu: ${target.username}`)
        .addFields(
          { name: "Level", value: String(player.level), inline: true },
          { name: "EXP", value: String(player.exp), inline: true },
          { name: "💵 Tiền mặt", value: formatMoney(player.money), inline: true },
          { name: "🏦 Ngân hàng", value: formatMoney(player.bank), inline: true },
          { name: "💎 Kim cương", value: String(player.diamonds), inline: true },
          { name: "❤️ Máu", value: String(player.health), inline: true },
          { name: "⚡ Năng lượng", value: String(player.energy), inline: true },
          { name: "💔 Nợ", value: formatMoney(player.loanAmount), inline: true },
          { name: "🏠 Nhà", value: String(player.houseLevel), inline: true },
          { name: "🚗 Xe", value: String(player.carLevel), inline: true },
          { name: "💍 Hôn nhân", value: player.spouseId ? "Đã kết hôn" : "Độc thân", inline: true },
          { name: "👶 Con cái", value: String(player.children), inline: true },
          { name: "🎖️ VIP", value: String(player.vipTier), inline: true },
          { name: "🏢 Nghề", value: player.job, inline: true },
          { name: "✅ Còn sống", value: player.isAlive ? "Có" : "Không", inline: true },
        )
        .setThumbnail(target.displayAvatarURL())
        .setFooter({ text: `ID: ${pid}` });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === "reset") {
      if (!player) return interaction.reply({ embeds: [errorEmbed("Người chơi này chưa đăng ký!")], ephemeral: true });
      await updatePlayer(target.id, interaction.guildId!, {
        level: 1, exp: 0, money: 1000, bank: 0, job: "unemployed", health: 100, energy: 100,
        happiness: 100, spouseId: null as any, children: 0, houseLevel: 0, carLevel: 0,
        isAlive: true, loanAmount: 0, diamonds: 0, vipTier: 0, casinoWins: 0, casinoLosses: 0, workedTotal: 0,
      });
      return interaction.reply({ embeds: [successEmbed(`✅ Đã reset tài khoản của **${target.username}**!`)], ephemeral: true });
    }

    if (sub === "ban") {
      if (!player) return interaction.reply({ embeds: [errorEmbed("Người chơi này chưa đăng ký!")], ephemeral: true });
      await updatePlayer(target.id, interaction.guildId!, { isAlive: false });
      return interaction.reply({ embeds: [successEmbed(`🔒 Đã khóa tài khoản **${target.username}**!`)], ephemeral: true });
    }

    if (sub === "unban") {
      if (!player) return interaction.reply({ embeds: [errorEmbed("Người chơi này chưa đăng ký!")], ephemeral: true });
      await updatePlayer(target.id, interaction.guildId!, { isAlive: true, health: 50 });
      return interaction.reply({ embeds: [successEmbed(`🔓 Đã mở khóa tài khoản **${target.username}**!`)], ephemeral: true });
    }
  }

  // ─── Tiền ────────────────────────────────────────────────────
  if (group === "tien") {
    const target = interaction.options.getUser("nguoi_dung", true);
    const amount = interaction.options.getInteger("so_tien", true);
    const player = await getPlayer(target.id, interaction.guildId!);
    if (!player) return interaction.reply({ embeds: [errorEmbed("Người chơi này chưa đăng ký!")], ephemeral: true });

    if (sub === "them") {
      await updatePlayer(target.id, interaction.guildId!, { money: player.money + amount });
      return interaction.reply({ embeds: [successEmbed(`✅ Đã thêm **${formatMoney(amount)}** cho **${target.username}**`)], ephemeral: true });
    }
    if (sub === "tru") {
      await updatePlayer(target.id, interaction.guildId!, { money: Math.max(0, player.money - amount) });
      return interaction.reply({ embeds: [successEmbed(`✅ Đã trừ **${formatMoney(amount)}** của **${target.username}**`)], ephemeral: true });
    }
    if (sub === "dat") {
      await updatePlayer(target.id, interaction.guildId!, { money: amount });
      return interaction.reply({ embeds: [successEmbed(`✅ Đã đặt tiền của **${target.username}** = **${formatMoney(amount)}**`)], ephemeral: true });
    }
  }

  // ─── Level ────────────────────────────────────────────────────
  if (group === "level") {
    const target = interaction.options.getUser("nguoi_dung", true);
    const player = await getPlayer(target.id, interaction.guildId!);
    if (!player) return interaction.reply({ embeds: [errorEmbed("Người chơi này chưa đăng ký!")], ephemeral: true });

    if (sub === "them_exp") {
      const expAmt = interaction.options.getInteger("exp", true);
      const newExp = player.exp + expAmt;
      const { level } = calculateLevel(newExp);
      await updatePlayer(target.id, interaction.guildId!, { exp: newExp, level });
      return interaction.reply({ embeds: [successEmbed(`✅ Đã thêm **${expAmt} EXP** cho **${target.username}** (Level ${level})`)], ephemeral: true });
    }
    if (sub === "dat_level" || sub === "max") {
      const targetLevel = sub === "max" ? 1000 : interaction.options.getInteger("level", true);
      const { totalExpForLevel } = await import("../constants/levels.js");
      const neededExp = totalExpForLevel(targetLevel);
      await updatePlayer(target.id, interaction.guildId!, { level: targetLevel, exp: neededExp });
      return interaction.reply({ embeds: [successEmbed(`✅ Đã đặt level của **${target.username}** = **${targetLevel}**`)], ephemeral: true });
    }
  }

  // ─── Kim cương ────────────────────────────────────────────────
  if (group === "kimcuong") {
    const target = interaction.options.getUser("nguoi_dung", true);
    const amount = interaction.options.getInteger("so_luong", true);
    const player = await getPlayer(target.id, interaction.guildId!);
    if (!player) return interaction.reply({ embeds: [errorEmbed("Người chơi này chưa đăng ký!")], ephemeral: true });

    if (sub === "them") {
      await updatePlayer(target.id, interaction.guildId!, { diamonds: player.diamonds + amount });
      return interaction.reply({ embeds: [successEmbed(`✅ Đã thêm **${amount}💎** cho **${target.username}**`)], ephemeral: true });
    }
    if (sub === "tru") {
      await updatePlayer(target.id, interaction.guildId!, { diamonds: Math.max(0, player.diamonds - amount) });
      return interaction.reply({ embeds: [successEmbed(`✅ Đã trừ **${amount}💎** của **${target.username}**`)], ephemeral: true });
    }
  }

  // ─── Gift Code ────────────────────────────────────────────────
  if (group === "giftcode") {
    if (sub === "tao") {
      const code = interaction.options.getString("code") ?? randomCode();
      const money = interaction.options.getInteger("tien") ?? 0;
      const exp = interaction.options.getInteger("exp") ?? 0;
      const diamonds = interaction.options.getInteger("kimcuong") ?? 0;
      const maxUses = interaction.options.getInteger("max_luot") ?? 1;
      const hanNgay = interaction.options.getInteger("han_ngay");
      const expiresAt = hanNgay ? new Date(Date.now() + hanNgay * 24 * 60 * 60 * 1000) : null;

      try {
        await db.insert(giftCodesTable).values({
          code: code.toUpperCase(),
          rewardsJson: { money: money || undefined, exp: exp || undefined, diamonds: diamonds || undefined },
          maxUses,
          uses: 0,
          expiresAt: expiresAt ?? undefined,
          createdBy: interaction.user.id,
          guildId: interaction.guildId!,
        });
      } catch {
        return interaction.reply({ embeds: [errorEmbed("Code này đã tồn tại!")], ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setColor(COLORS.success)
        .setTitle("🎟️ Gift Code Đã Tạo")
        .addFields(
          { name: "📌 Mã code", value: `\`${code.toUpperCase()}\``, inline: true },
          { name: "🔢 Lượt dùng", value: `${maxUses}`, inline: true },
          { name: "📅 Hết hạn", value: expiresAt ? `<t:${Math.floor(expiresAt.getTime() / 1000)}:R>` : "Không giới hạn", inline: true },
          { name: "🎁 Phần thưởng", value: [money ? `💵 ${formatMoney(money)}` : "", exp ? `⭐ ${exp} EXP` : "", diamonds ? `💎 ${diamonds} kim cương` : ""].filter(Boolean).join("\n") || "Không có", inline: false },
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === "xem") {
      const codes = await db.select().from(giftCodesTable)
        .where(eq(giftCodesTable.guildId, interaction.guildId!))
        .limit(20);
      if (codes.length === 0) return interaction.reply({ embeds: [errorEmbed("Chưa có gift code nào!")], ephemeral: true });
      const lines = codes.map(c => {
        const r = c.rewardsJson;
        const rewards = [r.money ? `${formatMoney(r.money)}` : "", r.exp ? `${r.exp}EXP` : "", r.diamonds ? `${r.diamonds}💎` : ""].filter(Boolean).join("+");
        const expired = c.expiresAt && new Date() > c.expiresAt;
        return `${expired ? "~~" : ""}\`${c.code}\`${expired ? "~~" : ""} — ${c.uses}/${c.maxUses} lượt | ${rewards}${expired ? " (hết hạn)" : ""}`;
      });
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.info).setTitle("🎟️ Danh Sách Gift Code").setDescription(lines.join("\n"))], ephemeral: true });
    }

    if (sub === "xoa") {
      const code = interaction.options.getString("code", true).toUpperCase();
      await db.delete(giftCodesTable).where(eq(giftCodesTable.code, code));
      return interaction.reply({ embeds: [successEmbed(`✅ Đã xóa code \`${code}\``)], ephemeral: true });
    }
  }

  return interaction.reply({ embeds: [errorEmbed("Lệnh không hợp lệ!")], ephemeral: true });
}

function randomCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}
