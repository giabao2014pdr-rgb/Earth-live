import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import { getPlayer, updatePlayer, formatMoney } from "../utils/db.js";
import { COLORS, errorEmbed, successEmbed } from "../utils/embeds.js";
import { BASE_LOAN_LIMIT, LOAN_INTEREST_RATE, VIP_MAP } from "../constants/premium.js";

// ─── /vay ────────────────────────────────────────────────────────────────────
export const loanData = new SlashCommandBuilder()
  .setName("loan")
  .setDescription("🏦 Vay tiền ngân hàng")
  .addIntegerOption(opt =>
    opt.setName("so_tien").setDescription("Số tiền muốn vay").setMinValue(10000).setRequired(true)
  );

export async function loanExecute(interaction: ChatInputCommandInteraction) {
  const amount = interaction.options.getInteger("so_tien", true);
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký!")], ephemeral: true });
  if (!player.isAlive) return interaction.reply({ embeds: [errorEmbed("Bạn đã tử vong!")], ephemeral: true });

  if (player.loanAmount > 0) {
    return interaction.reply({
      embeds: [errorEmbed(`Bạn đang còn nợ **${formatMoney(player.loanAmount)}**!\nDùng /trano để trả nợ trước.`)],
      ephemeral: true,
    });
  }

  const vip = VIP_MAP[player.vipTier] ?? VIP_MAP[0]!;
  const loanLimit = BASE_LOAN_LIMIT * vip.perks.loanLimitMultiplier;

  if (amount > loanLimit) {
    return interaction.reply({
      embeds: [errorEmbed(`Hạn mức vay của bạn là **${formatMoney(loanLimit)}**.\nNâng cấp VIP để tăng hạn mức!`)],
      ephemeral: true,
    });
  }

  const dueDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
  const totalDebt = Math.floor(amount * (1 + LOAN_INTEREST_RATE * 7)); // 5% per day × 7 days

  await updatePlayer(player.userId, player.guildId, {
    money: player.money + amount,
    loanAmount: totalDebt,
    loanDueAt: dueDate,
  });

  const embed = new EmbedBuilder()
    .setColor(COLORS.warning)
    .setTitle("🏦 Vay Tiền Thành Công")
    .addFields(
      { name: "💵 Nhận được", value: formatMoney(amount), inline: true },
      { name: "💸 Tổng nợ (có lãi)", value: formatMoney(totalDebt), inline: true },
      { name: "📅 Hạn trả", value: `<t:${Math.floor(dueDate.getTime() / 1000)}:R>`, inline: true },
    )
    .setDescription(`⚠️ Lãi suất ${LOAN_INTEREST_RATE * 100}%/ngày. Trả đúng hạn để tránh phạt!\nDùng **/trano** để trả nợ.`)
    .setFooter({ text: "Trả trễ sẽ bị trừ thêm tiền phạt!" });

  return interaction.reply({ embeds: [embed] });
}

// ─── /trano ──────────────────────────────────────────────────────────────────
export const repayData = new SlashCommandBuilder()
  .setName("repay")
  .setDescription("💳 Trả nợ ngân hàng");

export async function repayExecute(interaction: ChatInputCommandInteraction) {
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký!")], ephemeral: true });

  if (player.loanAmount <= 0) {
    return interaction.reply({ embeds: [successEmbed("✅ Bạn không có khoản nợ nào!")], ephemeral: true });
  }

  // Calculate late fee
  let debt = player.loanAmount;
  let lateFeeNote = "";
  if (player.loanDueAt && new Date() > player.loanDueAt) {
    const daysLate = Math.floor((Date.now() - player.loanDueAt.getTime()) / (24 * 60 * 60 * 1000));
    const lateFee = Math.floor(debt * 0.1 * daysLate); // 10% per late day
    debt += lateFee;
    lateFeeNote = `\n⚠️ Phạt trễ hạn: **+${formatMoney(lateFee)}** (${daysLate} ngày trễ)`;
  }

  if (player.money < debt) {
    // Pay partial from bank
    const totalAssets = player.money + player.bank;
    if (totalAssets < debt) {
      return interaction.reply({
        embeds: [errorEmbed(`Không đủ tiền trả nợ!\nNợ: **${formatMoney(debt)}**\nTài sản: **${formatMoney(totalAssets)}**\n\nBạn cần kiếm thêm tiền!`)],
        ephemeral: true,
      });
    }
    // Deduct from bank too
    const fromBank = debt - player.money;
    await updatePlayer(player.userId, player.guildId, {
      money: 0,
      bank: player.bank - fromBank,
      loanAmount: 0,
      loanDueAt: undefined,
    });
  } else {
    await updatePlayer(player.userId, player.guildId, {
      money: player.money - debt,
      loanAmount: 0,
      loanDueAt: undefined,
    });
  }

  const embed = new EmbedBuilder()
    .setColor(COLORS.success)
    .setTitle("✅ Trả Nợ Thành Công")
    .setDescription(`Bạn đã trả **${formatMoney(debt)}** cho ngân hàng.${lateFeeNote}\n\n🎉 Bạn đã thoát khỏi nợ nần!`);

  return interaction.reply({ embeds: [embed] });
}

// ─── /lai_suat ────────────────────────────────────────────────────────────────
export const interestData = new SlashCommandBuilder()
  .setName("interest")
  .setDescription("📊 Xem thông tin lãi suất ngân hàng và khoản vay hiện tại");

export async function interestExecute(interaction: ChatInputCommandInteraction) {
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký!")], ephemeral: true });

  const vip = VIP_MAP[player.vipTier] ?? VIP_MAP[0]!;
  const loanLimit = BASE_LOAN_LIMIT * vip.perks.loanLimitMultiplier;
  const bankInterest = 2 + vip.perks.interestRateBonus;

  const embed = new EmbedBuilder()
    .setColor(COLORS.info)
    .setTitle("🏦 Thông Tin Ngân Hàng")
    .addFields(
      { name: "💰 Tiền gửi", value: formatMoney(player.bank), inline: true },
      { name: "📈 Lãi suất tiết kiệm", value: `${bankInterest}%/tuần`, inline: true },
      { name: "💳 Hạn mức vay", value: formatMoney(loanLimit), inline: true },
      { name: "📉 Lãi suất vay", value: `${LOAN_INTEREST_RATE * 100}%/ngày`, inline: true },
      { name: "💸 Nợ hiện tại", value: player.loanAmount > 0 ? formatMoney(player.loanAmount) : "Không có nợ", inline: true },
      { name: "📅 Hạn trả", value: player.loanDueAt ? `<t:${Math.floor(player.loanDueAt.getTime() / 1000)}:R>` : "—", inline: true },
    )
    .setFooter({ text: `VIP: ${vip.name} | Nâng cấp VIP để tăng lãi suất tiết kiệm và hạn mức vay` });

  return interaction.reply({ embeds: [embed] });
}
