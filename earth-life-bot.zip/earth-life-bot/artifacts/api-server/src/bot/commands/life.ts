import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getPlayer, updatePlayer, formatMoney, playerId } from "../utils/db.js";
import { HOUSES, CARS } from "../constants/world.js";
import { COLORS } from "../utils/embeds.js";
import { db } from "@workspace/db";
import { playersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

// ─── HOUSE ───────────────────────────────────────────────────────────────────
export const houseData = new SlashCommandBuilder()
  .setName("house")
  .setDescription("🏠 Quản lý nhà ở")
  .addStringOption((opt) =>
    opt.setName("lenh").setDescription("Thao tác").setRequired(false)
      .addChoices({ name: "🏠 Xem nhà", value: "view" }, { name: "💰 Mua nhà mới", value: "buy" })
  );

export async function houseExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const cmd = interaction.options.getString("lenh") ?? "view";
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }

  if (cmd === "view") {
    const house = HOUSES.find((h) => h.level === player.houseLevel);
    const embed = new EmbedBuilder().setColor(COLORS.primary).setTitle("🏠 Nhà của bạn");
    if (house) {
      embed.setDescription(`${house.emoji} **${house.name}**\n${house.description}`);
    } else {
      embed.setDescription("❌ Bạn chưa có nhà! Dùng `/nha lenh:Mua nhà mới` để mua.");
    }
    const nextHouse = HOUSES.find((h) => h.level === player.houseLevel + 1);
    if (nextHouse) {
      embed.addFields({ name: `⬆️ Nâng cấp lên ${nextHouse.name}`, value: `${nextHouse.emoji} ${nextHouse.description}\n💰 Giá: **${formatMoney(nextHouse.cost)}**` });
    }
    await interaction.editReply({ embeds: [embed] });
    return;
  }

  if (cmd === "buy") {
    const nextHouse = HOUSES.find((h) => h.level === player.houseLevel + 1);
    if (!nextHouse) {
      await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.gold).setDescription("🏯 Bạn đã có dinh thự cao cấp nhất rồi!")] });
      return;
    }
    if (player.money < nextHouse.cost) {
      await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền! Cần **${formatMoney(nextHouse.cost)}** nhưng bạn chỉ có **${formatMoney(player.money)}**`)] });
      return;
    }
    await updatePlayer(user.id, guildId, { money: player.money - nextHouse.cost, houseLevel: nextHouse.level });
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(COLORS.success).setTitle("🏠 Mua nhà thành công!").setDescription(`${nextHouse.emoji} Bạn đã mua **${nextHouse.name}**!\n💰 Chi phí: **${formatMoney(nextHouse.cost)}**\n👛 Còn lại: **${formatMoney(player.money - nextHouse.cost)}**`)],
    });
  }
}

// ─── CAR ─────────────────────────────────────────────────────────────────────
export const carData = new SlashCommandBuilder()
  .setName("car")
  .setDescription("🚗 Quản lý phương tiện")
  .addStringOption((opt) =>
    opt.setName("lenh").setDescription("Thao tác").setRequired(false)
      .addChoices({ name: "🚗 Xem xe", value: "view" }, { name: "💰 Mua xe mới", value: "buy" })
  );

export async function carExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const cmd = interaction.options.getString("lenh") ?? "view";
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }

  if (cmd === "view") {
    const car = CARS.find((c) => c.level === player.carLevel);
    const embed = new EmbedBuilder().setColor(COLORS.primary).setTitle("🚗 Phương tiện của bạn");
    if (car) {
      embed.setDescription(`${car.emoji} **${car.name}**\n${car.description}`);
    } else {
      embed.setDescription("❌ Bạn chưa có xe! Dùng `/xe lenh:Mua xe mới` để mua.");
    }
    const nextCar = CARS.find((c) => c.level === player.carLevel + 1);
    if (nextCar) {
      embed.addFields({ name: `⬆️ Nâng cấp lên ${nextCar.name}`, value: `${nextCar.emoji} ${nextCar.description}\n💰 Giá: **${formatMoney(nextCar.cost)}**` });
    }
    await interaction.editReply({ embeds: [embed] });
    return;
  }

  if (cmd === "buy") {
    const nextCar = CARS.find((c) => c.level === player.carLevel + 1);
    if (!nextCar) {
      await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.gold).setDescription("🏎️ Bạn đã có siêu xe đỉnh nhất rồi!")] });
      return;
    }
    if (player.money < nextCar.cost) {
      await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền! Cần **${formatMoney(nextCar.cost)}** nhưng bạn chỉ có **${formatMoney(player.money)}**`)] });
      return;
    }
    await updatePlayer(user.id, guildId, { money: player.money - nextCar.cost, carLevel: nextCar.level });
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(COLORS.success).setTitle("🚗 Mua xe thành công!").setDescription(`${nextCar.emoji} Bạn đã mua **${nextCar.name}**!\n💰 Chi phí: **${formatMoney(nextCar.cost)}**\n👛 Còn lại: **${formatMoney(player.money - nextCar.cost)}**`)],
    });
  }
}

// ─── MARRY ───────────────────────────────────────────────────────────────────
export const marryData = new SlashCommandBuilder()
  .setName("marry")
  .setDescription("💍 Cầu hôn người chơi khác")
  .addUserOption((opt) => opt.setName("nguoi").setDescription("Người bạn muốn cầu hôn").setRequired(true));

export async function marryExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const target = interaction.options.getUser("nguoi", true);
  await interaction.deferReply();

  if (target.id === user.id) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Không thể tự cầu hôn chính mình!")] });
    return;
  }

  const [player, targetPlayer] = await Promise.all([
    getPlayer(user.id, guildId),
    getPlayer(target.id, guildId),
  ]);

  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }
  if (!targetPlayer) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Người kia chưa đăng ký!")] }); return; }
  if (player.spouseId) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn đã kết hôn rồi! Hãy ly hôn trước.")] }); return; }
  if (targetPlayer.spouseId) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Người kia đã có vợ/chồng rồi!")] }); return; }

  // Simple auto-accept for now (can be extended with confirmation flow)
  const pid1 = playerId(user.id, guildId);
  const pid2 = playerId(target.id, guildId);

  await Promise.all([
    updatePlayer(user.id, guildId, { spouseId: pid2, happiness: Math.min(100, player.happiness + 20) }),
    updatePlayer(target.id, guildId, { spouseId: pid1, happiness: Math.min(100, targetPlayer.happiness + 20) }),
  ]);

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(0xff69b4)
        .setTitle("💍 Kết hôn thành công!")
        .setDescription(`💕 **${user.displayName}** và **${target.displayName}** đã chính thức kết hôn!\n\nChúc hai bạn trăm năm hạnh phúc! 🌸`)
        .setTimestamp(),
    ],
  });
}

// ─── DIVORCE ─────────────────────────────────────────────────────────────────
export const divorceData = new SlashCommandBuilder().setName("divorce").setDescription("💔 Ly hôn với vợ/chồng hiện tại");

export async function divorceExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  await interaction.deferReply({ ephemeral: true });

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }
  if (!player.spouseId) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription("⚠️ Bạn chưa kết hôn!")] }); return; }

  const spouseParts = player.spouseId.split("_");
  const spouseUserId = spouseParts[0]!;

  await Promise.all([
    updatePlayer(user.id, guildId, { spouseId: null, happiness: Math.max(0, player.happiness - 30) }),
    updatePlayer(spouseUserId, guildId, { spouseId: null }),
  ]);

  await interaction.editReply({
    embeds: [new EmbedBuilder().setColor(COLORS.danger).setTitle("💔 Ly hôn").setDescription("Bạn đã ly hôn. Hạnh phúc giảm 30.")],
  });
}

// ─── BABY ────────────────────────────────────────────────────────────────────
export const babyData = new SlashCommandBuilder().setName("baby").setDescription("👶 Sinh con (cần phải có vợ/chồng và đủ điều kiện)");

export async function babyExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }
  if (!player.spouseId) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn cần phải kết hôn trước!")] }); return; }
  if (player.houseLevel < 2) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Cần có nhà ít nhất cấp 2 (Căn hộ mini) để sinh con!")] }); return; }
  if (player.children >= 5) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription("⚠️ Bạn đã có 5 con rồi! Đủ rồi nhé!")] }); return; }
  if (player.money < 5000) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Cần ít nhất **5,000₫** để sinh con (chi phí nuôi dưỡng)!")] }); return; }

  const babyGender = Math.random() < 0.5 ? "👦 Con trai" : "👧 Con gái";
  await updatePlayer(user.id, guildId, { children: player.children + 1, money: player.money - 5000, happiness: Math.min(100, player.happiness + 15) });

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(0xffb6c1)
        .setTitle(`👶 Chào mừng em bé!`)
        .setDescription(`**${user.displayName}** đã có thêm **${babyGender}**!\n\n💰 Chi phí nuôi dưỡng: 5,000₫\n😊 Hạnh phúc tăng: +15\n👶 Tổng số con: **${player.children + 1}**`)
        .setTimestamp(),
    ],
  });
}
