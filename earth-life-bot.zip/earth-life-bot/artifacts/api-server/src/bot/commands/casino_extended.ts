import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import { getPlayer, updatePlayer, formatMoney, playerId } from "../utils/db.js";
import { COLORS, errorEmbed } from "../utils/embeds.js";
import { db } from "@workspace/db";
import { playerItemsTable, activityLogsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const MIN_BET = 1000;

async function recordCasinoResult(pid: string, won: boolean, action: string, desc: string, amount: number) {
  await db.insert(activityLogsTable).values({ playerId: pid, action, description: desc, amount });
}

// ─── /taixiu ─────────────────────────────────────────────────────────────────
export const taixiuData = new SlashCommandBuilder()
  .setName("hilo")
  .setDescription("🎲 Chơi Tài Xỉu (đoán tổng 3 xúc xắc)")
  .addIntegerOption(o => o.setName("cuoc").setDescription("Số tiền cược").setMinValue(MIN_BET).setRequired(true))
  .addStringOption(o => o.setName("chon").setDescription("Tài (11-18) hay Xỉu (3-10)?").setRequired(true)
    .addChoices({ name: "🔴 Tài (11-18)", value: "tai" }, { name: "🔵 Xỉu (3-10)", value: "xiu" }));

export async function taixiuExecute(interaction: ChatInputCommandInteraction) {
  const bet = interaction.options.getInteger("cuoc", true);
  const choice = interaction.options.getString("chon", true);
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký!")], ephemeral: true });
  if (!player.isAlive) return interaction.reply({ embeds: [errorEmbed("Bạn đã tử vong!")], ephemeral: true });
  if (player.money < bet) return interaction.reply({ embeds: [errorEmbed(`Không đủ tiền! Bạn có ${formatMoney(player.money)}`)], ephemeral: true });

  const d1 = Math.floor(Math.random() * 6) + 1;
  const d2 = Math.floor(Math.random() * 6) + 1;
  const d3 = Math.floor(Math.random() * 6) + 1;
  const total = d1 + d2 + d3;
  const result = total >= 11 ? "tai" : "xiu";
  const won = result === choice;
  const pid = playerId(interaction.user.id, interaction.guildId!);

  const moneyChange = won ? bet : -bet;
  await updatePlayer(player.userId, player.guildId, {
    money: player.money + moneyChange,
    casinoWins: player.casinoWins + (won ? 1 : 0),
    casinoLosses: player.casinoLosses + (won ? 0 : 1),
  });
  await recordCasinoResult(pid, won, "casino", `Tài Xỉu: ${won ? "Thắng" : "Thua"} ${formatMoney(bet)}`, moneyChange);

  const diceEmojis = ["", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣"];
  const embed = new EmbedBuilder()
    .setColor(won ? COLORS.success : COLORS.error)
    .setTitle(`🎲 Tài Xỉu — ${won ? "🏆 THẮNG!" : "💀 THUA!"}`)
    .addFields(
      { name: "🎲 Xúc xắc", value: `${diceEmojis[d1]} ${diceEmojis[d2]} ${diceEmojis[d3]} = **${total}** (${total >= 11 ? "🔴 Tài" : "🔵 Xỉu"})`, inline: false },
      { name: "🎯 Bạn chọn", value: choice === "tai" ? "🔴 Tài" : "🔵 Xỉu", inline: true },
      { name: won ? "💰 Thắng" : "💸 Thua", value: formatMoney(bet), inline: true },
      { name: "💵 Số dư", value: formatMoney(player.money + moneyChange), inline: true },
    );
  return interaction.reply({ embeds: [embed] });
}

// ─── /xucxac ─────────────────────────────────────────────────────────────────
export const diceData = new SlashCommandBuilder()
  .setName("dice")
  .setDescription("🎲 Đoán số xúc xắc (1-6)")
  .addIntegerOption(o => o.setName("cuoc").setDescription("Số tiền cược").setMinValue(MIN_BET).setRequired(true))
  .addIntegerOption(o => o.setName("so").setDescription("Số bạn đoán (1-6)").setMinValue(1).setMaxValue(6).setRequired(true));

export async function diceExecute(interaction: ChatInputCommandInteraction) {
  const bet = interaction.options.getInteger("cuoc", true);
  const guess = interaction.options.getInteger("so", true);
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký!")], ephemeral: true });
  if (!player.isAlive) return interaction.reply({ embeds: [errorEmbed("Bạn đã tử vong!")], ephemeral: true });
  if (player.money < bet) return interaction.reply({ embeds: [errorEmbed(`Không đủ tiền!`)], ephemeral: true });

  const roll = Math.floor(Math.random() * 6) + 1;
  const won = roll === guess;
  const pid = playerId(interaction.user.id, interaction.guildId!);
  const winAmount = won ? bet * 5 : -bet; // 5x payout for exact guess

  await updatePlayer(player.userId, player.guildId, {
    money: player.money + winAmount,
    casinoWins: player.casinoWins + (won ? 1 : 0),
    casinoLosses: player.casinoLosses + (won ? 0 : 1),
  });
  await recordCasinoResult(pid, won, "casino", `Xúc Xắc: ${won ? "Thắng" : "Thua"} ${formatMoney(Math.abs(winAmount))}`, winAmount);

  const diceEmojis = ["", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣"];
  const embed = new EmbedBuilder()
    .setColor(won ? COLORS.success : COLORS.error)
    .setTitle(`🎲 Xúc Xắc — ${won ? "🏆 THẮNG x5!" : "💀 THUA!"}`)
    .addFields(
      { name: "🎲 Kết quả", value: `${diceEmojis[roll]} **${roll}**`, inline: true },
      { name: "🎯 Bạn đoán", value: `${diceEmojis[guess]} **${guess}**`, inline: true },
      { name: won ? "💰 Thắng" : "💸 Thua", value: formatMoney(Math.abs(winAmount)), inline: true },
    )
    .setDescription(won ? "🎉 Chính xác! Bạn thắng x5 tiền cược!" : `😞 Sai rồi! Số đúng là **${roll}**`)
    .setFooter({ text: `Số dư: ${formatMoney(player.money + winAmount)}` });
  return interaction.reply({ embeds: [embed] });
}

// ─── /poker ──────────────────────────────────────────────────────────────────
export const pokerData = new SlashCommandBuilder()
  .setName("poker")
  .setDescription("🃏 Chơi Video Poker (5 lá bài)")
  .addIntegerOption(o => o.setName("cuoc").setDescription("Số tiền cược").setMinValue(MIN_BET).setRequired(true));

const CARD_SUITS = ["♠️", "♥️", "♦️", "♣️"];
const CARD_VALUES = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const CARD_NUMS = [14, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];

interface Card { suit: string; value: string; num: number; }

function dealCard(used: Set<string>): Card {
  let card: Card;
  do {
    const s = CARD_SUITS[Math.floor(Math.random() * 4)]!;
    const vi = Math.floor(Math.random() * 13);
    card = { suit: s, value: CARD_VALUES[vi]!, num: CARD_NUMS[vi]! };
  } while (used.has(`${card.value}${card.suit}`));
  used.add(`${card.value}${card.suit}`);
  return card;
}

function evaluateHand(hand: Card[]): { name: string; multiplier: number } {
  const nums = hand.map(c => c.num).sort((a, b) => a - b);
  const suits = hand.map(c => c.suit);
  const counts: Record<number, number> = {};
  for (const n of nums) counts[n] = (counts[n] ?? 0) + 1;
  const freq = Object.values(counts).sort((a, b) => b - a);
  const isFlush = suits.every(s => s === suits[0]);
  const isStraight = nums[4]! - nums[0]! === 4 && new Set(nums).size === 5;
  const isRoyal = isStraight && isFlush && nums[0] === 10;

  if (isRoyal) return { name: "👑 Royal Flush", multiplier: 250 };
  if (isStraight && isFlush) return { name: "🌟 Straight Flush", multiplier: 50 };
  if (freq[0] === 4) return { name: "4️⃣ Tứ Quý", multiplier: 25 };
  if (freq[0] === 3 && freq[1] === 2) return { name: "🏠 Full House", multiplier: 9 };
  if (isFlush) return { name: "♠️ Flush", multiplier: 6 };
  if (isStraight) return { name: "📈 Straight", multiplier: 4 };
  if (freq[0] === 3) return { name: "3️⃣ Ba Cây", multiplier: 3 };
  if (freq[0] === 2 && freq[1] === 2) return { name: "2️⃣2️⃣ Hai Đôi", multiplier: 2 };
  if (freq[0] === 2) return { name: "2️⃣ Một Đôi", multiplier: 1 };
  return { name: "❌ Không có bài", multiplier: 0 };
}

export async function pokerExecute(interaction: ChatInputCommandInteraction) {
  const bet = interaction.options.getInteger("cuoc", true);
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký!")], ephemeral: true });
  if (!player.isAlive) return interaction.reply({ embeds: [errorEmbed("Bạn đã tử vong!")], ephemeral: true });
  if (player.money < bet) return interaction.reply({ embeds: [errorEmbed(`Không đủ tiền!`)], ephemeral: true });

  const used = new Set<string>();
  const hand = Array.from({ length: 5 }, () => dealCard(used));
  const { name, multiplier } = evaluateHand(hand);
  const won = multiplier > 0;
  const winAmount = won ? bet * multiplier : -bet;
  const pid = playerId(interaction.user.id, interaction.guildId!);

  await updatePlayer(player.userId, player.guildId, {
    money: player.money + winAmount,
    casinoWins: player.casinoWins + (won ? 1 : 0),
    casinoLosses: player.casinoLosses + (won ? 0 : 1),
  });
  await recordCasinoResult(pid, won, "casino", `Poker: ${name} ${won ? "Thắng" : "Thua"} ${formatMoney(Math.abs(winAmount))}`, winAmount);

  const handStr = hand.map(c => `\`${c.value}${c.suit}\``).join(" ");
  const embed = new EmbedBuilder()
    .setColor(won ? COLORS.success : COLORS.error)
    .setTitle(`🃏 Video Poker — ${name}`)
    .addFields(
      { name: "🃏 Bài của bạn", value: handStr, inline: false },
      { name: "📊 Hệ số thắng", value: multiplier > 0 ? `x${multiplier}` : "—", inline: true },
      { name: won ? "💰 Thắng" : "💸 Thua", value: formatMoney(Math.abs(winAmount)), inline: true },
      { name: "💵 Số dư", value: formatMoney(player.money + winAmount), inline: true },
    )
    .setDescription("**Bảng thưởng:** Đôi=x1 | Hai Đôi=x2 | Ba Cây=x3 | Straight=x4 | Flush=x6 | Full=x9 | Tứ Quý=x25 | Str.Flush=x50 | Royal=x250");
  return interaction.reply({ embeds: [embed] });
}

// ─── /veso ───────────────────────────────────────────────────────────────────
export const lotteryData = new SlashCommandBuilder()
  .setName("lottery")
  .setDescription("🎟️ Cào vé số")
  .addStringOption(o => o.setName("loai").setDescription("Loại vé").setRequired(false)
    .addChoices({ name: "🎟️ Vé thường (100₫)", value: "ve_so" }, { name: "🌟 Vé vàng (10💎)", value: "ve_so_vang" }));

export async function lotteryExecute(interaction: ChatInputCommandInteraction) {
  const loai = interaction.options.getString("loai") ?? "ve_so";
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký!")], ephemeral: true });
  if (!player.isAlive) return interaction.reply({ embeds: [errorEmbed("Bạn đã tử vong!")], ephemeral: true });

  const pid = playerId(interaction.user.id, interaction.guildId!);
  const [owned] = await db.select().from(playerItemsTable)
    .where(and(eq(playerItemsTable.playerId, pid), eq(playerItemsTable.itemId, loai))).limit(1);

  if (!owned || owned.quantity < 1) {
    // Auto-buy if regular ticket and has money
    if (loai === "ve_so") {
      if (player.money < 100) return interaction.reply({ embeds: [errorEmbed("Không đủ tiền mua vé số! (100₫)")], ephemeral: true });
      await updatePlayer(player.userId, player.guildId, { money: player.money - 100 });
    } else {
      return interaction.reply({ embeds: [errorEmbed("Bạn không có vé số vàng! Mua tại /cuahang loai:diamond")], ephemeral: true });
    }
  } else {
    await db.update(playerItemsTable).set({ quantity: owned.quantity - 1 }).where(eq(playerItemsTable.id, owned.id));
  }

  const isGolden = loai === "ve_so_vang";
  const roll = Math.random();

  let prize = 0;
  let prizeName = "";

  if (isGolden) {
    if (roll < 0.01) { prize = 10000000; prizeName = "💎 JACKPOT! 10,000,000₫"; }
    else if (roll < 0.05) { prize = 1000000; prizeName = "🥇 Giải Nhất: 1,000,000₫"; }
    else if (roll < 0.15) { prize = 200000; prizeName = "🥈 Giải Nhì: 200,000₫"; }
    else if (roll < 0.35) { prize = 50000; prizeName = "🥉 Giải Ba: 50,000₫"; }
    else if (roll < 0.65) { prize = 10000; prizeName = "🎁 An Ủi: 10,000₫"; }
    else { prize = 0; prizeName = "❌ Chúc bạn may mắn lần sau!"; }
  } else {
    if (roll < 0.001) { prize = 5000000; prizeName = "🌟 JACKPOT! 5,000,000₫"; }
    else if (roll < 0.01) { prize = 500000; prizeName = "🥇 Giải Nhất: 500,000₫"; }
    else if (roll < 0.05) { prize = 100000; prizeName = "🥈 Giải Nhì: 100,000₫"; }
    else if (roll < 0.15) { prize = 20000; prizeName = "🥉 Giải Ba: 20,000₫"; }
    else if (roll < 0.40) { prize = 5000; prizeName = "🎁 An Ủi: 5,000₫"; }
    else { prize = 0; prizeName = "❌ Trượt! Không trúng thưởng"; }
  }

  if (prize > 0) {
    await updatePlayer(player.userId, player.guildId, { money: player.money + prize });
  }

  const embed = new EmbedBuilder()
    .setColor(prize > 0 ? COLORS.gold : COLORS.error)
    .setTitle(`🎟️ Kết Quả Vé Số ${isGolden ? "Vàng 🌟" : "Thường"}`)
    .setDescription(`**${prizeName}**`)
    .addFields(
      { name: "💵 Tiền thắng", value: formatMoney(prize), inline: true },
      { name: "💰 Số dư mới", value: formatMoney(player.money + prize), inline: true },
    )
    .setFooter({ text: "Mua vé số tại /cuahang | Vé vàng tỷ lệ cao hơn!" });
  return interaction.reply({ embeds: [embed] });
}
