import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ActionRowBuilder,
  ComponentType,
} from "discord.js";
import { COLORS } from "../utils/embeds.js";

export const helpData = new SlashCommandBuilder()
  .setName("help")
  .setDescription("Xem hướng dẫn cách chơi Earth Life");

// ─── Category pages ───────────────────────────────────────────────────────────

function mainEmbed() {
  return new EmbedBuilder()
    .setColor(0x00bfff)
    .setTitle("📖 Earth Life — Hướng dẫn chơi")
    .setDescription(
      "Chọn một **danh mục** từ menu bên dưới để xem hướng dẫn chi tiết.\n\n" +
      "**📌 Tóm tắt nhanh:**\n" +
      "1️⃣ Dùng `/register` để tạo tài khoản\n" +
      "2️⃣ Dùng `/job` để chọn nghề nghiệp\n" +
      "3️⃣ Dùng `/work` để đi làm kiếm tiền\n" +
      "4️⃣ Dùng `/daily` để nhận thưởng hằng ngày\n" +
      "5️⃣ Mua nhà, xe, đầu tư, chơi casino để giàu hơn\n" +
      "6️⃣ Giữ sức khỏe, tránh bệnh tật\n" +
      "7️⃣ Đạt mục tiêu: **Level 1000** & **1 tỷ$**\n\n" +
      "👇 Chọn danh mục bên dưới để tìm hiểu thêm:"
    )
    .setFooter({ text: "Earth Life RPG • Menu tự động đóng sau 2 phút" });
}

function embedNhanVat() {
  return new EmbedBuilder()
    .setColor(0x7289da)
    .setTitle("👤 Hệ thống Nhân vật")
    .addFields(
      {
        name: "📋 Lệnh cơ bản",
        value:
          "`/register` — Tạo tài khoản (chỉ làm 1 lần)\n" +
          "`/profile` — Xem hồ sơ cá nhân\n" +
          "`/history` — Xem lịch sử hoạt động\n" +
          "`/leaderboard` — Bảng xếp hạng",
      },
      {
        name: "⭐ Level & EXP",
        value:
          "• Level tối đa: **1000**\n" +
          "• EXP nhận được từ: làm việc, khám phá, casino, chữa bệnh\n" +
          "• Lên level → nhận thưởng tiền & mở khoá danh hiệu\n" +
          "• Dùng `X2 EXP` (mua ở `/shop`) để tăng gấp đôi EXP tạm thời",
      },
      {
        name: "🏅 Danh hiệu theo level",
        value:
          "Lv1 Tân binh → Lv10 Người mới → Lv20 Thị dân → Lv30 Thương nhân\n" +
          "Lv50 Doanh nhân → Lv75 Tinh Anh → Lv100 Huyền Thoại → ...\n" +
          "Lv1000 **Bất Tử**",
      }
    )
    .setFooter({ text: "👤 Nhân vật • Chọn danh mục khác từ menu" });
}

function embedNgheNghiep() {
  return new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle("💼 Hệ thống Nghề nghiệp")
    .addFields(
      {
        name: "📋 Lệnh",
        value:
          "`/job` — Xem & chọn nghề nghiệp\n" +
          "`/work` — Đi làm (có thời gian hồi chiêu)",
      },
      {
        name: "🔧 15 Nghề nghiệp",
        value:
          "🌾 Nông dân | 🔧 Công nhân | 🚗 Tài xế | 🍳 Đầu bếp | ⚙️ Thợ máy\n" +
          "📚 Giáo viên | 👮 Cảnh sát | 🩺 Bác sĩ | 💻 Lập trình viên | ⚖️ Luật sư\n" +
          "💼 Doanh nhân | 🎮 Streamer | 🏗️ Thợ xây | 🎣 Ngư dân | ✈️ Phi công",
      },
      {
        name: "💡 Cách hoạt động",
        value:
          "• Mỗi nghề có mức **lương riêng** và **cấp nghề** riêng\n" +
          "• Làm việc nhiều → tăng **cấp nghề** → lương cao hơn\n" +
          "• `/work` có thời gian hồi chiêu — không thể spam\n" +
          "• Nghề cấp cao (Bác sĩ, Phi công...) lương cao nhưng cần level cao",
      }
    )
    .setFooter({ text: "💼 Nghề nghiệp • Chọn danh mục khác từ menu" });
}

function embedKinhTe() {
  return new EmbedBuilder()
    .setColor(0xf1c40f)
    .setTitle("💰 Hệ thống Kinh tế")
    .addFields(
      {
        name: "📋 Lệnh",
        value:
          "`/balance` — Xem số dư tiền mặt & ngân hàng\n" +
          "`/bank deposit <số>` — Gửi tiền vào ngân hàng\n" +
          "`/bank withdraw <số>` — Rút tiền ra\n" +
          "`/daily` — Nhận thưởng hằng ngày (streak càng dài càng nhiều)\n" +
          "`/pay @user <số>` — Chuyển tiền cho người khác\n" +
          "`/loan <số>` — Vay tiền từ ngân hàng\n" +
          "`/repay <số>` — Trả nợ\n" +
          "`/interest` — Xem lãi suất hiện tại",
      },
      {
        name: "🏦 Ngân hàng",
        value:
          "• Tiền gửi ngân hàng sinh **lãi hằng ngày** tự động\n" +
          "• Tiền mặt **không sinh lãi** — nên gửi NH bớt\n" +
          "• Vay tiền có **lãi suất** — trả đúng hạn hoặc bị phạt\n" +
          "• VIP → lãi suất gửi cao hơn & hạn mức vay lớn hơn",
      },
      {
        name: "💡 Mẹo",
        value:
          "• Điểm danh `/daily` liên tục để giữ **streak** nhận thưởng lớn\n" +
          "• Gửi tiền NH để hưởng lãi kép dài hạn\n" +
          "• Đừng vay quá nhiều — lãi phạt rất nặng nếu trễ hạn",
      }
    )
    .setFooter({ text: "💰 Kinh tế • Chọn danh mục khác từ menu" });
}

function embedTaiSan() {
  return new EmbedBuilder()
    .setColor(0xe67e22)
    .setTitle("🏠 Hệ thống Tài sản (Nhà & Xe)")
    .addFields(
      {
        name: "📋 Lệnh",
        value:
          "`/house` — Xem & mua/nâng cấp nhà\n" +
          "`/car` — Xem & mua/nâng cấp xe",
      },
      {
        name: "🏠 Cấp bậc Nhà",
        value:
          "1. 🏚️ Nhà nhỏ\n2. 🏠 Nhà thường\n3. 🏡 Nhà cao cấp\n" +
          "4. 🏰 Biệt thự\n5. 🌇 Penthouse\n6. 🏝️ Đảo riêng\n" +
          "*Nhà cao cấp hơn → tăng danh tiếng & uy tín*",
        inline: true,
      },
      {
        name: "🚗 Cấp bậc Xe",
        value:
          "1. 🛵 Xe máy\n2. 🚗 Ô tô\n3. 🏎️ Xe thể thao\n" +
          "4. 🚀 Siêu xe\n5. ✨ Xe giới hạn\n" +
          "*Xe hiếm tăng danh tiếng & sưu tập*",
        inline: true,
      },
      {
        name: "💡 Mẹo",
        value:
          "• Mua nhà/xe tăng điểm danh tiếng ảnh hưởng xếp hạng\n" +
          "• Có thể bán lại nhà/xe (giá thấp hơn giá mua)\n" +
          "• Nâng cấp rẻ hơn mua mới",
      }
    )
    .setFooter({ text: "🏠 Tài sản • Chọn danh mục khác từ menu" });
}

function embedCasino() {
  return new EmbedBuilder()
    .setColor(0xe74c3c)
    .setTitle("🎰 Hệ thống Casino")
    .addFields(
      {
        name: "🎮 Các trò chơi",
        value:
          "`/slots <cược>` — 🎰 Máy đánh bạc (3 ký tự trùng → jackpot)\n" +
          "`/coinflip <heads/tails> <cược>` — 🪙 Tung đồng xu\n" +
          "`/blackjack <cược>` — 🃏 Xỉ ngầu — đạt 21 điểm thắng\n" +
          "`/roulette <số/màu> <cược>` — 🎡 Roulette\n" +
          "`/race <số ngựa> <cược>` — 🏇 Đua ngựa\n" +
          "`/hilo <cược>` — 🎯 Tài Xỉu\n" +
          "`/dice <cược>` — 🎲 Xúc xắc\n" +
          "`/poker <cược>` — ♠️ Poker\n" +
          "`/lottery` — 🎟️ Vé số (quay mỗi ngày)",
      },
      {
        name: "💡 Lưu ý",
        value:
          "• Casino có **may mắn ngẫu nhiên** — không đảm bảo thắng\n" +
          "• Thắng/thua nhiều ảnh hưởng thành tích **BXH casino**\n" +
          "• Mua **Vé may mắn** ở `/shop` để tăng tỉ lệ thắng\n" +
          "• VIP Diamond có trò chơi casino đặc biệt",
      }
    )
    .setFooter({ text: "🎰 Casino • Chọn danh mục khác từ menu" });
}

function embedSucKhoe() {
  return new EmbedBuilder()
    .setColor(0x1abc9c)
    .setTitle("🏥 Hệ thống Sức khỏe & Bệnh tật")
    .addFields(
      {
        name: "📋 Lệnh",
        value:
          "`/health` — Kiểm tra sức khoẻ hiện tại & danh sách bệnh\n" +
          "`/hospital` — Vào viện điều trị bệnh\n" +
          "`/revive` — Hồi sinh sau khi chết (tốn phí)",
      },
      {
        name: "🦠 30 loại bệnh",
        value:
          "🟢 **Nhẹ** (cảm cúm, đau đầu...) — dễ chữa, ít nguy hiểm\n" +
          "🟡 **Trung bình** (viêm phổi, gãy xương...) — cần thuốc tốt\n" +
          "🔴 **Nặng** (ung thư, tim mạch...) — nguy cơ tử vong cao",
      },
      {
        name: "⚠️ Quan trọng",
        value:
          "• Bệnh **tự phát sinh** theo thời gian — check thường xuyên\n" +
          "• Bệnh nặng không chữa → HP giảm dần → **có thể chết**\n" +
          "• Chết → mất một phần tiền mặt, cần `/revive` để tiếp tục\n" +
          "• Mua **thuốc** ở `/shop` để tự chữa tại nhà (rẻ hơn bệnh viện)\n" +
          "• Năng lượng phục hồi tự động mỗi **30 phút**",
      }
    )
    .setFooter({ text: "🏥 Sức khoẻ • Chọn danh mục khác từ menu" });
}

function embedTheGioi() {
  return new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle("🌍 Thế giới & Khám phá")
    .addFields(
      {
        name: "📋 Lệnh",
        value:
          "`/map` — Xem bản đồ thế giới\n" +
          "`/travel <địa điểm>` — Di chuyển đến địa điểm mới\n" +
          "`/explore` — Khám phá địa điểm hiện tại (nhận thưởng ngẫu nhiên)",
      },
      {
        name: "📍 7 Địa điểm",
        value:
          "🏙️ Thành phố | 🌲 Rừng | 🏖️ Biển | ⛏️ Mỏ\n" +
          "🏔️ Núi | 🏜️ Sa mạc | 🏝️ Đảo hoang\n" +
          "*Mỗi nơi có phần thưởng & sự kiện riêng*",
      },
      {
        name: "💡 Mẹo",
        value:
          "• `/explore` có thể tìm thấy: tiền, vật phẩm, EXP, hoặc... bệnh!\n" +
          "• Di chuyển tốn tiền — chọn nơi phù hợp với mục tiêu\n" +
          "• Một số thành tựu yêu cầu khám phá đủ địa điểm",
      }
    )
    .setFooter({ text: "🌍 Thế giới • Chọn danh mục khác từ menu" });
}

function embedVatPham() {
  return new EmbedBuilder()
    .setColor(0x9b59b6)
    .setTitle("🎒 Vật phẩm & Cửa hàng")
    .addFields(
      {
        name: "📋 Lệnh",
        value:
          "`/shop` — Xem cửa hàng\n" +
          "`/inventory` — Xem túi đồ của bạn\n" +
          "`/use <vật phẩm>` — Sử dụng vật phẩm",
      },
      {
        name: "🛍️ Các loại vật phẩm",
        value:
          "💊 **Thuốc** — Chữa bệnh tại nhà (không cần bệnh viện)\n" +
          "🎟️ **Vé casino** — Chơi casino không tốn tiền\n" +
          "🎫 **Vé số** — Cơ hội trúng jackpot lớn\n" +
          "⚡ **X2 EXP / X2 Tiền** — Buff tạm thời khi làm việc\n" +
          "🍀 **Tăng may mắn** — Tăng tỉ lệ thắng casino\n" +
          "⏩ **Reset Cooldown** — Làm việc ngay lập tức\n" +
          "✨ **Hiệu ứng hồ sơ** — Trang trí `/profile`\n" +
          "🎁 **Hộp quà** — Mở ra nhận vật phẩm ngẫu nhiên",
      },
      {
        name: "💎 Vật phẩm Kim cương",
        value:
          "Một số vật phẩm hiếm chỉ mua được bằng 💎 Kim cương\n" +
          "Dùng `/diamond` để mua kim cương — `/vip` để xem gói VIP",
      }
    )
    .setFooter({ text: "🎒 Vật phẩm • Chọn danh mục khác từ menu" });
}

function embedDauTu() {
  return new EmbedBuilder()
    .setColor(0x27ae60)
    .setTitle("📈 Đầu tư & Bang hội")
    .addFields(
      {
        name: "📋 Lệnh đầu tư",
        value:
          "`/invest market` — Xem thị trường chứng khoán\n" +
          "`/invest buy <mã> <số lượng>` — Mua cổ phiếu\n" +
          "`/invest sell <mã> <số lượng>` — Bán cổ phiếu\n" +
          "`/invest portfolio` — Xem danh mục đầu tư của bạn",
      },
      {
        name: "📊 6 Mã cổ phiếu",
        value: "EARTH | LIFE | GOLD | TECH | OIL | BANK\n*Giá thay đổi ngẫu nhiên — mua thấp bán cao!*",
      },
      {
        name: "⚔️ Lệnh Bang hội",
        value:
          "`/guild create <tên>` — Tạo bang hội\n" +
          "`/guild join <tên>` — Gia nhập bang\n" +
          "`/guild info` — Xem thông tin bang\n" +
          "`/guild leave` — Rời bang",
      },
      {
        name: "💡 Mẹo đầu tư",
        value:
          "• Giá cổ phiếu biến động mỗi khi xem thị trường\n" +
          "• Đừng bỏ tất cả vào 1 mã — đa dạng hoá danh mục\n" +
          "• Theo dõi xu hướng và bán khi lời ổn",
      }
    )
    .setFooter({ text: "📈 Đầu tư • Chọn danh mục khác từ menu" });
}

function embedPremium() {
  return new EmbedBuilder()
    .setColor(0xf39c12)
    .setTitle("💎 Premium, Sự kiện & Thành tựu")
    .addFields(
      {
        name: "💎 VIP & Kim cương",
        value:
          "`/diamond` — Mua kim cương\n" +
          "`/vip` — Xem & nâng cấp VIP\n\n" +
          "🥉 Bronze | 🥈 Silver | 🥇 Gold | 💎 Diamond\n" +
          "VIP nhận: X2 EXP/Tiền, lãi NH cao hơn, quà hằng ngày, huy hiệu độc quyền",
      },
      {
        name: "🎁 Sự kiện & Gift Code",
        value:
          "`/event` — Xem sự kiện đang diễn ra\n" +
          "`/redeem <code>` — Nhập gift code nhận thưởng\n\n" +
          "📅 Sự kiện theo mùa: 🎊 Tết | 💝 Valentine | 🎃 Halloween | 🎄 Noel | 🎂 Sinh nhật bot",
      },
      {
        name: "🏆 Thành tựu",
        value:
          "`/achievement` — Xem danh sách thành tựu\n\n" +
          "Hoàn thành thành tựu → nhận phần thưởng đặc biệt!\n" +
          "VD: Kiếm 1 triệu$, đạt Lv100, thắng 100 ván casino...",
      }
    )
    .setFooter({ text: "💎 Premium • Chọn danh mục khác từ menu" });
}

// ─── Category map ─────────────────────────────────────────────────────────────
const CATEGORIES: Record<string, () => EmbedBuilder> = {
  main:       mainEmbed,
  nhanvat:    embedNhanVat,
  nghenghiep: embedNgheNghiep,
  kinhte:     embedKinhTe,
  taisan:     embedTaiSan,
  casino:     embedCasino,
  suckhoe:    embedSucKhoe,
  thegioi:    embedTheGioi,
  vatpham:    embedVatPham,
  dautu:      embedDauTu,
  premium:    embedPremium,
};

// ─── Execute ──────────────────────────────────────────────────────────────────
export async function helpExecute(interaction: ChatInputCommandInteraction) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId("help_menu")
    .setPlaceholder("📂 Chọn danh mục hướng dẫn...")
    .addOptions(
      new StringSelectMenuOptionBuilder().setLabel("🏠 Tổng quan").setValue("main").setDescription("Tóm tắt nhanh cách bắt đầu"),
      new StringSelectMenuOptionBuilder().setLabel("👤 Nhân vật & Level").setValue("nhanvat").setDescription("Profile, EXP, Level, danh hiệu"),
      new StringSelectMenuOptionBuilder().setLabel("💼 Nghề nghiệp").setValue("nghenghiep").setDescription("15 nghề, cách làm việc, cấp nghề"),
      new StringSelectMenuOptionBuilder().setLabel("💰 Kinh tế").setValue("kinhte").setDescription("Tiền, ngân hàng, vay, chuyển khoản"),
      new StringSelectMenuOptionBuilder().setLabel("🏠 Nhà & Xe").setValue("taisan").setDescription("Tài sản bất động sản và phương tiện"),
      new StringSelectMenuOptionBuilder().setLabel("🎰 Casino").setValue("casino").setDescription("8 trò chơi may mắn"),
      new StringSelectMenuOptionBuilder().setLabel("🏥 Sức khoẻ & Bệnh tật").setValue("suckhoe").setDescription("30 bệnh, cách điều trị, hồi sinh"),
      new StringSelectMenuOptionBuilder().setLabel("🌍 Thế giới & Khám phá").setValue("thegioi").setDescription("Bản đồ, di chuyển, phần thưởng"),
      new StringSelectMenuOptionBuilder().setLabel("🎒 Vật phẩm & Cửa hàng").setValue("vatpham").setDescription("Shop, túi đồ, cách sử dụng item"),
      new StringSelectMenuOptionBuilder().setLabel("📈 Đầu tư & Bang hội").setValue("dautu").setDescription("Chứng khoán, cổ phiếu, guild"),
      new StringSelectMenuOptionBuilder().setLabel("💎 VIP, Sự kiện & Thành tựu").setValue("premium").setDescription("Premium, gift code, event mùa")
    );

  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);

  const reply = await interaction.reply({
    embeds: [mainEmbed()],
    components: [row],
    fetchReply: true,
  });

  // Collector — listen for 2 minutes
  const collector = reply.createMessageComponentCollector({
    componentType: ComponentType.StringSelect,
    time: 120_000,
    filter: (i) => i.user.id === interaction.user.id,
  });

  collector.on("collect", async (selectInteraction) => {
    const value = selectInteraction.values[0]!;
    const buildEmbed = CATEGORIES[value] ?? mainEmbed;
    await selectInteraction.update({
      embeds: [buildEmbed()],
      components: [row],
    });
  });

  collector.on("end", async () => {
    const disabledMenu = new StringSelectMenuBuilder()
      .setCustomId("help_menu_disabled")
      .setPlaceholder("⏰ Menu đã hết hạn — dùng /help để mở lại")
      .setDisabled(true)
      .addOptions(new StringSelectMenuOptionBuilder().setLabel("—").setValue("noop"));
    const disabledRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(disabledMenu);
    await interaction.editReply({ components: [disabledRow] }).catch(() => {});
  });
}
