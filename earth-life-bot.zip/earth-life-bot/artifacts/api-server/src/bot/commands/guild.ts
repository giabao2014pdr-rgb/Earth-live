import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getPlayer, updatePlayer, formatMoney, playerId } from "../utils/db.js";
import { COLORS } from "../utils/embeds.js";
import { db } from "@workspace/db";
import { gameGuildsTable, guildMembersTable, playersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { randomUUID } from "node:crypto";

export const guildData = new SlashCommandBuilder()
  .setName("guild")
  .setDescription("⚔️ Hệ thống bang hội")
  .addStringOption((opt) =>
    opt.setName("lenh").setDescription("Thao tác").setRequired(true)
      .addChoices(
        { name: "📋 Thông tin bang", value: "info" },
        { name: "➕ Tạo bang mới", value: "create" },
        { name: "🚪 Rời bang", value: "leave" },
        { name: "👥 Danh sách thành viên", value: "members" },
      )
  )
  .addStringOption((opt) => opt.setName("ten").setDescription("Tên bang (khi tạo mới)").setRequired(false))
  .addStringOption((opt) => opt.setName("mo_ta").setDescription("Mô tả bang (khi tạo mới)").setRequired(false));

export async function guildExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const cmd = interaction.options.getString("lenh", true);
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }

  const pid = playerId(user.id, guildId);

  if (cmd === "create") {
    const name = interaction.options.getString("ten");
    const desc = interaction.options.getString("mo_ta") ?? "Một bang hội mới";
    if (!name) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Cần nhập tên bang!")] }); return; }
    if (player.guildGameId) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn đã ở trong một bang rồi! Hãy rời bang trước.")] }); return; }
    if (player.money < 10000) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Cần **10,000₫** để tạo bang!")] }); return; }

    const guildGameId = randomUUID();
    await db.insert(gameGuildsTable).values({ id: guildGameId, name, description: desc, leaderId: pid });
    await db.insert(guildMembersTable).values({ guildId: guildGameId, playerId: pid, role: "leader" });
    await updatePlayer(user.id, guildId, { guildGameId, money: player.money - 10000 });

    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(COLORS.success).setTitle("⚔️ Tạo bang thành công!").setDescription(`Bang **${name}** đã được thành lập!\n💰 Chi phí: 10,000₫\n👑 Thủ lĩnh: ${user.displayName}`)],
    });
    return;
  }

  if (cmd === "info") {
    if (!player.guildGameId) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription("⚠️ Bạn chưa ở trong bang nào!")] }); return; }

    const [bang] = await db.select().from(gameGuildsTable).where(eq(gameGuildsTable.id, player.guildGameId)).limit(1);
    if (!bang) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Không tìm thấy thông tin bang!")] }); return; }

    const memberCount = await db.select().from(guildMembersTable).where(eq(guildMembersTable.guildId, player.guildGameId));

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.primary)
          .setTitle(`⚔️ ${bang.name}`)
          .setDescription(bang.description)
          .addFields(
            { name: "👑 Thủ lĩnh", value: bang.leaderId, inline: true },
            { name: "👥 Thành viên", value: `${memberCount.length}/${bang.maxMembers}`, inline: true },
            { name: "⭐ Cấp bang", value: `${bang.level}`, inline: true },
            { name: "💰 Quỹ bang", value: formatMoney(bang.balance), inline: true },
          ),
      ],
    });
    return;
  }

  if (cmd === "leave") {
    if (!player.guildGameId) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription("⚠️ Bạn chưa ở trong bang nào!")] }); return; }

    await db.delete(guildMembersTable).where(and(eq(guildMembersTable.playerId, pid), eq(guildMembersTable.guildId, player.guildGameId)));
    await updatePlayer(user.id, guildId, { guildGameId: null });

    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription("👋 Bạn đã rời bang!")] });
    return;
  }

  if (cmd === "members") {
    if (!player.guildGameId) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription("⚠️ Bạn chưa ở trong bang nào!")] }); return; }

    const members = await db.select().from(guildMembersTable).where(eq(guildMembersTable.guildId, player.guildGameId));
    const memberList = members.map((m) => {
      const roleEmoji = m.role === "leader" ? "👑" : m.role === "officer" ? "⚔️" : "👤";
      return `${roleEmoji} ${m.playerId}`;
    }).join("\n").substring(0, 1000);

    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(COLORS.primary).setTitle("👥 Thành viên bang").setDescription(memberList || "Không có thành viên")],
    });
  }
}
