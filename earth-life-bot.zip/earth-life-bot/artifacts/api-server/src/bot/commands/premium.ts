import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import { getPlayer, updatePlayer, formatMoney, playerId } from "../utils/db.js";
import { COLORS, errorEmbed } from "../utils/embeds.js";
import { VIP_TIERS, VIP_MAP, DIAMOND_PACKAGES } from "../constants/premium.js";
import { db } from "@workspace/db";
import { playerItemsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { ITEMS } from "../constants/items.js";

// ─── /kim_cuong ───────────────────────────────────────────────────────────────
export const diamondData = new SlashCommandBuilder()
  .setName("diamond")
  .setDescription("💎 Xem số dư kim cương và cách sử dụng");

export async function diamondExecute(interaction: ChatInputCommandInteraction) {
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký!")], ephemeral: true });

  const vip = VIP_MAP[player.vipTier] ?? VIP_MAP[0]!;
  const embed = new EmbedBuilder()
    .setColor(0x00bfff)
    .setTitle("💎 Kim Cương")
    .setDescription("Kim cương là tiền tệ cao cấp dùng để mua vật phẩm VIP, gói tăng tốc, hiệu ứng hồ sơ và nhiều hơn nữa!")
    .addFields(
      { name: "💎 Số dư", value: `${player.diamonds} kim cương`, inline: true },
      { name: "🎖️ Hạng VIP", value: `${vip.emoji} ${vip.name}`, inline: true },
      { name: "📦 Cách nhận kim cương", value: "• Admin nạp cho bạn\n• Phần thưởng sự kiện\n• Thành tựu\n• Điểm danh VIP hằng ngày", inline: false },
      {
        name: "💰 Dùng kim cương để mua",
        value: "• Gói X2 EXP/Tiền\n• Hiệu ứng hồ sơ đặc biệt\n• Vé số vàng\n• Hộp quà lớn\n• Gói VIP\n• Xem tại `/cuahang loai:diamond`",
        inline: false,
      },
    )
    .setFooter({ text: "Dùng /vip để xem và mua gói VIP" });
  return interaction.reply({ embeds: [embed] });
}

// ─── /vip ─────────────────────────────────────────────────────────────────────
export const vipData = new SlashCommandBuilder()
  .setName("vip")
  .setDescription("👑 Xem và mua gói VIP")
  .addIntegerOption(o =>
    o.setName("hang").setDescription("Hạng VIP muốn mua (1=Bronze, 2=Silver, 3=Gold, 4=Diamond)")
      .setMinValue(1).setMaxValue(4).setRequired(false)
  );

export async function vipExecute(interaction: ChatInputCommandInteraction) {
  const tierChoice = interaction.options.getInteger("hang");
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký!")], ephemeral: true });

  const currentVip = VIP_MAP[player.vipTier] ?? VIP_MAP[0]!;

  // Show VIP info
  if (!tierChoice) {
    const tierLines = VIP_TIERS.filter(v => v.tier > 0).map(v => {
      const isCurrent = player.vipTier === v.tier;
      return `${isCurrent ? "▶️" : "  "} ${v.emoji} **${v.name}** — ${v.costDiamonds}💎/tháng\n   EXP x${v.perks.expMultiplier} | Tiền x${v.perks.moneyMultiplier} | May mắn +${Math.round((v.perks.luckBoost - 1) * 100)}% | ${v.perks.dailyDiamonds}💎/ngày`;
    }).join("\n");

    const expiryStr = player.vipTier > 0 && player.vipExpiresAt
      ? `<t:${Math.floor(player.vipExpiresAt.getTime() / 1000)}:R>`
      : "—";

    const embed = new EmbedBuilder()
      .setColor(currentVip.color)
      .setTitle("👑 Hệ Thống VIP")
      .setDescription(`**Hạng hiện tại:** ${currentVip.emoji} ${currentVip.name}\n**Hết hạn:** ${expiryStr}\n\n${tierLines}`)
      .addFields(
        { name: `${currentVip.emoji} Quyền lợi hiện tại`, value: player.vipTier > 0 ? `• EXP x${currentVip.perks.expMultiplier}\n• Tiền x${currentVip.perks.moneyMultiplier}\n• Lãi suất +${currentVip.perks.interestRateBonus}%\n• ${currentVip.perks.dailyDiamonds}💎/ngày\n• Hạn vay x${currentVip.perks.loanLimitMultiplier}` : "Không có quyền lợi VIP", inline: false },
      )
      .setFooter({ text: "Dùng /vip hang:<1-4> để mua | Cần kim cương 💎" });
    return interaction.reply({ embeds: [embed] });
  }

  // Buy VIP
  const targetVip = VIP_MAP[tierChoice];
  if (!targetVip) return interaction.reply({ embeds: [errorEmbed("Hạng VIP không hợp lệ!")], ephemeral: true });

  if (player.diamonds < targetVip.costDiamonds) {
    return interaction.reply({
      embeds: [errorEmbed(`Không đủ kim cương!\nCần: ${targetVip.costDiamonds}💎\nBạn có: ${player.diamonds}💎`)],
      ephemeral: true,
    });
  }

  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days
  // If already VIP, extend
  const existingExpiry = player.vipTier === tierChoice && player.vipExpiresAt && player.vipExpiresAt > new Date()
    ? new Date(player.vipExpiresAt.getTime() + 30 * 24 * 60 * 60 * 1000)
    : expiresAt;

  await updatePlayer(player.userId, player.guildId, {
    diamonds: player.diamonds - targetVip.costDiamonds,
    vipTier: tierChoice,
    vipExpiresAt: existingExpiry,
  });

  const embed = new EmbedBuilder()
    .setColor(targetVip.color)
    .setTitle(`${targetVip.emoji} Kích hoạt ${targetVip.name} thành công!`)
    .setDescription(`Bạn đã nâng cấp lên **${targetVip.name}**!`)
    .addFields(
      { name: "💎 Chi phí", value: `${targetVip.costDiamonds} kim cương`, inline: true },
      { name: "📅 Hết hạn", value: `<t:${Math.floor(existingExpiry.getTime() / 1000)}:R>`, inline: true },
      { name: "🎁 Quyền lợi", value: `• EXP x${targetVip.perks.expMultiplier}\n• Tiền x${targetVip.perks.moneyMultiplier}\n• ${targetVip.perks.dailyDiamonds}💎/ngày\n• Lãi suất +${targetVip.perks.interestRateBonus}%\n• Huy hiệu: ${targetVip.perks.badge}`, inline: false },
    );
  return interaction.reply({ embeds: [embed] });
}
