import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getPlayer, updatePlayer, formatMoney, playerId } from "../utils/db.js";
import { DISEASES, DISEASE_LIST, LIGHT_DISEASES, MEDIUM_DISEASES, HEAVY_DISEASES } from "../constants/diseases.js";
import { COLORS } from "../utils/embeds.js";
import { progressBar } from "../constants/levels.js";
import { db } from "@workspace/db";
import { playerDiseasesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

export const healthData = new SlashCommandBuilder()
  .setName("health")
  .setDescription("Kiểm tra sức khỏe và các bệnh đang mắc");

export async function healthExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký! Dùng `/dangky` trước.")] });
    return;
  }

  const pid = playerId(user.id, guildId);
  const diseases = await db.select().from(playerDiseasesTable).where(
    and(eq(playerDiseasesTable.playerId, pid), eq(playerDiseasesTable.isActive, true))
  );

  const healthBar = progressBar(player.health, 100, 15);
  const energyBar = progressBar(player.energy, 100, 15);
  const happinessBar = progressBar(player.happiness, 100, 15);

  let healthColor = COLORS.success;
  if (player.health < 30) healthColor = 0xed4245;
  else if (player.health < 60) healthColor = COLORS.warning;

  const embed = new EmbedBuilder()
    .setColor(healthColor)
    .setTitle(`🏥 Sức khỏe của ${user.displayName}`)
    .addFields(
      { name: "❤️ Sức khỏe", value: `${healthBar} **${player.health}/100**`, inline: false },
      { name: "⚡ Năng lượng", value: `${energyBar} **${player.energy}/100**`, inline: false },
      { name: "😊 Hạnh phúc", value: `${happinessBar} **${player.happiness}/100**`, inline: false },
    );

  if (diseases.length > 0) {
    const diseaseList = diseases.map((d) => {
      const info = DISEASES[d.diseaseId];
      if (!info) return `• ${d.diseaseId}`;
      const severityEmoji = info.severity === "light" ? "🟡" : info.severity === "medium" ? "🟠" : "🔴";
      return `${severityEmoji} ${info.emoji} **${info.name}** — Mất ${info.healthDrain}HP/giờ\n  Chi phí chữa: ${formatMoney(info.treatCost)}`;
    }).join("\n");

    embed.addFields({ name: `🦠 Bệnh đang mắc (${diseases.length})`, value: diseaseList.substring(0, 1000) });

    if (player.health < 20) {
      embed.addFields({ name: "⚠️ NGUY HIỂM!", value: "Sức khỏe quá thấp! Hãy đến bệnh viện ngay bằng lệnh `/benhvien`!" });
    } else {
      embed.addFields({ name: "💡 Gợi ý", value: "Dùng `/benhvien` để chữa bệnh!" });
    }
  } else {
    embed.addFields({ name: "✅ Tình trạng", value: "Bạn đang khỏe mạnh! Không mắc bệnh nào." });
  }

  // Restore energy info
  if (player.energy < 50) {
    embed.addFields({ name: "💡 Phục hồi năng lượng", value: "Năng lượng sẽ tự phục hồi theo thời gian, hoặc nhận hằng ngày `/hangngay`" });
  }

  await interaction.editReply({ embeds: [embed] });
}

export const hospitalData = new SlashCommandBuilder()
  .setName("hospital")
  .setDescription("Đến bệnh viện chữa bệnh")
  .addStringOption((opt) =>
    opt.setName("benh").setDescription("ID bệnh muốn chữa (xem trong /suckhoe)").setRequired(false)
  );

export async function hospitalExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] });
    return;
  }

  const pid = playerId(user.id, guildId);
  const diseases = await db.select().from(playerDiseasesTable).where(
    and(eq(playerDiseasesTable.playerId, pid), eq(playerDiseasesTable.isActive, true))
  );

  if (diseases.length === 0) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.success).setDescription("✅ Bạn không mắc bệnh nào! Sức khỏe tốt.")] });
    return;
  }

  const targetId = interaction.options.getString("benh");

  // Show list if no disease specified
  if (!targetId) {
    const list = diseases.map((d) => {
      const info = DISEASES[d.diseaseId];
      if (!info) return null;
      const sev = info.severity === "light" ? "🟡" : info.severity === "medium" ? "🟠" : "🔴";
      return `${sev} **${info.name}** (\`${info.id}\`) — ${formatMoney(info.treatCost)} | Tỷ lệ thành công: ${Math.round(info.treatSuccessRate * 100)}%`;
    }).filter(Boolean).join("\n");

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.primary)
          .setTitle("🏥 Bệnh viện — Danh sách bệnh")
          .setDescription(list + "\n\nDùng `/benhvien benh:<id>` để chữa một bệnh cụ thể.")
          .addFields({ name: "💰 Tiền của bạn", value: formatMoney(player.money) }),
      ],
    });
    return;
  }

  const diseaseRecord = diseases.find((d) => d.diseaseId === targetId);
  if (!diseaseRecord) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn không mắc bệnh này hoặc ID không đúng!")] });
    return;
  }

  const info = DISEASES[targetId];
  if (!info) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Không tìm thấy thông tin bệnh!")] });
    return;
  }

  if (player.money < info.treatCost) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền! Cần **${formatMoney(info.treatCost)}** nhưng bạn chỉ có **${formatMoney(player.money)}**`)],
    });
    return;
  }

  // Deduct cost
  await updatePlayer(user.id, guildId, { money: player.money - info.treatCost });

  // Check success
  const success = Math.random() < info.treatSuccessRate;

  if (success) {
    await db.update(playerDiseasesTable)
      .set({ isActive: false, treatedAt: new Date() })
      .where(eq(playerDiseasesTable.id, diseaseRecord.id));

    const healthRestore = Math.floor(20 + Math.random() * 20);
    await updatePlayer(user.id, guildId, { health: Math.min(100, player.health + healthRestore - info.healthDrain) });

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.success)
          .setTitle(`✅ Chữa bệnh thành công!`)
          .setDescription(`${info.emoji} **${info.name}** đã được chữa khỏi!\n\n💊 Chi phí: **${formatMoney(info.treatCost)}**\n❤️ Sức khỏe phục hồi: **+${healthRestore}**`)
          .setTimestamp(),
      ],
    });
  } else {
    // Failed treatment - might have death risk
    const dies = player.health <= 20 && Math.random() < info.deathRisk;
    if (dies) {
      await updatePlayer(user.id, guildId, { isAlive: false, health: 0 });
      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x000000)
            .setTitle("💀 Điều trị thất bại — Tử vong!")
            .setDescription(`${info.emoji} **${info.name}** quá nguy hiểm...\n**${user.displayName}** đã không qua khỏi!\n\n💔 Chi phí điều trị: **${formatMoney(info.treatCost)}** (không hoàn lại)\n\nDùng \`/hoisinh\` để hồi sinh (mất 50% tài sản).`)
            .setTimestamp(),
        ],
      });
    } else {
      await updatePlayer(user.id, guildId, { health: Math.max(1, player.health - 10) });
      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(COLORS.danger)
            .setTitle("❌ Điều trị thất bại!")
            .setDescription(`Điều trị **${info.name}** không thành công!\n\n💊 Chi phí: **${formatMoney(info.treatCost)}** (không hoàn lại)\n❤️ Sức khỏe: **-10**\n\nHãy thử lại hoặc chọn bệnh viện tốt hơn.`)
            .setTimestamp(),
        ],
      });
    }
  }
}

export const reviveData = new SlashCommandBuilder()
  .setName("revive")
  .setDescription("Hồi sinh sau khi chết (mất 50% tài sản)");

export async function reviveExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  await interaction.deferReply({ ephemeral: true });

  const player = await getPlayer(user.id, guildId);
  if (!player) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] });
    return;
  }

  if (player.isAlive) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription("⚠️ Bạn chưa chết! Không cần hồi sinh.")] });
    return;
  }

  const lostMoney = Math.floor(player.money / 2);
  const lostBank = Math.floor(player.bank / 2);

  await updatePlayer(user.id, guildId, {
    isAlive: true,
    health: 50,
    energy: 50,
    money: player.money - lostMoney,
    bank: player.bank - lostBank,
  });

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.success)
        .setTitle("✨ Hồi sinh thành công!")
        .setDescription(`**${user.displayName}** đã được hồi sinh!\n\n💸 Mất ${formatMoney(lostMoney)} trong ví\n🏦 Mất ${formatMoney(lostBank)} trong ngân hàng\n❤️ Sức khỏe: 50/100`)
        .setTimestamp(),
    ],
  });
}
