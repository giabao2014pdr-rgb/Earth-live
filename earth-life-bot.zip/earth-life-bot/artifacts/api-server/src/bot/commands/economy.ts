import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getPlayer, updatePlayer, formatMoney, cooldownRemaining, formatCooldown } from "../utils/db.js";
import { COLORS } from "../utils/embeds.js";
import { db } from "@workspace/db";
import { playersTable } from "@workspace/db";
import { desc, ne } from "drizzle-orm";
import { eq } from "drizzle-orm";
import { playerId } from "../utils/db.js";

export const balanceData = new SlashCommandBuilder()
  .setName("balance")
  .setDescription("Kiểm tra số dư ví và ngân hàng");

export async function balanceExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  await interaction.deferReply({ ephemeral: true });

  const player = await getPlayer(user.id, guildId);
  if (!player) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký! Dùng `/dangky` trước.")] });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(COLORS.gold)
    .setTitle("💰 Tài chính của bạn")
    .setThumbnail(user.displayAvatarURL())
    .addFields(
      { name: "👛 Ví tiền", value: `**${formatMoney(player.money)}**`, inline: true },
      { name: "🏦 Ngân hàng", value: `**${formatMoney(player.bank)}**`, inline: true },
      { name: "💎 Tổng tài sản", value: `**${formatMoney(player.money + player.bank)}**`, inline: true },
    )
    .setTimestamp();

  await interaction.editReply({ embeds: [embed] });
}

export const bankData = new SlashCommandBuilder()
  .setName("bank")
  .setDescription("Giao dịch ngân hàng")
  .addStringOption((opt) =>
    opt.setName("lenh").setDescription("Thao tác").setRequired(true)
      .addChoices(
        { name: "💳 Gửi tiền", value: "deposit" },
        { name: "💵 Rút tiền", value: "withdraw" },
        { name: "📊 Xem số dư", value: "balance" },
      )
  )
  .addIntegerOption((opt) => opt.setName("so_tien").setDescription("Số tiền (bỏ trống để gửi/rút tất cả)").setRequired(false).setMinValue(1));

export async function bankExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const cmd = interaction.options.getString("lenh", true);
  const amount = interaction.options.getInteger("so_tien");
  await interaction.deferReply({ ephemeral: true });

  const player = await getPlayer(user.id, guildId);
  if (!player) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký! Dùng `/dangky` trước.")] });
    return;
  }

  if (cmd === "balance") {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(COLORS.gold).setTitle("🏦 Ngân hàng").addFields(
        { name: "👛 Ví", value: formatMoney(player.money), inline: true },
        { name: "🏦 Tài khoản ngân hàng", value: formatMoney(player.bank), inline: true },
      )],
    });
    return;
  }

  if (cmd === "deposit") {
    const depositAmount = amount ?? player.money;
    if (depositAmount <= 0 || player.money < depositAmount) {
      await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền! Ví của bạn chỉ có **${formatMoney(player.money)}**`)] });
      return;
    }
    await updatePlayer(user.id, guildId, { money: player.money - depositAmount, bank: player.bank + depositAmount });
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(COLORS.success).setDescription(`✅ Đã gửi **${formatMoney(depositAmount)}** vào ngân hàng!\n🏦 Số dư ngân hàng: **${formatMoney(player.bank + depositAmount)}**`)],
    });
    return;
  }

  if (cmd === "withdraw") {
    const withdrawAmount = amount ?? player.bank;
    if (withdrawAmount <= 0 || player.bank < withdrawAmount) {
      await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền! Ngân hàng của bạn chỉ có **${formatMoney(player.bank)}**`)] });
      return;
    }
    await updatePlayer(user.id, guildId, { money: player.money + withdrawAmount, bank: player.bank - withdrawAmount });
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(COLORS.success).setDescription(`✅ Đã rút **${formatMoney(withdrawAmount)}** ra khỏi ngân hàng!\n👛 Ví của bạn: **${formatMoney(player.money + withdrawAmount)}**`)],
    });
  }
}

export const dailyData = new SlashCommandBuilder()
  .setName("daily")
  .setDescription("Nhận phần thưởng hằng ngày");

export async function dailyExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký! Dùng `/dangky` trước.")] });
    return;
  }

  const remaining = cooldownRemaining(player.lastDaily, 24);
  if (remaining > 0) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription(`⏰ Đã nhận rồi! Quay lại sau **${formatCooldown(remaining)}**`)],
    });
    return;
  }

  const reward = 500 + player.level * 50;
  const expReward = 50 + player.level * 5;
  const energyRestore = 50;

  await updatePlayer(user.id, guildId, {
    money: player.money + reward,
    exp: player.exp + expReward,
    energy: Math.min(100, player.energy + energyRestore),
    happiness: Math.min(100, player.happiness + 10),
    lastDaily: new Date(),
  });

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.gold)
        .setTitle("🎁 Phần thưởng hằng ngày!")
        .setDescription(`Chào **${user.displayName}**! Đây là phần thưởng của bạn hôm nay:\n\n💰 +**${formatMoney(reward)}**\n⭐ +**${expReward} EXP**\n⚡ +**${energyRestore} Năng lượng**\n😊 +10 Hạnh phúc\n\nHẹn gặp lại ngày mai! 🌟`)
        .setTimestamp(),
    ],
  });
}

export const payData = new SlashCommandBuilder()
  .setName("pay")
  .setDescription("Chuyển tiền cho người khác")
  .addUserOption((opt) => opt.setName("nguoi").setDescription("Người nhận tiền").setRequired(true))
  .addIntegerOption((opt) => opt.setName("so_tien").setDescription("Số tiền muốn chuyển").setRequired(true).setMinValue(1));

export async function payExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const target = interaction.options.getUser("nguoi", true);
  const amount = interaction.options.getInteger("so_tien", true);
  await interaction.deferReply();

  if (target.id === user.id) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Không thể chuyển tiền cho chính mình!")] });
    return;
  }

  const [sender, receiver] = await Promise.all([
    getPlayer(user.id, guildId),
    getPlayer(target.id, guildId),
  ]);

  if (!sender) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] });
    return;
  }
  if (!receiver) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Người nhận chưa đăng ký!")] });
    return;
  }
  if (sender.money < amount) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền! Ví của bạn chỉ có **${formatMoney(sender.money)}**`)] });
    return;
  }

  const fee = Math.floor(amount * 0.02); // 2% fee
  const received = amount - fee;

  await Promise.all([
    updatePlayer(user.id, guildId, { money: sender.money - amount }),
    updatePlayer(target.id, guildId, { money: receiver.money + received }),
  ]);

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.success)
        .setTitle("💸 Chuyển tiền thành công!")
        .addFields(
          { name: "👤 Người gửi", value: user.displayName, inline: true },
          { name: "👤 Người nhận", value: target.displayName, inline: true },
          { name: "💰 Số tiền", value: formatMoney(amount), inline: true },
          { name: "💳 Phí giao dịch (2%)", value: formatMoney(fee), inline: true },
          { name: "✅ Người nhận được", value: formatMoney(received), inline: true },
        ),
    ],
  });
}

export const leaderboardData = new SlashCommandBuilder()
  .setName("leaderboard")
  .setDescription("Bảng xếp hạng server")
  .addStringOption((opt) =>
    opt.setName("loai").setDescription("Loại xếp hạng").setRequired(false)
      .addChoices(
        { name: "💰 Giàu nhất", value: "money" },
        { name: "⭐ Cấp độ cao nhất", value: "level" },
      )
  );

export async function leaderboardExecute(interaction: ChatInputCommandInteraction) {
  const guildId = interaction.guildId!;
  const type = interaction.options.getString("loai") ?? "money";
  await interaction.deferReply();

  const players = await db
    .select()
    .from(playersTable)
    .where(eq(playersTable.guildId, guildId))
    .orderBy(type === "money" ? desc(playersTable.money) : desc(playersTable.level))
    .limit(10);

  if (players.length === 0) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription("Chưa có người chơi nào!")] });
    return;
  }

  const medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"];
  const title = type === "money" ? "💰 Top Giàu Nhất" : "⭐ Top Cấp Độ Cao Nhất";

  const rows = players.map((p, i) => {
    const value = type === "money" ? formatMoney(p.money + p.bank) : `Cấp ${p.level}`;
    return `${medals[i]} **${p.name}** — ${value}`;
  });

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.gold)
        .setTitle(title)
        .setDescription(rows.join("\n"))
        .setTimestamp(),
    ],
  });
}
