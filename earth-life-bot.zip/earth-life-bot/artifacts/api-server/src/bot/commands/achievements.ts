import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import { db } from "@workspace/db";
import { playerAchievementsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getPlayer, updatePlayer, formatMoney, playerId } from "../utils/db.js";
import { COLORS, errorEmbed } from "../utils/embeds.js";
import { ACHIEVEMENTS, type AchievementStats } from "../constants/achievements.js";

export const achievementsData = new SlashCommandBuilder()
  .setName("achievement")
  .setDescription("🏆 Xem thành tựu của bạn");

export async function achievementsExecute(interaction: ChatInputCommandInteraction) {
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký! Dùng /dangky")], ephemeral: true });

  const pid = playerId(interaction.user.id, interaction.guildId!);
  const unlocked = await db.select().from(playerAchievementsTable).where(eq(playerAchievementsTable.playerId, pid));
  const unlockedIds = new Set(unlocked.map(u => u.achievementId));

  // Check for new achievements
  const stats: AchievementStats = {
    level: player.level,
    totalEarned: player.totalEarned,
    money: player.money,
    bank: player.bank,
    houseLevel: player.houseLevel,
    carLevel: player.carLevel,
    casinoWins: player.casinoWins,
    casinoLosses: player.casinoLosses,
    workedTotal: player.workedTotal,
    children: player.children,
    isMarried: !!player.spouseId,
    guildGameId: player.guildGameId,
    loanAmount: player.loanAmount,
  };

  const newlyUnlocked: typeof ACHIEVEMENTS = [];
  for (const ach of ACHIEVEMENTS) {
    if (!unlockedIds.has(ach.id) && ach.check(stats)) {
      await db.insert(playerAchievementsTable).values({ playerId: pid, achievementId: ach.id });
      unlockedIds.add(ach.id);
      newlyUnlocked.push(ach);
      // Give rewards
      const updates: any = {};
      if (ach.reward.money) updates.money = player.money + ach.reward.money;
      if (ach.reward.exp) updates.exp = player.exp + ach.reward.exp;
      if (ach.reward.diamonds) updates.diamonds = player.diamonds + ach.reward.diamonds;
      if (Object.keys(updates).length) await updatePlayer(player.userId, player.guildId, updates);
    }
  }

  // Build embed
  const totalAch = ACHIEVEMENTS.length;
  const doneCount = unlockedIds.size;
  const progressPct = Math.round((doneCount / totalAch) * 100);

  const lines = ACHIEVEMENTS.map(ach => {
    const done = unlockedIds.has(ach.id);
    const rewardStr = [
      ach.reward.money ? `💵 ${formatMoney(ach.reward.money)}` : "",
      ach.reward.exp ? `⭐ ${ach.reward.exp} EXP` : "",
      ach.reward.diamonds ? `💎 ${ach.reward.diamonds}` : "",
    ].filter(Boolean).join(" ");
    return `${done ? "✅" : "⬜"} ${ach.emoji} **${ach.name}**\n   ↳ ${ach.description}${rewardStr ? ` | Thưởng: ${rewardStr}` : ""}`;
  });

  // Paginate: show in chunks
  const chunkSize = 8;
  const chunks: string[] = [];
  for (let i = 0; i < lines.length; i += chunkSize) {
    chunks.push(lines.slice(i, i + chunkSize).join("\n"));
  }

  const newlyUnlockedNote = newlyUnlocked.length > 0
    ? `\n\n🎉 **Vừa mở khóa:** ${newlyUnlocked.map(a => `${a.emoji} ${a.name}`).join(", ")}`
    : "";

  const embed = new EmbedBuilder()
    .setColor(COLORS.gold)
    .setTitle(`🏆 Thành Tựu — ${interaction.user.username}`)
    .setDescription(`**${doneCount}/${totalAch}** thành tựu (${progressPct}%)${newlyUnlockedNote}\n\n${chunks[0] ?? ""}`)
    .setFooter({ text: `Trang 1/${chunks.length} | Hoàn thành thành tựu để nhận phần thưởng!` });

  return interaction.reply({ embeds: [embed] });
}

/** Call this after major actions to auto-check and grant achievements */
export async function checkAndGrantAchievements(userId: string, guildId: string) {
  try {
    const { getPlayer: gp } = await import("../utils/db.js");
    const { db: database } = await import("@workspace/db");
    const { playerAchievementsTable: pat } = await import("@workspace/db");
    const { eq: eqFn } = await import("drizzle-orm");

    const player = await gp(userId, guildId);
    if (!player) return;

    const pid = `${userId}_${guildId}`;
    const unlocked = await database.select().from(pat).where(eqFn(pat.playerId, pid));
    const unlockedIds = new Set(unlocked.map((u: any) => u.achievementId));

    const stats: AchievementStats = {
      level: player.level, totalEarned: player.totalEarned, money: player.money,
      bank: player.bank, houseLevel: player.houseLevel, carLevel: player.carLevel,
      casinoWins: player.casinoWins, casinoLosses: player.casinoLosses,
      workedTotal: player.workedTotal, children: player.children,
      isMarried: !!player.spouseId, guildGameId: player.guildGameId, loanAmount: player.loanAmount,
    };

    for (const ach of ACHIEVEMENTS) {
      if (!unlockedIds.has(ach.id) && ach.check(stats)) {
        await database.insert(pat).values({ playerId: pid, achievementId: ach.id });
        const { updatePlayer: up } = await import("../utils/db.js");
        const updates: any = {};
        if (ach.reward.money) updates.money = player.money + ach.reward.money;
        if (ach.reward.exp) updates.exp = player.exp + ach.reward.exp;
        if (ach.reward.diamonds) updates.diamonds = player.diamonds + ach.reward.diamonds;
        if (Object.keys(updates).length) await up(userId, guildId, updates);
      }
    }
  } catch (_) { /* silent */ }
}
