import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getPlayer, updatePlayer, addExpAndMoney, formatMoney, cooldownRemaining, formatCooldown } from "../utils/db.js";
import { JOBS, JOB_LIST } from "../constants/jobs.js";
import { COLORS } from "../utils/embeds.js";
import { calculateLevel } from "../constants/levels.js";
import { DISEASES, DISEASE_LIST } from "../constants/diseases.js";
import { db } from "@workspace/db";
import { playerDiseasesTable, playersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { playerId } from "../utils/db.js";

// Work command
export const workData = new SlashCommandBuilder()
  .setName("work")
  .setDescription("Đi làm để kiếm tiền và EXP");

export async function workExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký! Dùng `/dangky` trước.")] });
    return;
  }

  if (!player.isAlive) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0x555555).setDescription("💀 Bạn đã chết! Không thể làm việc.")] });
    return;
  }

  const job = JOBS[player.job] ?? JOBS.unemployed!;
  const remaining = cooldownRemaining(player.lastWork, job.cooldownHours);
  if (remaining > 0) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription(`⏰ Bạn cần nghỉ ngơi! Có thể làm việc lại sau **${formatCooldown(remaining)}**`)],
    });
    return;
  }

  if (player.energy < job.energyCost) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription(`⚡ Không đủ năng lượng! Cần **${job.energyCost}** nhưng chỉ còn **${player.energy}**.\nHãy nghỉ ngơi hoặc ăn uống để phục hồi.`)],
    });
    return;
  }

  const levelInfo = calculateLevel(player.exp);
  const pay = Math.floor(job.basePay + job.payPerLevel * player.jobLevel + levelInfo.level * 10 + Math.random() * job.basePay * 0.3);
  const expGain = Math.floor(job.expGain + Math.random() * 10);

  const newEnergy = Math.max(0, player.energy - job.energyCost);
  const newHealth = Math.max(0, player.health - job.healthCost);
  const newHappiness = Math.min(100, player.happiness + 3);

  await updatePlayer(user.id, guildId, {
    energy: newEnergy,
    health: newHealth,
    happiness: newHappiness,
    lastWork: new Date(),
  });

  const result = await addExpAndMoney(player, expGain, pay);

  const workMessages: Record<string, string[]> = {
    farmer: ["Bạn đã cày ruộng cả ngày và thu hoạch được mùa bội thu!", "Đàn gà lớn khỏe, thu được nhiều trứng hôm nay!", "Vườn rau xanh tươi, bán được giá cao!"],
    police: ["Bạn đã bắt được tên trộm nguy hiểm!", "Tuần tra thành phố bình yên, nhận thưởng hoàn thành nhiệm vụ!", "Giải quyết vụ tai nạn giao thông thành công!"],
    doctor: ["Bạn đã cứu sống một bệnh nhân nguy kịch!", "Phẫu thuật thành công, gia đình bệnh nhân cảm ơn rối rít!", "Khám 50 bệnh nhân hôm nay, mệt nhưng vui!"],
    programmer: ["Code chạy ngon, khách hàng trả tiền sớm!", "Fix xong bug khó, sếp thưởng thêm!", "Deploy thành công tính năng mới, team ăn mừng!"],
    streamer: ["Stream đêm nay view đỉnh, donate ào ào!", "Clip viral triệu view, nhà tài trợ liên hệ!", "Thắng game live, fan donate mưa!"],
    chef: ["Món đặc biệt hôm nay được đánh giá 5 sao!", "Nhà hàng đông khách, thu nhập cao hơn thường ngày!", "Phát minh ra công thức mới, khách hàng khen ngợi!"],
  };

  const msgs = workMessages[player.job] ?? ["Bạn đã hoàn thành ca làm việc hôm nay!", "Một ngày làm việc hiệu quả!", "Công việc suôn sẻ, nhận được lương xứng đáng!"];
  const msg = msgs[Math.floor(Math.random() * msgs.length)]!;

  const embed = new EmbedBuilder()
    .setColor(COLORS.success)
    .setTitle(`${job.emoji} Hoàn thành công việc!`)
    .setDescription(msg)
    .addFields(
      { name: "💰 Thu nhập", value: `+**${formatMoney(pay)}**`, inline: true },
      { name: "⭐ EXP", value: `+**${expGain}**`, inline: true },
      { name: "⚡ Năng lượng", value: `-${job.energyCost} (còn ${newEnergy})`, inline: true },
    );

  if (result.leveledUp) {
    embed.addFields({ name: "🎉 LEVEL UP!", value: `Bạn đã lên **Cấp ${result.newLevel}**! Chúc mừng!`, inline: false });
  }

  embed.setFooter({ text: `Tổng tiền: ${formatMoney(result.player.money)} | Làm lại sau ${job.cooldownHours}h` });
  await interaction.editReply({ embeds: [embed] });
}

// Jobs command
export const jobsData = new SlashCommandBuilder()
  .setName("job")
  .setDescription("Xem và chọn nghề nghiệp")
  .addStringOption((opt) =>
    opt.setName("chon").setDescription("Chọn nghề để chuyển sang").setRequired(false)
      .addChoices(...JOB_LIST.map((j) => ({ name: `${j.emoji} ${j.name} (Cấp ${j.levelRequired})`, value: j.id })))
  );

export async function jobsExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký! Dùng `/dangky` trước.")] });
    return;
  }

  const chosenJob = interaction.options.getString("chon");
  if (chosenJob) {
    const job = JOBS[chosenJob];
    if (!job) {
      await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Nghề không tồn tại!")] });
      return;
    }
    if (player.level < job.levelRequired) {
      await interaction.editReply({
        embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription(`❌ Cần **Cấp ${job.levelRequired}** để chọn nghề này! (Bạn đang Cấp ${player.level})`)],
      });
      return;
    }
    if (player.job === chosenJob) {
      await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription(`⚠️ Bạn đã là **${job.emoji} ${job.name}** rồi!`)] });
      return;
    }
    await updatePlayer(user.id, guildId, { job: chosenJob, jobLevel: 1 });
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(COLORS.success).setTitle(`${job.emoji} Chuyển nghề thành công!`).setDescription(`Bạn đã trở thành **${job.name}**!\n\n📋 ${job.description}\n\n💰 Lương cơ bản: **${formatMoney(job.basePay)}**/ca\n⚡ Tốn năng lượng: **${job.energyCost}**`)],
    });
    return;
  }

  // List all jobs
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle("💼 Danh sách nghề nghiệp")
    .setDescription("Dùng `/nghe chon:<tên nghề>` để chuyển nghề\n\n" +
      JOB_LIST.map((j) => {
        const canWork = player.level >= j.levelRequired;
        return `${canWork ? "✅" : "🔒"} ${j.emoji} **${j.name}** (Cấp ${j.levelRequired}) — ${formatMoney(j.basePay)}/ca`;
      }).join("\n")
    )
    .setFooter({ text: `Nghề hiện tại: ${JOBS[player.job]?.name ?? "Thất nghiệp"} | Cấp ${player.level}` });

  await interaction.editReply({ embeds: [embed] });
}
