import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import { COLORS } from "../utils/embeds.js";
import { EVENTS, getActiveEvents, getEventBonuses } from "../constants/events.js";

export const eventsData = new SlashCommandBuilder()
  .setName("event")
  .setDescription("🎉 Xem sự kiện đang diễn ra và sắp tới");

export async function eventsExecute(interaction: ChatInputCommandInteraction) {
  const now = new Date();
  const activeEvents = getActiveEvents(now);
  const bonuses = getEventBonuses(now);

  const activeLines = activeEvents.length > 0
    ? activeEvents.map(ev => `${ev.emoji} **${ev.name}**\n   ${ev.description}`).join("\n\n")
    : "😴 Hiện không có sự kiện nào đang diễn ra.";

  // Upcoming events (next 60 days)
  const upcomingLines: string[] = [];
  for (const ev of EVENTS) {
    if (activeEvents.find(a => a.id === ev.id)) continue;
    const nextDate = findNextOccurrence(ev, now);
    if (nextDate && nextDate.getTime() - now.getTime() < 60 * 24 * 60 * 60 * 1000) {
      const ts = Math.floor(nextDate.getTime() / 1000);
      upcomingLines.push(`${ev.emoji} **${ev.name}** — <t:${ts}:R>`);
    }
  }

  const bonusLines: string[] = [];
  if (bonuses.expMultiplier > 1) bonusLines.push(`⭐ EXP x${bonuses.expMultiplier}`);
  if (bonuses.moneyMultiplier > 1) bonusLines.push(`💵 Tiền x${bonuses.moneyMultiplier}`);
  if (bonuses.luckBoost > 1) bonusLines.push(`🍀 May mắn +${Math.round((bonuses.luckBoost - 1) * 100)}%`);
  if (bonuses.dailyBonus > 0) bonusLines.push(`🎁 Điểm danh +${(bonuses.dailyBonus).toLocaleString("vi-VN")}₫`);

  const embed = new EmbedBuilder()
    .setColor(activeEvents.length > 0 ? COLORS.gold : COLORS.info)
    .setTitle("🎉 Sự Kiện Earth Life")
    .addFields(
      {
        name: `🔥 Đang diễn ra (${activeEvents.length})`,
        value: activeLines,
        inline: false,
      },
    );

  if (bonusLines.length > 0) {
    embed.addFields({ name: "✨ Bonus hiện tại", value: bonusLines.join("\n"), inline: false });
  }

  if (upcomingLines.length > 0) {
    embed.addFields({ name: "📅 Sắp diễn ra (60 ngày tới)", value: upcomingLines.join("\n"), inline: false });
  }

  embed.addFields({
    name: "📖 Tất cả sự kiện",
    value: EVENTS.map(ev => `${ev.emoji} **${ev.name}** — ${ev.startDay}/${ev.startMonth} đến ${ev.endDay}/${ev.endMonth}`).join("\n"),
    inline: false,
  });

  embed.setFooter({ text: "Các bonus sự kiện được áp dụng tự động khi bạn làm việc, khám phá và điểm danh!" });

  return interaction.reply({ embeds: [embed] });
}

function findNextOccurrence(ev: (typeof EVENTS)[0], from: Date): Date | null {
  const year = from.getFullYear();
  for (let y = year; y <= year + 1; y++) {
    const start = new Date(y, ev.startMonth - 1, ev.startDay);
    if (start > from) return start;
  }
  return null;
}
