import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import { db } from "@workspace/db";
import { playerItemsTable, activityLogsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { getPlayer, updatePlayer, formatMoney, playerId } from "../utils/db.js";
import { COLORS, errorEmbed } from "../utils/embeds.js";
import { ITEMS, SHOP_ITEMS, DIAMOND_ITEMS } from "../constants/items.js";

// ─── /tui_do ────────────────────────────────────────────────────────────────
export const inventoryData = new SlashCommandBuilder()
  .setName("inventory")
  .setDescription("🎒 Xem túi đồ của bạn");

export async function inventoryExecute(interaction: ChatInputCommandInteraction) {
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký! Dùng /dangky để tạo nhân vật.")], ephemeral: true });

  const pid = playerId(interaction.user.id, interaction.guildId!);
  const items = await db.select().from(playerItemsTable).where(eq(playerItemsTable.playerId, pid));

  if (items.length === 0) {
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.info).setTitle("🎒 Túi Đồ Trống").setDescription("Bạn chưa có vật phẩm nào.\nMua tại cửa hàng bằng `/cuahang`!").setFooter({ text: interaction.user.username })], ephemeral: false });
  }

  const grouped: Record<string, number> = {};
  for (const it of items) {
    grouped[it.itemId] = (grouped[it.itemId] ?? 0) + it.quantity;
  }

  const lines = Object.entries(grouped).map(([id, qty]) => {
    const info = ITEMS[id];
    if (!info) return `\`${id}\` × ${qty}`;
    return `${info.emoji} **${info.name}** × ${qty}\n   ↳ ${info.description}`;
  });

  const embed = new EmbedBuilder()
    .setColor(COLORS.gold)
    .setTitle(`🎒 Túi Đồ — ${interaction.user.username}`)
    .setDescription(lines.join("\n\n"))
    .setFooter({ text: `Dùng /dung <tên vật phẩm> để sử dụng` });

  return interaction.reply({ embeds: [embed] });
}

// ─── /cuahang ───────────────────────────────────────────────────────────────
export const shopData = new SlashCommandBuilder()
  .setName("shop")
  .setDescription("🏪 Cửa hàng vật phẩm")
  .addStringOption(opt =>
    opt.setName("loai").setDescription("Loại cửa hàng").setRequired(false)
      .addChoices(
        { name: "💵 Mua bằng tiền", value: "tien" },
        { name: "💎 Mua bằng kim cương", value: "diamond" },
        { name: "🛒 Mua một vật phẩm", value: "mua" },
      )
  )
  .addStringOption(opt => opt.setName("vat_pham").setDescription("ID vật phẩm muốn mua").setRequired(false))
  .addIntegerOption(opt => opt.setName("so_luong").setDescription("Số lượng muốn mua (mặc định 1)").setMinValue(1).setMaxValue(99).setRequired(false));

export async function shopExecute(interaction: ChatInputCommandInteraction) {
  const loai = interaction.options.getString("loai") ?? "tien";
  const vatPhamId = interaction.options.getString("vat_pham");
  const soLuong = interaction.options.getInteger("so_luong") ?? 1;

  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký! Dùng /dangky để tạo nhân vật.")], ephemeral: true });

  // Show shop list
  if (!vatPhamId || loai !== "mua") {
    const list = loai === "diamond" ? DIAMOND_ITEMS : SHOP_ITEMS;
    const lines = list.map(item =>
      `${item.emoji} **${item.name}** \`ID: ${item.id}\`\n   ${item.description}\n   ${loai === "diamond" ? `💎 ${item.diamondPrice} kim cương` : `💵 ${formatMoney(item.price)}`}`
    );
    const embed = new EmbedBuilder()
      .setColor(COLORS.gold)
      .setTitle(loai === "diamond" ? "💎 Cửa Hàng Kim Cương" : "🏪 Cửa Hàng Vật Phẩm")
      .setDescription(lines.join("\n\n"))
      .setFooter({ text: `Dùng /cuahang loai:mua vat_pham:<ID> để mua` });
    return interaction.reply({ embeds: [embed] });
  }

  // Buy item
  const item = ITEMS[vatPhamId];
  if (!item) return interaction.reply({ embeds: [errorEmbed("Không tìm thấy vật phẩm này!")], ephemeral: true });

  if (loai === "diamond") {
    if (item.diamondPrice === 0) return interaction.reply({ embeds: [errorEmbed("Vật phẩm này không bán bằng kim cương!")], ephemeral: true });
    const total = item.diamondPrice * soLuong;
    if (player.diamonds < total) return interaction.reply({ embeds: [errorEmbed(`Không đủ kim cương! Cần ${total}💎, bạn có ${player.diamonds}💎`)], ephemeral: true });
    await updatePlayer(player.userId, player.guildId, { diamonds: player.diamonds - total });
  } else {
    if (item.price === 0) return interaction.reply({ embeds: [errorEmbed("Vật phẩm này không bán bằng tiền mặt! Dùng kim cương 💎")], ephemeral: true });
    const total = item.price * soLuong;
    if (player.money < total) return interaction.reply({ embeds: [errorEmbed(`Không đủ tiền! Cần ${formatMoney(total)}, bạn có ${formatMoney(player.money)}`)], ephemeral: true });
    await updatePlayer(player.userId, player.guildId, { money: player.money - total });
  }

  const pid = playerId(interaction.user.id, interaction.guildId!);
  // Check if already have this item
  const existing = await db.select().from(playerItemsTable)
    .where(and(eq(playerItemsTable.playerId, pid), eq(playerItemsTable.itemId, vatPhamId)))
    .limit(1);

  if (existing.length > 0) {
    await db.update(playerItemsTable)
      .set({ quantity: existing[0]!.quantity + soLuong })
      .where(eq(playerItemsTable.id, existing[0]!.id));
  } else {
    await db.insert(playerItemsTable).values({ playerId: pid, itemId: vatPhamId, quantity: soLuong });
  }

  const price = loai === "diamond" ? `${item.diamondPrice * soLuong}💎` : formatMoney(item.price * soLuong);
  const embed = new EmbedBuilder()
    .setColor(COLORS.success)
    .setTitle("✅ Mua thành công!")
    .setDescription(`${item.emoji} **${item.name}** × ${soLuong}\n💸 Đã trả: **${price}**`)
    .setFooter({ text: "Dùng /tui_do để xem túi đồ, /dung để sử dụng" });

  return interaction.reply({ embeds: [embed] });
}

// ─── /dung ──────────────────────────────────────────────────────────────────
export const useItemData = new SlashCommandBuilder()
  .setName("use")
  .setDescription("🧪 Sử dụng vật phẩm trong túi đồ")
  .addStringOption(opt => opt.setName("vat_pham").setDescription("ID vật phẩm muốn dùng").setRequired(true));

export async function useItemExecute(interaction: ChatInputCommandInteraction) {
  const vatPhamId = interaction.options.getString("vat_pham", true);
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký!")], ephemeral: true });
  if (!player.isAlive) return interaction.reply({ embeds: [errorEmbed("Bạn đã tử vong! Dùng /hoisinh để hồi sinh.")], ephemeral: true });

  const pid = playerId(interaction.user.id, interaction.guildId!);
  const [owned] = await db.select().from(playerItemsTable)
    .where(and(eq(playerItemsTable.playerId, pid), eq(playerItemsTable.itemId, vatPhamId)))
    .limit(1);

  if (!owned || owned.quantity < 1) return interaction.reply({ embeds: [errorEmbed("Bạn không có vật phẩm này trong túi đồ!")], ephemeral: true });

  const item = ITEMS[vatPhamId];
  if (!item) return interaction.reply({ embeds: [errorEmbed("Vật phẩm không hợp lệ!")], ephemeral: true });

  if (item.type === "collectible") {
    // Profile effects
    await updatePlayer(player.userId, player.guildId, { profileEffect: vatPhamId });
    await db.update(playerItemsTable).set({ quantity: owned.quantity - 1 }).where(eq(playerItemsTable.id, owned.id));
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.success).setTitle("✨ Kích hoạt hiệu ứng!").setDescription(`${item.emoji} **${item.name}** đã được áp dụng vào hồ sơ của bạn!`)] });
  }

  if (item.type === "boost") {
    // For now, boosts that reduce cooldown
    if (item.effect?.cooldownReduce === 1) {
      await updatePlayer(player.userId, player.guildId, { lastWork: null });
      await db.update(playerItemsTable).set({ quantity: owned.quantity - 1 }).where(eq(playerItemsTable.id, owned.id));
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.success).setTitle("⏰ Cooldown đã xóa!").setDescription("Bạn có thể đi làm ngay bây giờ!")] });
    }
    return interaction.reply({ embeds: [errorEmbed("Gói boost này được kích hoạt tự động khi bạn làm việc/casino!")] });
  }

  if (item.type === "gift") {
    // Open gift box
    const rewards = openGiftBox(vatPhamId);
    const updates: Partial<typeof player> = {};
    const lines: string[] = [];
    if (rewards.money) { updates.money = player.money + rewards.money; lines.push(`💵 ${formatMoney(rewards.money)}`); }
    if (rewards.diamonds) { updates.diamonds = player.diamonds + rewards.diamonds; lines.push(`💎 ${rewards.diamonds} kim cương`); }
    if (Object.keys(updates).length) await updatePlayer(player.userId, player.guildId, updates);
    if (rewards.itemId) {
      const [ex] = await db.select().from(playerItemsTable).where(and(eq(playerItemsTable.playerId, pid), eq(playerItemsTable.itemId, rewards.itemId))).limit(1);
      if (ex) await db.update(playerItemsTable).set({ quantity: ex.quantity + 1 }).where(eq(playerItemsTable.id, ex.id));
      else await db.insert(playerItemsTable).values({ playerId: pid, itemId: rewards.itemId, quantity: 1 });
      const ri = ITEMS[rewards.itemId];
      if (ri) lines.push(`${ri.emoji} ${ri.name}`);
    }
    await db.update(playerItemsTable).set({ quantity: owned.quantity - 1 }).where(eq(playerItemsTable.id, owned.id));
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.gold).setTitle(`${item.emoji} Mở hộp quà!`).setDescription(`Bạn nhận được:\n${lines.join("\n")}`)] });
  }

  // Consumables (medicine etc.)
  const eff = item.effect ?? {};
  const updates: Record<string, number> = {};
  const lines: string[] = [];
  if (eff.health) { updates["health"] = Math.min(100, player.health + eff.health); lines.push(`❤️ +${eff.health} máu`); }
  if (eff.energy) { updates["energy"] = Math.min(100, player.energy + eff.energy); lines.push(`⚡ +${eff.energy} năng lượng`); }
  if (eff.happiness) { updates["happiness"] = Math.min(100, player.happiness + eff.happiness); lines.push(`😊 +${eff.happiness} hạnh phúc`); }
  if (eff.money) { updates["money"] = player.money + eff.money; lines.push(`💵 +${formatMoney(eff.money)}`); }
  if (eff.exp) { updates["exp"] = player.exp + eff.exp; lines.push(`⭐ +${eff.exp} EXP`); }

  await updatePlayer(player.userId, player.guildId, updates as any);
  await db.update(playerItemsTable).set({ quantity: owned.quantity - 1 }).where(eq(playerItemsTable.id, owned.id));

  const embed = new EmbedBuilder()
    .setColor(COLORS.success)
    .setTitle(`${item.emoji} Đã dùng: ${item.name}`)
    .setDescription(lines.join("\n") || "Không có hiệu ứng trực tiếp.");

  return interaction.reply({ embeds: [embed] });
}

function openGiftBox(boxId: string): { money?: number; diamonds?: number; itemId?: string } {
  const roll = Math.random();
  if (boxId === "hop_qua_lon") {
    if (roll < 0.05) return { diamonds: 50 };
    if (roll < 0.2) return { diamonds: 10 };
    if (roll < 0.6) return { money: Math.floor(Math.random() * 500000) + 100000 };
    return { money: Math.floor(Math.random() * 100000) + 10000 };
  }
  // hop_qua_nho
  if (roll < 0.3) return { money: Math.floor(Math.random() * 50000) + 5000 };
  if (roll < 0.6) return { itemId: "thuoc_bo" };
  if (roll < 0.8) return { itemId: "nuoc_tang_luc" };
  return { itemId: "ve_so" };
}
