import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import { db } from "@workspace/db";
import { giftCodesTable, giftCodeUsesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { getPlayer, updatePlayer, formatMoney, playerId } from "../utils/db.js";
import { COLORS, errorEmbed } from "../utils/embeds.js";

export const giftcodeData = new SlashCommandBuilder()
  .setName("redeem")
  .setDescription("🎟️ Nhập gift code để nhận thưởng")
  .addStringOption(o => o.setName("code").setDescription("Mã code").setRequired(true));

export async function giftcodeExecute(interaction: ChatInputCommandInteraction) {
  const code = interaction.options.getString("code", true).trim().toUpperCase();
  const player = await getPlayer(interaction.user.id, interaction.guildId!);
  if (!player) return interaction.reply({ embeds: [errorEmbed("Bạn chưa đăng ký! Dùng /dangky")], ephemeral: true });
  if (!player.isAlive) return interaction.reply({ embeds: [errorEmbed("Tài khoản bị khóa!")], ephemeral: true });

  // Find code
  const [gc] = await db.select().from(giftCodesTable)
    .where(and(eq(giftCodesTable.code, code), eq(giftCodesTable.guildId, interaction.guildId!)))
    .limit(1);

  if (!gc) return interaction.reply({ embeds: [errorEmbed("❌ Mã code không tồn tại!")], ephemeral: true });

  // Check expiry
  if (gc.expiresAt && new Date() > gc.expiresAt) {
    return interaction.reply({ embeds: [errorEmbed("❌ Mã code đã hết hạn!")], ephemeral: true });
  }

  // Check max uses
  if (gc.uses >= gc.maxUses) {
    return interaction.reply({ embeds: [errorEmbed("❌ Mã code đã hết lượt sử dụng!")], ephemeral: true });
  }

  const pid = playerId(interaction.user.id, interaction.guildId!);

  // Check if already used by this player
  const [alreadyUsed] = await db.select().from(giftCodeUsesTable)
    .where(and(eq(giftCodeUsesTable.codeId, gc.id), eq(giftCodeUsesTable.playerId, pid)))
    .limit(1);

  if (alreadyUsed) return interaction.reply({ embeds: [errorEmbed("❌ Bạn đã sử dụng mã code này rồi!")], ephemeral: true });

  // Apply rewards
  const r = gc.rewardsJson;
  const updates: any = {};
  const rewardLines: string[] = [];

  if (r.money) {
    updates.money = player.money + r.money;
    updates.totalEarned = player.totalEarned + r.money;
    rewardLines.push(`💵 **${formatMoney(r.money)}**`);
  }
  if (r.exp) {
    const { calculateLevel } = await import("../constants/levels.js");
    const newExp = player.exp + r.exp;
    const { level } = calculateLevel(newExp);
    updates.exp = newExp;
    updates.level = level;
    rewardLines.push(`⭐ **${r.exp} EXP**`);
  }
  if (r.diamonds) {
    updates.diamonds = player.diamonds + r.diamonds;
    rewardLines.push(`💎 **${r.diamonds} kim cương**`);
  }
  if (r.items?.length) {
    const { playerItemsTable } = await import("@workspace/db");
    for (const it of r.items) {
      const [ex] = await db.select().from(playerItemsTable)
        .where(and(eq(playerItemsTable.playerId, pid), eq(playerItemsTable.itemId, it.itemId))).limit(1);
      if (ex) await db.update(playerItemsTable).set({ quantity: ex.quantity + it.quantity }).where(eq(playerItemsTable.id, ex.id));
      else await db.insert(playerItemsTable).values({ playerId: pid, itemId: it.itemId, quantity: it.quantity });
      rewardLines.push(`🎁 **${it.itemId}** × ${it.quantity}`);
    }
  }

  if (Object.keys(updates).length) await updatePlayer(player.userId, player.guildId, updates);

  // Record usage
  await db.insert(giftCodeUsesTable).values({ codeId: gc.id, playerId: pid });
  await db.update(giftCodesTable).set({ uses: gc.uses + 1 }).where(eq(giftCodesTable.id, gc.id));

  const embed = new EmbedBuilder()
    .setColor(COLORS.gold)
    .setTitle("🎉 Nhập Code Thành Công!")
    .setDescription(`Mã: \`${code}\`\n\n**Phần thưởng nhận được:**\n${rewardLines.join("\n")}`)
    .setFooter({ text: `Lượt sử dụng: ${gc.uses + 1}/${gc.maxUses}` });

  return interaction.reply({ embeds: [embed] });
}
