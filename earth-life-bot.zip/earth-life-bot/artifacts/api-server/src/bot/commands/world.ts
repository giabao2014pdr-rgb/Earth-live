import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getPlayer, updatePlayer, addExpAndMoney, formatMoney, cooldownRemaining, formatCooldown, playerId } from "../utils/db.js";
import { LOCATIONS, LOCATION_LIST } from "../constants/world.js";
import { DISEASES, DISEASE_LIST } from "../constants/diseases.js";
import { COLORS } from "../utils/embeds.js";
import { db } from "@workspace/db";
import { playerDiseasesTable } from "@workspace/db";

function rng() { return Math.random(); }

export const exploreData = new SlashCommandBuilder()
  .setName("explore")
  .setDescription("🌎 Khám phá địa điểm hiện tại để nhận EXP và tiền");

export async function exploreExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }
  if (!player.isAlive) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0x555555).setDescription("💀 Bạn đã chết!")] }); return; }

  const remaining = cooldownRemaining(player.lastExplore, 0.5); // 30 min cooldown
  if (remaining > 0) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription(`⏰ Cần nghỉ ngơi! Khám phá lại sau **${formatCooldown(remaining)}**`)] });
    return;
  }

  const loc = LOCATIONS[player.location] ?? LOCATIONS.city!;
  const baseExp = Math.floor(20 * loc.expBonus + rng() * 20);
  const baseMoney = Math.floor(100 * loc.moneyBonus + rng() * 100);

  // Random event
  const event = loc.events[Math.floor(rng() * loc.events.length)]!;

  // Disease chance
  let diseaseMsg = "";
  if (rng() < loc.diseaseChance && player.health > 30) {
    const candidates = DISEASE_LIST.filter((d) => d.severity === "light");
    const disease = candidates[Math.floor(rng() * candidates.length)]!;
    const pid = playerId(user.id, guildId);
    await db.insert(playerDiseasesTable).values({ playerId: pid, diseaseId: disease.id }).onConflictDoNothing();
    diseaseMsg = `\n\n🦠 Bạn đã bị nhiễm **${disease.emoji} ${disease.name}**! Hãy đến bệnh viện (/benhvien)`;
  }

  await updatePlayer(user.id, guildId, { lastExplore: new Date(), energy: Math.max(0, player.energy - 10) });
  const result = await addExpAndMoney(player, baseExp, baseMoney);

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${loc.emoji} Khám phá ${loc.name}`)
    .setDescription(`Bạn đã khám phá và **${event}**!\n\n💰 +**${formatMoney(baseMoney)}**\n⭐ +**${baseExp} EXP**\n⚡ -10 Năng lượng${diseaseMsg}`);

  if (result.leveledUp) embed.addFields({ name: "🎉 LEVEL UP!", value: `Lên **Cấp ${result.newLevel}**!` });
  embed.setFooter({ text: "Cooldown: 30 phút" });

  await interaction.editReply({ embeds: [embed] });
}

export const travelData = new SlashCommandBuilder()
  .setName("travel")
  .setDescription("✈️ Di chuyển đến địa điểm khác")
  .addStringOption((opt) =>
    opt.setName("diadiem").setDescription("Địa điểm muốn đến").setRequired(true)
      .addChoices(...LOCATION_LIST.map((l) => ({ name: `${l.emoji} ${l.name}`, value: l.id })))
  );

export async function travelExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  const dest = interaction.options.getString("diadiem", true);
  await interaction.deferReply();

  const player = await getPlayer(user.id, guildId);
  if (!player) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Bạn chưa đăng ký!")] }); return; }
  if (player.location === dest) { await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLORS.warning).setDescription("⚠️ Bạn đã ở đây rồi!")] }); return; }

  const travelCost = player.carLevel > 0 ? 50 : 200;
  if (player.money < travelCost) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ Không đủ tiền đi lại! Cần **${formatMoney(travelCost)}**`)] });
    return;
  }

  const loc = LOCATIONS[dest]!;
  await updatePlayer(user.id, guildId, { location: dest, money: player.money - travelCost });

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.success)
        .setTitle(`${loc.emoji} Di chuyển thành công!`)
        .setDescription(`Bạn đã đến **${loc.name}**!\n${loc.description}\n\n💰 Chi phí đi lại: ${formatMoney(travelCost)}`)
        .addFields(
          { name: "📈 Bonus EXP", value: `x${loc.expBonus}`, inline: true },
          { name: "💰 Bonus Thu nhập", value: `x${loc.moneyBonus}`, inline: true },
          { name: "🦠 Nguy cơ bệnh", value: `${Math.round(loc.diseaseChance * 100)}%`, inline: true },
        ),
    ],
  });
}

export const mapData = new SlashCommandBuilder().setName("map").setDescription("🗺️ Xem bản đồ thế giới");

export async function mapExecute(interaction: ChatInputCommandInteraction) {
  const user = interaction.user;
  const guildId = interaction.guildId!;
  await interaction.deferReply({ ephemeral: true });

  const player = await getPlayer(user.id, guildId);

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle("🗺️ Bản đồ thế giới")
    .setDescription(
      LOCATION_LIST.map((l) => {
        const current = player?.location === l.id ? " **← Bạn đang ở đây**" : "";
        return `${l.emoji} **${l.name}**${current}\n  EXP: x${l.expBonus} | Thu nhập: x${l.moneyBonus} | Bệnh: ${Math.round(l.diseaseChance * 100)}%`;
      }).join("\n\n")
    )
    .setFooter({ text: "Dùng /dichuy để di chuyển" });

  await interaction.editReply({ embeds: [embed] });
}
