import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  GuildMember,
} from "discord.js";
import { getPlayer, getOrCreatePlayer, formatMoney, playerId } from "../utils/db.js";
import { JOBS } from "../constants/jobs.js";
import { HOUSES, CARS, LOCATIONS } from "../constants/world.js";
import { getLevelTitle, progressBar, expToNextLevel, calculateLevel } from "../constants/levels.js";
import { COLORS } from "../utils/embeds.js";
import { db } from "@workspace/db";
import { playerDiseasesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

export const data = new SlashCommandBuilder()
  .setName("profile")
  .setDescription("Xem hồ sơ nhân vật")
  .addUserOption((opt) => opt.setName("user").setDescription("Xem hồ sơ người khác").setRequired(false));

export async function execute(interaction: ChatInputCommandInteraction) {
  const target = interaction.options.getUser("user") ?? interaction.user;
  const guildId = interaction.guildId!;

  await interaction.deferReply();

  let player = await getPlayer(target.id, guildId);
  if (!player) {
    if (target.id === interaction.user.id) {
      player = await getOrCreatePlayer(target.id, guildId, target.displayName);
    } else {
      await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("❌ Người này chưa đăng ký! Hãy dùng `/dangky` trước.")] });
      return;
    }
  }

  const job = JOBS[player.job] ?? JOBS.unemployed!;
  const house = HOUSES.find((h) => h.level === player.houseLevel);
  const car = CARS.find((c) => c.level === player.carLevel);
  const location = LOCATIONS[player.location] ?? LOCATIONS.city!;
  const levelInfo = calculateLevel(player.exp);
  const title = getLevelTitle(player.level);
  const bar = progressBar(levelInfo.expInLevel, levelInfo.expNeeded);

  const pid = playerId(target.id, guildId);
  const diseases = await db.select().from(playerDiseasesTable).where(
    and(eq(playerDiseasesTable.playerId, pid), eq(playerDiseasesTable.isActive, true))
  );

  const healthBar = progressBar(player.health, 100, 10);
  const energyBar = progressBar(player.energy, 100, 10);
  const happinessBar = progressBar(player.happiness, 100, 10);

  const embed = new EmbedBuilder()
    .setColor(player.isAlive ? COLORS.primary : 0x555555)
    .setTitle(`${player.isAlive ? "" : "💀 "}${job.emoji} Hồ sơ của ${target.displayName}`)
    .setThumbnail(target.displayAvatarURL())
    .addFields(
      { name: "⭐ Cấp độ", value: `**${player.level}** — ${title}\n${bar} ${levelInfo.expInLevel}/${levelInfo.expNeeded} EXP`, inline: false },
      { name: "💰 Tài chính", value: `Ví: **${formatMoney(player.money)}**\nNgân hàng: **${formatMoney(player.bank)}**`, inline: true },
      { name: "👔 Nghề nghiệp", value: `${job.emoji} ${job.name}\n(Cấp ${player.jobLevel})`, inline: true },
      { name: "📍 Vị trí", value: `${location.emoji} ${location.name}`, inline: true },
      { name: "❤️ Sức khỏe", value: `${healthBar} ${player.health}/100`, inline: true },
      { name: "⚡ Năng lượng", value: `${energyBar} ${player.energy}/100`, inline: true },
      { name: "😊 Hạnh phúc", value: `${happinessBar} ${player.happiness}/100`, inline: true },
      { name: "🏠 Nhà", value: house ? `${house.emoji} ${house.name}` : "❌ Chưa có", inline: true },
      { name: "🚗 Xe", value: car ? `${car.emoji} ${car.name}` : "❌ Chưa có", inline: true },
      { name: "👨‍👩‍👧 Gia đình", value: player.spouseId ? `💍 Đã kết hôn\n👶 ${player.children} con` : "💔 Độc thân", inline: true },
    );

  if (diseases.length > 0) {
    embed.addFields({
      name: `🏥 Bệnh hiện tại (${diseases.length})`,
      value: diseases.map((d) => `• ${d.diseaseId}`).join("\n").substring(0, 200),
      inline: false,
    });
  }

  embed.setFooter({ text: `Tổng thu nhập: ${formatMoney(player.totalEarned)}` }).setTimestamp();

  await interaction.editReply({ embeds: [embed] });
}
