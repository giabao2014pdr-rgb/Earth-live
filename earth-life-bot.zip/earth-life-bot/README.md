# 🌍 Earth Life Bot — Full Source Code

    ## Cấu trúc thư mục
    ```
    artifacts/api-server/src/
    index.ts                    Entry point (Express + Discord bot)
    app.ts                      Express config + /api/ping endpoint
    bot/
      index.ts                  Đăng ký 45 slash commands, passive tasks
      commands/                 26 file lệnh (45 lệnh tổng)
      constants/                jobs, diseases, items, levels, events...
      utils/                    DB helpers, embed builders
    lib/db/
    src/
      index.ts                  Kết nối PostgreSQL (Drizzle ORM)
      schema/                   4 file schema: players, diseases, guilds, extras
    drizzle.config.ts
    railway.toml                  Config deploy lên Railway
    ```

    ## Biến môi trường
    | Tên | Mô tả |
    |-----|-------|
    | DISCORD_TOKEN | Token bot Discord |
    | DISCORD_CLIENT_ID | Client ID bot Discord |
    | DATABASE_URL | PostgreSQL connection string |
    | SESSION_SECRET | Chuỗi bất kỳ (vd: abc123) |
    | PORT | Tự động (Railway tự set) |

    ## Deploy Railway (miễn phí)
    1. Push lên GitHub
    2. railway.app → New Project → chọn repo
    3. Thêm plugin PostgreSQL (DATABASE_URL tự điền)
    4. Thêm: DISCORD_TOKEN, DISCORD_CLIENT_ID, SESSION_SECRET
    5. Railway tự build & bot online 24/7 ✅

    ## 45 Slash Commands
    /register /profile /work /job /balance /bank /daily /pay /leaderboard
    /loan /repay /interest /health /hospital /revive
    /slots /coinflip /blackjack /roulette /race /hilo /dice /poker /lottery
    /house /car /marry /divorce /baby /explore /travel /map /guild
    /inventory /shop /use /achievement /diamond /vip /admin /redeem
    /event /invest /history /help
    